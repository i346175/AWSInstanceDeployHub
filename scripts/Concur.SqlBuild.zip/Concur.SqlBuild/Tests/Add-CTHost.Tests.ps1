. ./Load-Module.ps1

[void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
[void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
[void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")

InModuleScope Concur.SqlBuild{

    ##########################################################################################
    # function for setup/cleanup

    function SetupCleanup {
        [cmdletbinding()]
        param(
            [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
            [string] $ComputerName
        )
        begin{
            $Config = Get-Configuration
            $Port = $Config.port 
        }
        process{

            # get the listener
            $Listener = Get-Listener ($Computer | Format-ServerName)

            if ([System.string]::IsNullOrEmpty($Listener)) {
                Write-Information "The Listener for computer $Computer was not found."
                return
            }

            try {
                # connect to ct_host server
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Config.cthostserver | Format-ServerName -AddPort)

                # delete the listener from ct_host.  Note that you MUST test with a listener that doesn't have any databases, or you'll get:
                #    The DELETE statement conflicted with the REFERENCE constraint "FK_CTH_DATABASE_INSTANCE_KEY". The conflict occurred in
                #    database "ct_host", table "dbo.CTH_DATABASE", column 'INSTANCE_KEY'.
                $cmd = "USE $($Config.cthostdbname)
                
                        DELETE dbo.cth_server_instance
                         WHERE UPPER(server_name) = '$($Listener.ToUpper())' 
                           AND port_num = $Port 
                           AND instance_name IS NULL"

                [void] $srv.ConnectionContext.ExecuteNonQuery($cmd)
            }
            catch{
                Add-EventLogEntry -Computer $Computer -EntryType Warning -Message "There was an error in trying to delete listener $($Listener | Format-ServerName) from CT_HOST"
                throw $_
            }
            finally {
                if ($srv) {
                    $srv.ConnectionContext.Disconnect() 
                }
            }
        }
        end {

        }
    }


    ##########################################################################################
    # tests for Test-CTHost

    Describe 'Test-CTHost success' {
        [bool] $bExists = Test-CTHost SEAPR1DB0580, SEAPR1DB7500
        
        It 'should be true' {
            $bExists | Should -BeTrue
        }
    }

    Describe 'Test-CTHost failure' {
        [bool] $bExists = Test-CTHost SEAPR1DB0580, SEAPR1DB3016
        
        It 'should be false' {
            $bExists | Should -BeFalse
        }
    }


    ##########################################################################################
    # tests for Add-CTHost

    $Computer = 'SEAPR1DBBAT082'    # DESTRUCTIVE TEST - Do not use a real server!
    $Config = Get-Configuration
    $Port = $Config.port 

    Describe 'Setup' {

        # delete the row from table in ct_host if it exists
        if (Test-CTHost -ComputerName $Computer) {
            SetupCleanup -ComputerName $Computer
        }

        # verify the listener either didn't exist in ct_host, or we just deleted it
        It 'listener should not exist in ct_host' {
            Test-CTHost $Computer | Should -BeFalse
        }
    }


    Describe 'Add-CTHost failure for server with no listener' {
        $ComputerNoListener = 'SEAPR1DB3016'
        Add-CTHost -ComputerName $ComputerNoListener

        It 'listener should not exist in ct_host' {
            Test-CTHost $ComputerNoListener | Should -BeFalse
        }
    }


    # ??Describe 'Add-CTHost failure for server with wrong roletype' {
    # $ComputerBadRole = 'SEAPR1DB3016'
    # Scott on Role Type: I think they do have device42 in this though, so we can likely look it up there?
    # I think the role type is one of the properties of the custom properties of a server in device42…let me look…
    # in pscc yes, in devtest, no…
    

    Describe 'Add-CTHost successful' {
        Add-CTHost -ComputerName $Computer

        It 'listener should exist in ct_host' {
            Test-CTHost $Computer | Should -BeTrue
        }
    }


    Describe 'Cleanup' {
        # delete the row from table in ct_host if it exists
        SetupCleanup -ComputerName $Computer

        It 'listener should not exist in ct_host' {
            Test-CTHost $Computer | Should -BeFalse
        }
    }
}
