. ./Load-Module.ps1

InModuleScope Concur.SqlBuild{
	
    $ComputerName = (Get-ClusterNode).Name
	
    Describe 'Test-Listener success' {
        [bool] $bExists = Test-Listener -ComputerName $ComputerName
        
        It 'should be true' {
            $bExists | Should Be True
        }
    }
    
    Describe 'Get-Listener success'{
        $Listener = Get-Listener -ComputerName $ComputerName

        It 'should not be null or empty'{
            $Listener | Should Not BeNullOrEmpty
        }
    }
}    
