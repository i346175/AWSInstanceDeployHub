. ./Load-Module.ps1

InModuleScope Concur.SqlBuild{
    $result = Get-SqlDefaultConfiguration

    Describe 'Get-SqlDefaultConfiguration'{
        It 'should not be null or empty'{
            $result | Should -Not -BeNullOrEmpty
        }
        It 'should have a count of trace flags > 0'{
            $result.traceflags.Split(',').Count | Should -BeGreaterThan 0
        }
        It 'should have Database Admins in the logins'{
            ($result.logins | Where-Object{$_.name -eq 'Database Admins'}).Count | should -BeGreaterThan 0
        }
        It 'should have configuration options'{
            $result.sp_config.Count | Should -BeGreaterThan 0
        }
    }

}