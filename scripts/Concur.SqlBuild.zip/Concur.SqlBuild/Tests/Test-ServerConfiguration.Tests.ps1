# https://jira.concur.com/browse/CSCI-223
# https://manualzz.com/doc/48900418/cis-microsoft-sql-server-2016-benchmark

. ./Load-Module.ps1

InModuleScope Concur.SqlBuild{
   
    # declarations
    $Config = Get-Configuration
    $ConfigSql = Get-SqlDefaultConfiguration
    $ComputerName = 'SEAPR1DB3016', 'SEAPR1DBBAT082'
    #$ComputerName = 'SEAPR1DBITIN007' # 

    Describe 'Setup' {
        $ComputerName | Set-SPConfiguration -Name 'show advanced options' -Value 1
    }

    # iterate the computers
    foreach($Computer in $ComputerName){

        # SQL Server sp_configure settings
        Describe 'SQL Server sp_configure settings' {
            foreach($cnfg in $ConfigSql.sp_config){
                if ($cnfg.Name -ne 'show advanced options') {

                    try{
                        $Computer | Test-SPConfiguration -Name $cnfg.Name -Value $cnfg.Value | Should -BeTrue
                    }
                    catch {
                        # otherwise exception will abort foreach loop 
                    }
                }
            }
        }


        # CIS security requirements: https://sap.sharepoint.com/:x:/r/sites/102791/Shared%20Documents/Cloud%20Services/Team%20Content%20(not%20public)/Central%20Infrastructure/Database%20Administration/DBA%20Run%20Books/Talos/Concur.SqlBuild_Docs/CISSecurityIssueTracking.xlsx?d=w3a59bdb9a0f64d4cbd6a8dfef8820234&csf=1&e=ETAXrq
        # Currently there are 41 requirements in the list.
        Describe 'CIS security requirement 1.1 - Ensure Latest SQL Server Service Packs and Hotfixes are Installed' {

            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                $srv.VersionString | Should -Be $ConfigSql.sqlserverversion
            }
            catch{
                Write-Warning "SQL Server version is incorrect on computer $Computer. Expected $($ConfigSql.sqlserverversion), found $($srv.VersionString)"
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }


        Describe 'CIS security requirement 1.2 - Ensure Single-Function Member Servers are Used' {
            # ?? Comment: "What exactly does this mean?"
        }

        # See sp_configure Pester tests for:
        #   2.1 - Ensure 'Ad Hoc Distributed Queries' Server Configuration Option is set to '0'
        #   2.2 - Ensure 'CLR Enabled' Server Configuration Option is set to '0'
        #   2.3 - Ensure 'Cross DB Ownership Chaining' Server Configuration Option is set to '0'
        #   2.4 - Ensure 'Database Mail XPs' Server Configuration Option is set to '0' 
        #   2.5 - Ensure 'Ole Automation Procedures' Server Configuration Option is set to '0' 
        #   2.6 - Ensure 'Remote Access' Server Configuration Option is set to '0'
        #   2.7 - Ensure 'Remote Admin Connections' Server Configuration Option is set to '0'
        #   2.8 - Ensure 'Scan For Startup Procs' Server Configuration Option is set to '0'


        Describe 'CIS security requirement 2.9 - Ensure "Trustworthy" Database Property is set to "Off"' {

            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                foreach ($Database in $srv.Databases | Where-Object{!$_.IsDatabaseSnapshot -and $_.Name -notin @('model', 'tempdb')}) {
                    $Database.TrustWorthy | Should -BeFalse
                }
            }
            catch{
                Write-Warning "Database $Database on computer $Computer has Trustworthy property set to True."
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }


        Describe 'CIS security requirement 2.10 - Ensure Unnecessary SQL Server Protocols are set to "Disabled"' {

            # check named pipes
            $bEnabled = Invoke-Command -ComputerName $Computer -ScriptBlock{
                [system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
                [system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SqlWmiManagement") | Out-Null
                $wmi = New-Object Microsoft.SqlServer.Management.smo.WMI.ManagedComputer $env:COMPUTERNAME
                $uri = "ManagedComputer[@Name='$env:COMPUTERNAME']/ServerInstance[@Name='MSSQLSERVER']/ServerProtocol[@Name='NP']" 
                $prot = $wmi.GetSmoObject($uri)
                return $prot.IsEnabled
            } 

            try {
                $bEnabled | Should -BeFalse
            }
            catch{
                Write-Warning "Protocol 'Named Pipes' is enabled on computer $Computer."
            }

            # check shared memory
            $bEnabled = Invoke-Command -ComputerName $Computer -ScriptBlock{
                [system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
                [system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SqlWmiManagement") | Out-Null
                $wmi = New-Object Microsoft.SqlServer.Management.smo.WMI.ManagedComputer $env:COMPUTERNAME
                $uri = "ManagedComputer[@Name='$env:COMPUTERNAME']/ServerInstance[@Name='MSSQLSERVER']/ServerProtocol[@Name='SM']" 
                $prot = $wmi.GetSmoObject($uri)
                return $prot.IsEnabled
            } 

            try {
                $bEnabled | Should -BeFalse
            }
            catch{
                Write-Warning "Protocol 'Shared Memory' is enabled on computer $Computer."
            }
        }


        Describe 'CIS security requirement 2.11 - Ensure SQL Server is configured to use non-standard ports' {

            $PortNumber = Invoke-Command -ComputerName $Computer -ScriptBlock{
                [system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
                [system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SqlWmiManagement") | Out-Null
                $mc = new-object Microsoft.SqlServer.Management.smo.WMI.ManagedComputer $using:Computer
                $Instance = $mc.ServerInstances['MSSQLSERVER']
                $protocol = $Instance.ServerProtocols['Tcp']
                $ip = $protocol.IPAddresses['IPAll']
                $ipProps = $ip.IPAddressProperties['TcpPort']
                return $ipProps.Value
            } 

            try {
                $PortNumber | Should -Be $Config.port
            }
            catch{
                Write-Warning "Non-standard SQL Server port found on computer $Computer. Expected $($Config.port), found $($PortNumber)."
            }
        }


        Describe 'CIS security requirement 2.12 - Ensure "Hide Instance" option is set to "Yes" for Production SQL Server instances' {
            # Contained Databases Feature Not In Use
        }


        Describe 'CIS security requirement 2.13 - Ensure the "sa" Login Account is set to "Disabled"' {
            $saAcctName = $ConfigSql.salogin

            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                if(Test-Login -ComputerName $Computer -Name $saAcctName){
                    $srv.Logins[$saAcctName].IsDisabled | Should -BeTrue
                }
                else{
                    Write-Warning "The sa Login Account '$($saAcctName)' does not exist on computer $Computer." 
                }
            }
            catch{
                Write-Warning "The sa Login Account '$($saAcctName)' exists but is not disabled on computer $Computer." 
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }


        Describe 'CIS security requirement 2.14 - Ensure the "sa" Login Account has been renamed' {

            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                Test-Login -ComputerName $Computer -Name "sa" | Should -BeFalse
            }
            catch{
                Write-Warning "The 'sa' Login Account has not been renamed on computer $Computer." 
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }


        # See sp_configure Pester tests for:
        #   2.15 - Ensure 'xp_cmdshell' Server Configuration Option is set to '0' 


        Describe 'CIS security requirement 2.16 - Ensure "AUTO_CLOSE" is set to "OFF" on contained databases' {
            # Contained Databases Feature Not In Use
        }


        Describe 'CIS security requirement 2.17 - Ensure no login exists with the name "sa"' {

            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                Test-Login -ComputerName $Computer -Name "sa" | Should -BeFalse
            }
            catch{
                Write-Warning "There is an 'sa' Login Account on computer $Computer." 
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }


        Describe 'CIS security requirement 3.1 - Ensure "Server Authentication" Property is set to "Windows Authentication Mode"' {

            [Microsoft.SqlServer.Management.SMO.ServerLoginMode] $LoginMode = Invoke-Command -ComputerName $Computer -ScriptBlock{
                [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
                [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
                [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer)
                return $srv.Settings.LoginMode
            }

            try {
                $LoginMode | Should -Be [Microsoft.SqlServer.Management.SMO.ServerLoginMode]::Integrated 
            }
            catch {
                Write-Warning "Server Authentication is set incorrectly on computer $Computer. Expected $([Microsoft.SqlServer.Management.SMO.ServerLoginMode]::Integrated), found $($LoginMode)."
            }
        }


        Describe 'CIS security requirement 3.2 - Ensure CONNECT permissions on the "guest" user is Revoked within all SQL Server databases excluding the master, msdb and tempdb' {

            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                $PermSet = New-Object Microsoft.SqlServer.Management.smo.DatabasePermissionSet([Microsoft.SqlServer.Management.smo.DatabasePermission]::Connect)
                $Name = 'guest'

                foreach($Database in $srv.Databases | Where-Object{!$_.IsSystemObject}){
                    if($Computer | Test-DatabaseUser -DatabaseName $Database.Name -Name $Name){
                        $oPerms = $Database.EnumDatabasePermissions($Name, $PermSet)

                        try {
                            $oPerms.Length | Should -Be 0 
                        }
                        catch {
                            Write-Warning "CONNECT permission on 'guest' user is not revoked on computer $Computer, database $($Database.Name)."
                        }
                    }
                }
            }
            catch{
                throw $_ 
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }


        Describe 'CIS security requirement 3.3 - Ensure "Orphaned Users" are Dropped From SQL Server Databases' {

            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true            
                foreach($Database in $srv.Databases | Where-Object{!$_.IsSystemObject -and $_.Status -eq [Microsoft.SqlServer.Management.smo.DatabaseStatus]::Normal -and !$_.IsDatabaseSnapshot -and !$_.ReadOnly}){
            
                    foreach($User in $Database.Users | Where-Object{[System.String]::IsNullOrEmpty($_.Login) -and $_.AuthenticationType -ne [Microsoft.SqlServer.Management.smo.AuthenticationType]::None}){
                        $UserName = $User.Name.Trim()

                        try {
                            $UserName | Should -NotBeNullOrEmpty 
                        }
                        catch {
                            Write-Warning "Orphaned user '$UserName' found on computer $Computer, database $($Database.Name)."
                        }
                    }
                }
            }
            catch{
                throw $_ 
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }


        Describe 'CIS security requirement 3.4 - Ensure SQL Authentication is not used in contained databases' {
            # Contained Databases Feature Not In Use
        }


        #?? Scott is checking to see if this needs to check for Windows Admin, not sysadmin.
        Describe 'CIS security requirement 3.5 - Ensure the SQL Server MSSQL Service Account is Not an Administrator' {
            $ServiceName = 'MSSQLSERVER'
            $AcctName = Get-SqlServiceAccount -ComputerName $Computer | Where-Object{$_.Name -eq $ServiceName}

            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                try {
                    $srv.Logins[$AcctName.ServiceAccount].IsMember("sysadmin") | Should -BeFalse
                }
                catch {
                    Write-Warning "$ServiceName service account $($AcctName.ServiceAccount) is an Administrator on computer $Computer."
                }
            }
            catch{
                throw $_ 
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }


        #?? Scott is checking to see if this needs to check for Windows Admin, not sysadmin.
        Describe 'CIS security requirement 3.6 - Ensure the SQL Server SQLAgent Service Account is Not an Administrator' {
            $ServiceName = 'SQLSERVERAGENT'
            $AcctName = Get-SqlServiceAccount -ComputerName $Computer | Where-Object{$_.Name -eq $ServiceName}

            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                try {
                    $srv.Logins[$AcctName.ServiceAccount].IsMember("sysadmin") | Should -BeFalse
                }
                catch {
                    Write-Warning "$ServiceName service account $($AcctName.ServiceAccount) is an Administrator on computer $Computer."
                }
            }
            catch{
                throw $_ 
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }


        Describe 'CIS security requirement 3.7 - Ensure the SQL Server Full-Text Service Account is Not an Administrator' {
            # Full-Text Service Not In Use
        }


        # ?? I *think* this is correct, but can't figure out how to test it by violating the rule.
        Describe 'CIS security requirement 3.8 - Ensure only the default permissions specified by Microsoft are granted to the public server role' {

            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true                
                try {
                    $srv.Roles['public'].EnumObjectPermissions() | Should -BeNullOrEmpty
                }
                catch {
                    Write-Warning "Non-default permissions are granted to the public server role on computer $Computer."
                }
            }
            catch{
                throw $_
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }


        # ?? Will come back to this one.
        Describe 'CIS security requirement 3.9 - Ensure Windows BUILTIN groups are not SQL Logins' {
        }


        # ?? Will come back to this one.
        Describe 'CIS security requirement 3.10 - Ensure Windows local groups are not SQL Logins' {
        }


        # ?? Will come back to this one.
        Describe 'CIS security requirement 3.11 - Ensure the public role in the msdb database is not granted access to SQL Agent proxies' {
        }


        Describe 'CIS security requirement 4.1 - Ensure "MUST_CHANGE" Option is set to "ON" for All SQL Authenticated Logins' {
            # BOL: If MUST_CHANGE is specified, CHECK_EXPIRATION and CHECK_POLICY must be set to ON.
            # Note: To enable the grayed-out "must change" checkbox in SSMS, you must change the password first.
            # BOL: Server principals with names enclosed by double hash marks (##) are for internal system use only.
            #      These principal accounts do not have passwords that can be changed by administrators as they are
            #      based on certificates issued to Microsoft.

            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                foreach ($Login in $srv.Logins) {
                    if($Login.LoginType -eq [Microsoft.SqlServer.Management.smo.LoginType]::SqlLogin) {
                        
                        if ($Login.Name -notlike '##*') {

                            try {
                                $Login.mustchangepassword | Should -BeTrue
                            }
                            catch {
                                Write-Warning "SQL Login '$($Login.Name)' does not have MUST_CHANGE option set on computer $Computer."
                            }
                        }
                    }
                }
            }
            catch{
                throw $_
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }

    
        Describe 'CIS security requirement 4.2 - Ensure "CHECK_EXPIRATION" Option is set to "ON" for All SQL Authenticated Logins Within the Sysadmin Role' {
            # BOL: Server principals with names enclosed by double hash marks (##) are for internal system use only.
            #      These principal accounts do not have passwords that can be changed by administrators as they are
            #      based on certificates issued to Microsoft.

            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                $Role = $srv.Roles['sysadmin']

                foreach ($LoginName in $Role.EnumMemberNames()) {
                    $Login = $srv.Logins[$LoginName]

                    if($Login.LoginType -eq [Microsoft.SqlServer.Management.smo.LoginType]::SqlLogin) {
                        
                        if ($Login.Name -notlike '##*') {

                            try {
                                $Login.checkexpiration | Should -BeTrue
                            }
                            catch {
                                Write-Warning "The sysadmin SQL Login '$($Login.Name)' does not have CHECK_EXPIRATION option set on computer $Computer."
                            }
                        }
                    }
                }
            }
            catch{
                throw $_
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }


        Describe 'CIS security requirement 4.3 - Ensure "CHECK_POLICY" Option is set to "ON" for All SQL Authenticated Logins' {
            # BOL: Server principals with names enclosed by double hash marks (##) are for internal system use only.
            #      These principal accounts do not have passwords that can be changed by administrators as they are
            #      based on certificates issued to Microsoft.

            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true

                foreach ($Login in $srv.Logins) {
                    if($Login.LoginType -eq [Microsoft.SqlServer.Management.smo.LoginType]::SqlLogin) {
                        
                        if ($Login.Name -notlike '##*') {

                            try {
                                $Login.checkpolicy | Should -BeTrue
                            }
                            catch {
                                Write-Warning "SQL Login '$($Login.Name)' does not have CHECK_POLICY option set on computer $Computer."
                            }
                        }
                    }
                }
            }
            catch{
                throw $_
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }


        Describe 'CIS security requirement 5.1 - Ensure "Maximum number of error log files" is set to greater than or equal to "12"' {
            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true

                if ($srv.NumberOfLogFiles -eq -1) {
                    Write-Warning "ERRORLOG recycling is not enabled on computer $Computer."
                }

                try {
                    $srv.NumberOfLogFiles | Should -BeGreaterOrEqual $ConfigSql.errorlogcount
                }
                catch {
                    Write-Warning "'Maximum number of error log files' is incorrect on computer $Computer. Expected $($ConfigSql.errorlogcount), found $($srv.NumberOfLogFiles)."
                }
            }
            catch{
                throw $_ 
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect()
                }
            }
        }


        # See sp_configure Pester tests for:
        #   5.2 - Ensure 'Default Trace Enabled' Server Configuration Option is set to '1' 


        Describe 'CIS security requirement 5.3 - Ensure "Login Auditing" is set to "failed logins"' {
            $Level = 'Failure'

            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true

                try {
                    $srv.AuditLevel | Should -Be $Level
                }
                catch {
                    Write-Warning "'Login Auditing' is incorrect on computer $Computer. Expected $($Level), found $($srv.AuditLevel)."
                }
            }
            catch{
                throw $_ 
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect()
                }
            }
        }


        Describe 'CIS security requirement 5.4 - Ensure "SQL Server Audit" is set to capture both "failed" and "successful logins"' {
            $AuditName = $ConfigSql.audits | Where-Object{$_.name -eq 'TrackLogins'}
            $AuditSpecName = $ConfigSql.audits | Where-Object{$_.name -eq 'TrackLogins'} | Select-Object -ExpandProperty auditspecname
    
            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                $Audit = $srv.Audits[$AuditName.Name]

                if ($Audit) {
                    $AuditSpec = $srv.ServerAuditSpecifications | Where-Object {$_.Name -ieq $AuditSpecName}

                    if ($AuditSpec) {
                        $AuditSpecDetails = $AuditSpec.EnumAuditSpecificationDetails()

                        try {
                            $AuditActionType = [Microsoft.SqlServer.Management.Smo.AuditActionType]::FailedLoginGroup
                            $SpecDetail = new-object Microsoft.SqlServer.Management.Smo.AuditSpecificationDetail($AuditActionType)
                            $AuditSpecDetails | Should -Contain $SpecDetail
                        }
                        catch {
                            Write-Warning "'SQL Server Audit' is not set to capture $($AuditActionType) login events on computer $Computer."
                        }
    
                        try {
                            $AuditActionType = [Microsoft.SqlServer.Management.Smo.AuditActionType]::SuccessfulLoginGroup
                            $SpecDetail = new-object Microsoft.SqlServer.Management.Smo.AuditSpecificationDetail($AuditActionType)
                            $AuditSpecDetails | Should -Contain $SpecDetail
                        }
                        catch {
                            Write-Warning "'SQL Server Audit' is not set to capture '$($AuditActionType)' login events on computer $Computer."
                        }
                    }
                    else {
                        Write-Warning "'SQL Server Audit' specification does not exist for Audit '$($Audit.Name)' on computer $Computer."
                    }
                }
                else {
                    Write-Warning "'SQL Server Audit' does not exist on computer $Computer."
                }
            }
            catch {
                throw $_
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect()
                }
            }
        }


        Describe 'CIS security requirement 6.1 - Ensure Sanitize Database and Application User Input is Sanitized' {
            # Comment: "Must be answered by application teams"
        }


        Describe 'CIS security requirement 6.2 - Ensure "CLR Assembly Permission Set" is set to "SAFE_ACCESS" for All CLR Assemblies' {

            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                foreach ($Database in $srv.Databases | Where-Object {! $_.IsDatabaseSnapshot -and $_.Name -notin @('model', 'tempdb')}) {
                    [Microsoft.SqlServer.Management.Smo.SqlAssemblyCollection] $Assemblies = $Database.Assemblies

                    foreach ($Assembly in $Database.Assemblies | Where-Object IsSystemObject -eq $false) {

                        try {
                            $Assembly.AssemblySecurityLevel | Should -Be [Microsoft.SqlServer.Management.Smo.AssemblySecurityLevel]::Safe
                        }
                        catch {
                            Write-Warning "Security level for CLR assembly '$($Assembly.Name)' is incorrect in database '$($Database.Name)' on computer $Computer. Expected '$([Microsoft.SqlServer.Management.Smo.AssemblySecurityLevel]::Safe)', found '$($Assembly.AssemblySecurityLevel)'."
                        }
                    }
                }
            }
            catch {
                throw $_
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }


        Describe 'CIS security requirement 7.1 - Ensure "Symmetric Key encryption algorithm" is set to "AES_128" or higher in non-system databases' {
            # https://docs.microsoft.com/en-us/dotnet/api/microsoft.sqlserver.management.smo.symmetrickeyencryptionalgorithm?view=sql-smo-140.17283.0
            # CIS document: "The following algorithms (as referred to by SQL Server) are considered weak or deprecated and 
            #                should no longer be used in SQL Server: DES, DESX, RC2, RC4, RC4_128."

            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                foreach ($Database in $srv.Databases | Where-Object {! $_.IsDatabaseSnapshot -and ! $_.IsSystemObject}) {
                    $SymmetricKeys = $Database.SymmetricKeys

                    foreach ($SymmetricKey in $SymmetricKeys) {

                        try {
                            $SymmetricKey.EncryptionAlgorithm | Should -BeIn @('Aes128', 'Aes192', 'Aes256')
                        }
                        catch {
                            Write-Warning "Incorrect encryption algorithm '$($SymmetricKey.EncryptionAlgorithm)' found on symmetric key '$($SymmetricKey.Name)' in database '$($Database.Name)' on computer $Computer."
                        }
                    }

                }
            }
            catch {
                throw $_
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }


        Describe 'CIS security requirement 7.2 - Ensure Asymmetric Key Size is set to "greater than or equal to 2048" in non-system databases' {
            # https://docs.microsoft.com/en-us/dotnet/api/microsoft.sqlserver.management.smo.asymmetrickeyencryptionalgorithm?view=sql-smo-140.17283.0

            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                foreach ($Database in $srv.Databases | Where-Object {! $_.IsDatabaseSnapshot -and ! $_.IsSystemObject}) {
                    $AsymmetricKeys = $Database.AsymmetricKeys

                    foreach ($AsymmetricKey in $AsymmetricKeys) {

                        try {
                            $AsymmetricKey.KeyLength | Should -BeGreaterOrEqual 2048
                        }
                        catch {
                            Write-Warning "Incorrect encryption algorithm '$($AsymmetricKey.KeyEncryptionAlgorithm)' ($($AsymmetricKey.KeyLength) bits) found on asymmetric key '$($AsymmetricKey.Name)' in database '$($Database.Name)' on computer $Computer."
                        }
                    }

                }
            }
            catch {
                throw $_
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }


        Describe 'CIS security requirement 8.1 - Ensure "SQL Server Browser Service" is configured correctly' {
            # CIS: "No recommendation is being given on disabling the SQL Server Browser service.
            #       Rationale: In the case of a default instance installation, the SQL Server Browser service is disabled by default. 
            #       Unless there is a named instance on the same server, there is typically no reason for the SQL Server Browserservice
            #       to be running. In this case it is strongly suggested that the SQL Server Browser service remain disabled."

            $SQLInstances = Invoke-Command -ComputerName $Computer {
                (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances
            }

            $objects = New-Object System.Collections.Generic.List[PSCustomObject]

            foreach ($SQLInstance in $SQLInstances) {

                if ($SQLInstance -ne 'MSSQLSERVER') {
                    Write-Warning "Found named SQL Server instance '$($SQLInstance)' on computer $Computer."

                    $objects.Add(
                        [PSCustomObject]@{
                            InstanceName = $SQLInstance
                        })
                }
            }

            try {
                $objects | Should -BeNullOrEmpty

                # If there are no named instances, Browser service should not be running.
                $service = Get-SqlServiceAccount -ComputerName $Computer | Where-Object{$_.Name -eq 'SQLBrowser'}

                # For some reason, "Should -Be" isn't working for this, so I'm hacking it like this.  Pester bug?
                if ($service.ServiceState -ne [Microsoft.SqlServer.Management.Smo.Wmi.ServiceState]::Stopped) {
                    Write-Warning "SQL Server service 'SQLBrowser' is not stopped, and there are no named instances on computer $Computer."
                }

                <# Should work, but doesn't. See above.
                try {
                    $service.ServiceState | Should -Be [Microsoft.SqlServer.Management.Smo.Wmi.ServiceState]::Stopped 
                }
                catch {
                    Write-Warning "SQL Server service 'SQLBrowser' is not stopped, and there are no named instances on computer $Computer."
                }
                #>
            }    
            catch {
                Write-Warning "Found $($objects.Count) named SQL Server instances on computer $Computer."
            }
        }



 

            


    }

    Describe 'Cleanup' {
        $ComputerName | Set-SPConfiguration -Name 'show advanced options' -Value 0
    }
}
