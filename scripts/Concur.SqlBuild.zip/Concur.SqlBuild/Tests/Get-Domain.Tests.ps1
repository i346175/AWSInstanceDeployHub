. ./Load-Module.ps1

Describe 'Get-Domain'{
    It 'should not be null or empty'{
        Get-Domain | Should -Not -BeNullOrEmpty
    }
}