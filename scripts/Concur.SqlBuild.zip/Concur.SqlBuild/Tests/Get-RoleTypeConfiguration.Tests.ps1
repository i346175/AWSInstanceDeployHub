param(
    $Name = 'db0'
)
. ./Load-Module.ps1

InModuleScope Concur.SqlBuild{
    $result = Get-RoleTypeConfiguration -Name $Name
    
    Describe 'Get-SqlDefaultConfiguration'{
        It 'should not be null or empty'{
            $result | Should -Not -BeNullOrEmpty
        }
        It 'should have a template property'{
            $result.template | should -Not -BeNullOrEmpty
        }
        It 'should have an os property'{
            $result.os | Should -Not -BeNullOrEmpty
        }
        It 'should have storage'{
            $result.storage.count | Should -BeGreaterThan 0
        }
        It 'should have logins'{
            $result.logins.count | Should -BeGreaterThan 0
        }
    }

}