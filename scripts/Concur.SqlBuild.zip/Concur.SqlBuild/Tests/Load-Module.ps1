$moduleName = (get-item -path (Split-Path -Path $PSScriptRoot -Parent)).BaseName
$path = Join-Path -Path  $($PSScriptRoot | Split-Path -Parent) -ChildPath "$moduleName.psm1"
Import-Module $path -Force -DisableNameChecking