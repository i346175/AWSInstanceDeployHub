. ./Load-Module.ps1 

Describe 'Convert-HexStringToByte'{
    $value = '0x5BF7677A9D22BD4DB697CDD179F23D69'  | Convert-HexStringToByte

    It 'should not be null or empty'{
        $value | Should -Not -BeNullOrEmpty
    }

    It 'should return a byte value'{
        $value | Should -BeOfType [byte]
    }

    it 'should have a count greater than 0'{
        $value.length | Should -BeGreaterThan 0
    }
}