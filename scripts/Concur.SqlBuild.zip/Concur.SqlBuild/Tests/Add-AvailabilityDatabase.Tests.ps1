. ./Load-Module.ps1


InModuleScope Concur.SqlBuild{
    Describe 'Add-AvailabilityDatabase'{

        $roleConfig = Get-RoleTypeConfiguration -Name 'dbsql'
        $configAGName = $roleConfig.availabilitygroupname
    
        $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($env:COMPUTERNAME)
        $AGName = $srv.AvailabilityGroups[0].Name 

        It 'should match the Availability Group name created from the config file' {
            $AGName | Should Be $configAGName
        }
    }
} 
