. ./Load-Module.ps1

InModuleScope Concur.SqlBuild{
    $parent = Split-Path $PSScriptRoot -Parent
    $pwd = ConvertTo-SecureString "AKCp5dKE3Xm42FJaCMTFLjFvVh1zdwBSqfpCFJxrSR8TmDYe4WzAaNUPtnZf6ZifyF8WCfqFH" -AsPlainText -Force
    $Credential = New-Object System.Management.Automation.PSCredential ("X-JFrog-Art-Api", $pwd)
    $src = "https://artifactory.concurtech.net/artifactory/util-sandbox-local/7-zip/7z1805-x64.msi"
    $dest = [System.IO.Path]::Combine($parent, '7z1805-x64.msi');

    Describe 'Setup'{
        Remove-Item -Path $dest -Force -ErrorAction SilentlyContinue | Out-Null
        It 'file should not exist'{
            $dest | Should -not -Exist
        }
    }

    Describe 'Get-Artifact'{
        Get-Artifact -Location $src -Destination $dest -Credential $Credential
        It 'file should exist'{
            $dest | Should -Exist
        }
    }

    Describe 'Cleanup file'{
        Remove-Item -Path $dest -Force 
        It 'should not exist'{
            $dest | Should -Not -Exist
        }
    }
}

