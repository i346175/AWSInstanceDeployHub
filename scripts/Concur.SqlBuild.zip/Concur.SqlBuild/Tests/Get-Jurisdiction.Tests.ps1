. ./Load-Module.ps1 

Describe 'Get-jurisdiction'{
    It 'should not be null or empty'{
        Get-jurisdiction | Should -Not -BeNullOrEmpty
    }

    $parent = Split-Path -Path $PSScriptRoot -Parent
    #$config = Get-Content -Path (Join-Path -Path $parent -ChildPath 'config.json') | ConvertFrom-Json
    $config = get-content -Path ([System.IO.Path]::Combine($parent, 'Config', 'config.json')) | ConvertFrom-Json
    $value = $config.jurisdiction | Where-Object{$_.location -eq (Get-jurisdiction)}
    It 'should be a valid jurisdiction'{
        $value | Should -Not -BeNullOrEmpty
    }
}