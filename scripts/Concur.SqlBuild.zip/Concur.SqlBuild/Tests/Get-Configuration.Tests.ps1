. ./Load-Module.ps1

InModuleScope Concur.SqlBuild{
    
    
    Context 'Default configuration'{
        $result = Get-Configuration 

        Describe 'Get-Configuration'{
            It 'Should not be null or empty'{
                $result | Should -Not -BeNullOrEmpty
            }
            It 'should have a jurisdiction of test'{
                $result.jurisdiction | Should -Be 'test'
            }
            It 'should have 2080 as the port'{
                $result.port | Should -Be 2080
            }
            It 'should have SEAPR1DB3016 as the ctHost server'{
                $result.cthostserver | Should -Be 'SEAPR1DB3016'
            }
        }
    }
    
}

