. ./Load-Module.ps1

InModuleScope Concur.SqlBuild{
    $result = Get-RoleTypes 
    
    Describe 'Get-RoleTypes should not be null or empty' {
        It 'Should not be null'{
            $result | Should -Not -BeNullOrEmpty
        }
        
    }
    
    Describe 'Get-RoleTypes count should be greater than 0'{
        It 'should be greater than 0'{
            $result.Count | Should -BeGreaterThan 0
        }
    }
}

