. ./Load-Module.ps1

Describe 'Add-EventLogEntry'{
    $LogName = 'Setup'
    $Source = 'SqlConfig'

	$ComputerNames = (Get-ClusterNode).Name

    foreach($Computer in $ComputerNames){
        It 'Entry - Information - should not be null or empty'{
            Get-EventLog -LogName $LogName -ComputerName $Computer -Source $Source -EntryType Information | Should Not BeNullOrEmpty
        }

        It 'Entry - Warning - should not be null or empty'{
            Get-EventLog -LogName $LogName -ComputerName $Computer -Source $Source -EntryType Warning | Should Not BeNullOrEmpty
        }
    }
}
 
