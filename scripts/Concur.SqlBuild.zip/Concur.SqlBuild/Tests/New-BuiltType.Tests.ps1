. ./Load-Module.ps1

$roleType = 'TestRole'
$parent = Split-Path -Path $PSScriptRoot -Parent
$configFiles = [System.io.Path]::Combine($parent, "Config", "RoleTypes")
$fileName = Join-Path -Path $configFiles -ChildPath "$roleType.json"

$storage = @(
        @{
            "drive"="e"
            "label"="data"
            "size"="1099511627776"
        }
        @{
            "drive"="f"
            "label"="tempdb"
            "size"="536870912000"
        }
        @{
            "drive"="g"
            "label"="log"
            "size"="536870912000"
        }        
)
$logins = @(
    @{
        "name"="database admins"
        "roles"="sysadmin"
    }
    @{
        "name"="benr"
        "roles"="sysadmin"
    }
    @{
        "name"="ussea7x"
        "roles"=""
        "sid"="123456789"
    }
)
$config = @(
    @{
        "name"="show advanced options"
        "value"="1"
    },
    @{
        "name"="optimize for ad-hoc workload"
        "value"="1"
    },
    @{
        "name"="backup compression"
        "value"="1"
    }
)
New-BuildType -Name $roleType -RoleType $roleType -Template 'CNQR-DB8-3.0' -OperatingSystem 'Windows Server 2016 Datacenter 2019-06' -Storage $storage -Logins $logins -SqlConfigurationOptions $config -Force

Describe "file creation" {
    it "tests that file $fileName exists"{
        $fileName | Should -Exist
    }   
}

Describe "New-BuiltType" {
    $result = Get-Content -Path $fileName | ConvertFrom-Json
    It "should be json format"{
        $result | Should -Not -BeNullOrEmpty
    }
}

Describe 'Test newly created role type configuration'{
    . ./Get-RoleTypeConfiguration.Tests.ps1 -Name $roleType
}

Describe "Cleanup"{
    It "should remove the file $fileName"{
        Remove-Item -Path $fileName -Force
    }
    It "file $fileName should not exist"{
        $fileName | Should -Not -Exist
    }
}

