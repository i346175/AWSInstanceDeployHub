. ./Load-Module.ps1 

Describe 'Get-Password'{
    [PSCredential]$cred = Get-Password -Name 'SW_ReadOnly' 
    It 'should not return null or empty'{
        $cred | Should -Not -BeNullOrEmpty
    }

    It 'should have a password'{
        $cred.Password | Should -Not -BeNullOrEmpty
    }

    It 'should have a login name'{
        $cred.UserName | Should -Not -BeNullOrEmpty
    }
}