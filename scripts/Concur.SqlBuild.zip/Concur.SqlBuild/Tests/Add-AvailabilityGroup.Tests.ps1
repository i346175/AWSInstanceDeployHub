. .\Load-Module.ps1

InModuleScope Concur.SqlBuild{
	
	$ComputerName = (Get-ClusterNode).Name
	
	Describe 'Test Add-AvailabilityGroup success' {
		$agExists = (Get-AvailabilityGroup -ComputerName $ComputerName).Name[0]
		It 'should not be null or empty'{
        		$agExists | Should Not BeNullOrEmpty
    		}

    		It 'should return a string value'{
        		$agExists | Should BeOfType [string]
    		}

    		it 'should have a count greater than 0'{
        		$agExists.length | Should  BeGreaterThan 0
    		}
	}
}