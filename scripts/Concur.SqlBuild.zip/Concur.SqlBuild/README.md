# Concur.SQLBuild
All changes need to be uploaded to AWSInstanceDeployHub repository so that they are promoted directly to S3 bucket for DCP provisioning!
Whole module needs to be in zip format!

Folder to upload to: https://github.concur.com/impact/AWSInstanceDeployHub/tree/main/scripts

Concur Sql Build Module

## History

```text
Date        Ticket#     Description
7/19/2022   CSCI-4014   Add SQL Audit script
8/18/2022   CSCI-4154   Changed CommandLog retention from 374 to 7
8/26/2022   CSCI-4206   Changed retention for TLOG backups from 168 to 48 hours
2/1/2023    CSCI-1751   One-off SQL Config scripts addition
2/2/2023    CAM-2301    Update Add-DNSCame.ps1
2/3/2023    CAM-2302    One-off bug fix to address domainless CTHOST connect logic
2/7/2023    CSCI-5447   Fix for eOperations DB restore script
2/10/2023   CSCI-5403   Code change to add TF 3459 for AG clusters (Change in /Invoke-SqlDefaultConfiguration.ps1)
3/1/2023    CSCI-5452   Create reportmigration CNames under phz- reportmigration.us2.cnqr.tech
3/2/2023    CSCI-5347   Removing the Trace flags which are not required on SQL2019 boxes.
3/23/2023   CSCI-5569   S3 sync job step logic enhancement
4/11/2023   CSCI-5740   CTP value changed to 200 for Expense and Spend-Impl servers.
4/17/2023   CSCI-5870   Granted 'lock pages in memory' to sql service account
4/28/2023   CSCI-5895   Bug fixes to fix Listener creation and change Secondary replica mode to SYNC
5/2/2023    CSCI-5893   DCP sa login creation script added which is required by EBSSwap automation workflow
5/26/2023   CSCI-5949   Add missing post-build One-off scripts
6/2/2023    CAM-2464    Changed add-listener to utilize primary node instead of all nodes.
6/5/2023    CSCI-6009   Code addition for adding SQLListener EC2 Tag
6/5/2023    CSCI-6013   Skip creation additional C-records in reportmigration.<envt>.cnqr.tech PHZ
6/7/2023    CSCI-6032   Change the MaxServerMemory setting by changing the amount of memory to leave for OS
6/20/2023   CSCI-6055   Skip C-record creation if C-name contains DUMMY keyword in it.
7/25/2023   CSCI-6183   Skip CTH configurations for Exp, Rpt and Imple servers, if C-name contains DUMMY keyword in it.
8/16/2023   CAM-2603    Fix for SQL Listener creation failure due to AG unavailability
8/24/2023   CSCI-6357   Fix for SQL Listener creation failure possibly due to lag in DC replication. (do not need above code changes made under CAM-2603)
8/29/2023   CSCI-6367   Added logic to cleanup out of date backup files on M: and change DIFF retention to 2 days on M: drive.
9/13/2023   OPI-5769121 Change log retention period on M: from 48 hours to 36 hours.
10/24/2023  OPI-5786481 PSCC Database Authentication - user sa_pscc_tenable_db needs DB roles to conduct CIS and STIG scans per FedRAMP requirements
11/7/2023   CSCI-6518   Added dbFormationSrvRole creation script
11/20/2023  CSCI-6529   Set up directory aws-sql-clr, and put scripts about database awsopsdb there. Also remove USPSCC\I846083 since the user is deactiviated
2/2/2024    CSCI-6705   Remove Database Admins from Local Administrators group
2/27/2024   CSCI-6763   Remove DNS suffix for reporting DB servers entries in CTHOST from the one-off scripts
3/8/2024    ISBN-CLOPS16328 Add-EventLogEntry was modified to log locally instead of logging to event log, due to permissions/access issues.
3/11/2024   CSCI-6736   Add non DBA AD groups to list of logins(to one-off scripts) to be created on US2,EU2,APJ1 servers
3/13/2024   CSCI-6806   Tempdb data file size fix to address rounding issue.
3/21/2024   CSCI-6833   Modified FW rules to utilize SQL Admin port as being EnvPort# + 1
4/1/2024    CSCI-6914   Added database health detection
4/1/2024    CSCI-3615   Granted AG group CREATE ANY DATABASE for seeding purposes (not automatic seeding...)
4/10/2024   CSCI-6950   Added tags to metadata info
4/10/2024   CSCI-6953   Added environment variable for VPCName 
4/16/2024   CSCI-6982   Corrected -UseBasicParsing missing for enabling metadata tag
5/6/2024    CSCI-5441   Update CTHOST linked server code on Exp/Impl servers to NOT use remote login
05/07/2024  CSCI-7044   Removed msdb..backupset.IX_BACKUPSET_MEDIA_SET_ID index 
05/15/2024  CSCI-6918   Merging Apj1 branch + cleaning + AWSInstanceDeployHub settings for provisioning with DCP tool
05/15/2024  CSCI-6917   Enabled ServerAudit in CCPS only and log it to file on M-drive.
05/16/2024  CSCI-6918   Fix of reporting deploy.ps1. Credentials to connect to cthost
05/28/2024  CSCI-7034   Add feature to add required server(s) to SQL account Delegation list
05/30/2024  CSCI-7015   Hide sql instance (if not cluster)
05/30/2024  CSCI-7016   Set all ports to be (20xx); No port should be 1433...

```

## Usage

```powershell
cls

Import-Module Concur.SqlBuild -Force -DisableNameChecking


$ComputerName = "EC2AMAZ-KBC0DID
EC2AMAZ-UPCAGLC
EC2AMAZ-300MMLI" -split "`r`n"

$Credential = Get-Credential -Message “Enter your password” -UserName ($env:USERNAME.ToLower())
$ComputerName | Invoke-SqlConfiguration -Credential $Credential
Invoke-RoleConfiguration -ComputerName $ComputerName -Name ‘dbsql’ -Credential $Credential



```

## Notes

### Proxy

The install process will disable the proxy for the current session when this module is loaded.  This module does not function correctly with a proxy enabled.

### Accounts

#### mssqlSPN_write 

This ad group is has permissions to create SPNs for the servers being built.  The **sa_dba_prov** account requires membership in this group to successfully execute the build.  If you have a need to debug this process, you should add your account to this group as well.

#### mssql_provisioning

This ad group is has permissions to create computer objects in the ou ` OU=DB Cluster Names,OU=Servers,OU=(env),DC=(env),DC=system,DC=cnqr,DC=tech 
` for the servers being built.  The **sa_dba_prov** account requires membership in this group to successfully execute the build.  If you have a need to debug this process, you should add your account to this group as well.
