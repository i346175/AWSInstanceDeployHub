function Add-AltDNSCName {
        param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [ValidateNotNull()]
        [string]$CNameValue
    )

    $localData = Get-WmiObject -Namespace root\cimv2 -Class Win32_ComputerSystem | Select-Object Name, Domain  
    $env:https_proxy = (Get-ItemPropertyValue -Path "HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings\" -Name "ProxyServer").split('//')[-1]

    $CNameArray = $CNameValue.split(".")
    $AltDomain = ('{0}.{1}.{2}.{3}' -f $CNameArray[1],$env:aws_envt,$CNameArray[2],$CNameArray[3])
    $AltCNameValue = $CNameArray[0] + "." + $AltDomain
    
    $AlthostedZone = ( aws route53 list-hosted-zones-by-name --dns-name $AltDomain --max-items 1 --no-verify-ssl ) | ConvertFrom-Json

    if(!$AltHostedZone)
    {
        $localData.Name |  Add-EventLogEntry -Message "This script cannot continue due to inability to query AWS for $AltHostedZone Hosted Zones. Exiting."
    }

	$AlthostedZoneID = ($AlthostedZone.HostedZones.ID).split('/')[-1]

    $pathtoCnameTemplate = "C:\\mssql-scripts\\dnsCRecordPayload.json"
    $pathtoAltCnameFile = "D:\\dnsAltCRecordPayload.json"
    ((Get-Content -Path $pathtoCnameTemplate -Raw) -replace 'hostfqdn',$CNameValue) | Set-Content -Path $pathtoAltCnameFile
    ((Get-Content -Path $pathtoAltCnameFile -Raw) -replace 'cnameShort',$AltCNameValue) | Set-Content -Path $pathtoAltCnameFile

    $TestCName = $AltCNameValue + "." 
    $TestAltCName = (aws route53 list-resource-record-sets --hosted-zone-id $AlthostedZoneID --query "ResourceRecordSets[?Name == '$TestCName']" --no-verify-ssl ) | ConvertFrom-Json
    if($TestAltCName){
        $localData.name | Add-EventLogEntry -EntryType Error -Message "CName $AltCNameValue already existing in PHZ $AlthostedZoneID. Exiting."
            return
    }
    $status = (aws route53 change-resource-record-sets --hosted-zone-id $AlthostedZoneID --change-batch file://$pathtoAltCnameFile --no-verify-ssl ) | ConvertFrom-Json
    $status
    if([bool]$status){
                    $localData.Name |  Add-EventLogEntry -Message  "Report Migration Cname $AltCNameValue successfully created."
    }  
    else{
                    $localData.Name |  Add-EventLogEntry -Message  "Report Migration Cname $AltCNameValue failed to create."
    }
}

 
