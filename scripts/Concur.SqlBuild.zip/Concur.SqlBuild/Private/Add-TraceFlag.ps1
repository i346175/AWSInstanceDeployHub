function Add-TraceFlag{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [string[]]$TraceFlag
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")

        $config = Get-Configuration 
    }
    process{

        foreach($Computer in $ComputerName){

            Invoke-Command -ComputerName $Computer -ScriptBlock{
                $hklmRootNode = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server"
    
                $props = Get-ItemProperty "$hklmRootNode\Instance Names\SQL"
                $instances = $props.psobject.properties | ?{$_.Value -like 'MSSQL*'} | Select-Object Value
    
                $instances | ForEach-Object{
                    $inst = $_.Value;
                    $regKey = "$hklmRootNode\$inst\MSSQLServer\Parameters"
                    $props = Get-ItemProperty $regKey
                    $params = $props.psobject.properties | Where-Object{$_.Name -like 'SQLArg*'} | Select-Object Name, Value
                    [int]$paramCount = $params.Count
                    $using:TraceFlag | ForEach-Object{
                        $hasFlag = $false
                        $flag = "-T$_"
                        foreach ($param in $params) {
                            if($param.Value -eq $flag) {
                                $hasFlag = $true
                                break;
                            }
                        }
                        if (-not $hasFlag) {
                            write-verbose "Adding $flag"
                            $newRegProp = "SQLArg$paramCount"
                            Set-ItemProperty -Path $regKey -Name $newRegProp -Value $flag
                            $paramCount++;
                        } else {
                            write-verbose "$flag already set"
                        }
                    }
                }
    
                Restart-Service -Name MSSQLSERVER -Force | Out-Null
                Start-Service -Name SQLSERVERAGENT
                
            }
        }

    }
    end{

    }
}