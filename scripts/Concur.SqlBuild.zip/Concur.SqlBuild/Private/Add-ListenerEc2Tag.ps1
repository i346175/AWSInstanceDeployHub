function Add-ListenerEc2Tag{
    <#
    .SYNOPSIS
    Create SQL Listener EC2 Tags 
    
    .DESCRIPTION
    Create SQL Listener EC2 Tags     
    
    .PARAMETER ComputerName
    The name(s) of the computers to configure
    
    .PARAMETER ListenerName
    The SQL Listener for the cluster
    
    .EXAMPLE
    Add-ListenerEc2Tag -ComputerName $ComputerName -ListenerName $SQLListener
    
    .NOTES
    General notes
    #>
    
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$ListenerName
    )
    begin{
        $env:https_proxy = ''
    }
    process{
        try{
            $instIDs = $(aws ec2 describe-instances --filters Name=tag:HostName,Values=$($ComputerName -join ",") | ConvertFrom-Json).Reservations.Instances.InstanceId
            aws ec2 create-tags --resources $instIDs --tags Key=SQLListener,Value=$ListenerName
            $ComputerName |  Add-EventLogEntry -Message  "EC2 Tag [SQLListener] successfully created."
        }
        catch{
            $ComputerName | Add-EventLogEntry -EntryType Error -Message "There was an error while creating SQL Listener EC2 Tag.`r`nDetailed Exception:$($_ | Format-List -Force | Out-String)"
        }
    }
    end{
    }
}