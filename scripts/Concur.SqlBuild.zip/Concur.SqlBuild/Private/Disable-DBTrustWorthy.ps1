function Disable-DBTrustworthy{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
    }
    process{
        foreach($Computer in $ComputerName){
            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                foreach($Database in $srv.Databases | Where-Object{!$_.IsDatabaseSnapshot -and $_.Name -notin @('model', 'tempdb') -and $_.Status -eq [Microsoft.SqlServer.Management.Smo.DatabaseStatus]::Normal}){
                    $Database.TrustWorthy = $false;
                    $Database.Alter();
                }
            }
            catch{
                $Computer | Add-EventLogEntry -EntryType Warning -Message "There was an error disabling trustworthyness on database $($Database.Name).`r`nDetailed Exception:`r`n$($_ | Format-List -Force | Out-String)"
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }
    }
    end{

    }
}