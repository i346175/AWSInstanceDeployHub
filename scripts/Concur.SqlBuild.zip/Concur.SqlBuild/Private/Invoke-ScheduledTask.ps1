function Invoke-ScheduledTask{
<#
.SYNOPSIS
Create a scheduled task on a remote computer and execute said task

.DESCRIPTION
Create a scheduled task on a remote computer and execute said task

.PARAMETER Computername
The name of the computer you want to create the scheduled task on

.PARAMETER Credential
The credential to use to both create and execute the scheduled task as

.PARAMETER ScriptBlock
The script you want to execute for this task

.PARAMETER TaskName
The name of the task

.PARAMETER Wait
Wait for the task to complete before returning

.PARAMETER TimeoutMinutes
Number of minutes to wait for the scheduled task before timing out

.PARAMETER SleepSeconds
Number of seconds to sleep between checking the status of the scheduled task

.EXAMPLE
Invoke-ScheduledTask -ComputerName SEAPR1DB1001 -Credential (get-Credential) -ScriptBlock {Test-Cluster} -Wait

.NOTES
General notes
#>
    param(
        [Alias('ServerName', 'CN')]
        [Parameter(Mandatory=$true, ValueFromPipeline=$false)]
        [string]$Computername,
        [Parameter(Mandatory)]
        [PSCredential]$Credential,
        [Parameter(Mandatory)]
        [ScriptBlock]$ScriptBlock,
        [string]$TaskName = "ScheduledTask_$([GUID]::new().ToString())",
        [switch]$Wait,
        [int]$TimeoutMinutes = 30,
        [int]$SleepSeconds = 120
    )

    Set-StrictMode -Version Latest

    $username = $Credential.Username
    $password = $Credential.GetNetworkCredential().Password

$script = @"
schtasks /CREATE /TN '$TaskName' /SC WEEKLY /RL HIGHEST ``
    /RU $username /RP $password ``
    /TR "$($ScriptBlock.ToString())" /F

schtasks /RUN /TN '$($TaskName)'
"@

    ## Create the task on the remote system to configure CredSSP
    $command = [ScriptBlock]::Create($script)
    Invoke-Command $computername $command -Cred $Credential

    if($Wait){
        Invoke-Command -ComputerName $Computername -ScriptBlock{
            $start = Get-Date
            While(((schtasks.exe /query /TN "$using:Taskname" /FO CSV | ConvertFrom-Csv | Select-Object -expandproperty Status -first 1) -eq "Running")){
                if((New-TimeSpan -Start $start -End (get-date)).Minutes -gt $TimeoutMinutes){
                    throw "Scheduled task $($using:TaskName) is not responding after $TimeoutMinutes minutes."
                }
                Start-Sleep -Seconds $SleepSeconds
            }
        }
    }

    Invoke-Command $computername {
        schtasks /DELETE /TN `'$TaskName`' /F
    } -Cred $Credential


}

