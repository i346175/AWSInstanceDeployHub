function Format-LoginName{    
    <#
    .SYNOPSIS
    Formats a login name to either strip or add domain information based upon the DomainType
    
    .DESCRIPTION
    Formats a login name to either strip or add domain information based upon the DomainType
    
    .PARAMETER Name
    The name of the login to format
    
    .PARAMETER Separator
    The domain separator, either '@' or '\'
    
    .PARAMETER DomainType
    Whether to strip the domain, add only the domain name, or to fully-qualify the domain
    
    .EXAMPLE
    $Name | Format-LoginName -DomainType FQDN 
    #-->  Returns domain.com\Name
    
    .EXAMPLE
    $Name | Format-LoginName -DomainType DN 
    #-->  Returns domain\Name

    .EXAMPLE
    $Name | Format-LoginName -Separator @
    #-->  Returns username@domain.com

    .NOTES
    I detest this function.  There MUST be a better way to do this...
    #>
    
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [Alias('LoginName')]
        [string[]]$Name,
        [ValidateSet('\', '@')]
        [string]$Separator = '\',
        [ValidateSet('NoDomain', 'FQDN', 'DN')]
        [string]$DomainType = 'NoDomain'
    )
    begin{
        $objects = New-Object System.Collections.Generic.List[string]
    }
    process{

        foreach($loginName in $Name){

            if($loginName.Contains('\')){
                $loginName = $loginName.Split('\')[1]
            }
            elseif($loginName.Contains('@')){
                $loginName = $loginName.Split('@')[0]
            }

            #if @ has been set, just put it to username@domain.com...anything else is not a valid format...
            if($Separator -eq '@'){
                [void]$objects.Add("$loginName$('@')$(Get-Domain)");
                return;
            }

            #the separator at this point, MUST be '\'
            switch($DomainType){
                'NoDomain'{
                    [void]$objects.Add($loginName);
                }
                'FQDN'{
                    [void]$objects.Add("$(Get-Domain)\$loginName")
                }
                'DN'{
                    $domain = Get-Domain
                    [void]$objects.Add("$($domain.substring(0, $domain.indexof('.')))\$loginName");
                }
            }
        }
    }
    end{
        return $objects
    }
}