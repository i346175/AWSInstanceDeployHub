function Add-ProxyAccount{
    <#
    .SYNOPSIS
    Adds a proxy and automatically creates a credential if one does not exist to add to the proxy
    
    .DESCRIPTION
    Adds a proxy and automatically creates a credential if one does not exist to add to the proxy
    
    .PARAMETER ComputerName
    The name(s) of the computers on which to create the proxy accounts
    
    .PARAMETER Name
    The name of the proxy 

    .PARAMETER AccountName
    The name of the credential this proxy will use.  
    The cmdlet will test to see if the credential exists and will automatically add it if it does not.

    .PARAMETER SubSystem
    The subsystems that this proxy will have access to.  
    The Values must be one of the following:
    TransactSql, ActiveScripting, CmdExec, Snapshot, LogReader, Distribution, Merge, QueueReader, AnalysisQuery, AnalysisCommand, Ssis, PowerShell

    .EXAMPLE
    $ComputerName | Add-ProxyAccount -Name 
    
    .NOTES
    General notes
    #>
    
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$Name,
        [Parameter(Mandatory)]
        [string]$AccountName,
        [Parameter(Mandatory)]
        #[ValidateSet('TransactSql', 'ActiveScripting', 'CmdExec', 'Snapshot', 'LogReader', 'Distribution', 'Merge', 'QueueReader', 'AnalysisQuery', 'AnalysisCommand', 'Ssis', 'PowerShell')]
        [string[]]$SubSystem

    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Management.Smo.Agent")
    }
    process{
        foreach($Computer in $ComputerName){
            try{
                $srv = New-Object Microsoft.SqlServer.Management.Smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                if($srv.JobServer.ProxyAccounts[$Name]){
                    $Computer | Remove-ProxyJob -ProxyName $Name
                    $srv.JobServer.ProxyAccounts[$Name].Drop();
                    $srv.JobServer.ProxyAccounts.Refresh();
                    #$Computer | Add-EventLogEntry -EntryType Warning -Message "The proxy $Name already exists on computer $Computer."
                    #return;
                }
                #if no credential for the $AccountName, Add one
                if(!$srv.Credentials[($AccountName | Format-LoginName -DomainType DN)]){
                    try{
                        $account = Get-Password -Name $AccountName
                    }
                    catch{
                        $Computer | Add-EventLogEntry -EntryType Warning -Message "Could not retrieve the credentials for account $AccountName on computer $Computer."
                        return;
                    }
                    $cred = New-Object Microsoft.SqlServer.Management.smo.Credential $srv, ($AccountName | Format-LoginName -DomainType DN)
                    $cred.Create(($AccountName | Format-LoginName -DomainType DN), $account.Password);
                    $srv.Credentials.Refresh();
                }

                $proxyAccount = New-Object Microsoft.SqlServer.Management.Smo.Agent.ProxyAccount ($srv.JobServer, $Name, ($AccountName | Format-LoginName -DomainType DN))
                $proxyAccount.Create();
                foreach($sub in $SubSystem){
                    if(!([Microsoft.SqlServer.Management.Smo.Agent.AgentSubSystem].GetEnumNames() | Where-Object{$_ -eq $sub})){
                        $Computer | Add-EventLogEntry -EntryType Warning -Message "The subsystem $sub for proxy $Name on computer $Computer is not a valid proxy subsystem name.`r`nIt should be one of the following:  $([Microsoft.SqlServer.Management.Smo.Agent.AgentSubSystem].GetEnumNames() -join ', ')"
                        return;
                    }
                    $proxyAccount.AddSubSystem([Microsoft.SqlServer.Management.Smo.Agent.AgentSubSystem]$sub);
                }
                #$srv.JobServer.ProxyAccounts.Add($proxyAccount);
                $srv.JobServer.ProxyAccounts.Refresh();
            }
            catch{
                if($srv.ProxyAccount[$Name]){
                    $srv.ProxyAccount[$Name].Drop();
                }
                throw $_ 
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }
    }
    end{

    }
}