function Test-ADAccount{
    <#
    .SYNOPSIS
    Tests whether or not an account or group exists
    
    .DESCRIPTION
    Tests whether or not an account or group exists
    
    .PARAMETER Name
    The name of the account to test.  It can be a group or user.
    
    .EXAMPLE
    if(Test-ADAccount -Name 'snewman'){
        "Gah, NEWMAN still works here..."
    }
    
    .NOTES
    General notes
    #>
    
    [cmdletbinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Name
    )

    $Name = $Name | Format-LoginName -DomainType NoDomain 
    if(!(Get-ADObject -Filter {(sAMAccountName -eq $Name)} -ErrorAction SilentlyContinue)){
        return $false
    }

    return $true
}