function Add-AvailabilityGroup{
    <#
    .SYNOPSIS
    Adds an availability group to the computers
    
    .DESCRIPTION
    Adds an availability group to the computers
    
    .PARAMETER ComputerName
    The names of the computers to add as replicas to the availability group
    
    .PARAMETER Name
    The name of the availability group
    
    .EXAMPLE
    Add-AvailabilityGroup -ComputerName $Computers -Name Expense
    
    .NOTES
    The first $ComputerName passed in will be the primary.  The last one will be set to be the asynch node and will not allow connections, due to licencing costs.
    #>
    
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$Name,
        [switch]$DatabaseHealthTrigger
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
    }
    process{

        $ComputerName | Enable-Hadr 
        try{
            $ComputerName | Add-EventLogEntry -Message "Initializing AG Creation."
            $primary = $ComputerName | Select-Object -First 1
            $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($primary | Format-ServerName -AddPort)
            if($srv.AvailabilityGroups[$Name]){
                $ComputerName | Add-EventLogEntry -EntryType Warning -Message "The AvailabilityGroup $Name already exists."  
                return;
            }
            $grp = New-Object Microsoft.SqlServer.Management.smo.AvailabilityGroup $srv, $Name 
            $grp.AutomatedBackupPreference = [Microsoft.SqlServer.Management.smo.AvailabilityGroupAutomatedBackupPreference]::Primary

            if($DatabaseHealthTrigger){  #csci-6914
                $grp.DatabaseHealthTrigger = $true;
            }

            [int]$i = 0;
            foreach($Replica in $ComputerName){
                $ComputerName | Add-EventLogEntry -Message "Configuring $replica."
                $i++;
                $rep = new-object Microsoft.SqlServer.Management.smo.AvailabilityReplica $grp, "$Replica"
                $rep.EndpointUrl = "TCP://$Replica.$(Get-Domain):5022"

                if($grp.AvailabilityReplicas[$Replica]){
                    $ComputerName | Add-EventLogEntry -EntryType Warning -Message "AvailabilityReplica $Replica already exists in group $($grp.Name)."
                    continue;
                }

                #first time through, go ahead and add me before doing the checks below...
                # Condition [$i -eq 2] added to add 2nd node of 2-node build as SYNC node. Ref CSCI-5895
                if($i -lt $ComputerName.Count -or $i -eq 2){
                    $rep.FailoverMode = [Microsoft.SqlServer.Management.smo.AvailabilityReplicaFailoverMode]::Automatic
                    $rep.AvailabilityMode = [Microsoft.SqlServer.Management.smo.AvailabilityReplicaAvailabilityMode]::SynchronousCommit
                    $rep.ConnectionModeInPrimaryRole = [Microsoft.SqlServer.Management.smo.AvailabilityReplicaConnectionModeInPrimaryRole]::AllowAllConnections
                    $rep.ConnectionModeInSecondaryRole = [Microsoft.SqlServer.Management.smo.AvailabilityReplicaConnectionModeInSecondaryRole]::AllowAllConnections
                }  #last computer always becomes the DR node...
                else{
                    $rep.FailoverMode = [Microsoft.SqlServer.Management.smo.AvailabilityReplicaFailoverMode]::Manual
                    $rep.AvailabilityMode = [Microsoft.SqlServer.Management.smo.AvailabilityReplicaAvailabilityMode]::AsynchronousCommit
                    $rep.ConnectionModeInPrimaryRole = [Microsoft.SqlServer.Management.smo.AvailabilityReplicaConnectionModeInPrimaryRole]::AllowAllConnections
                    $rep.ConnectionModeInSecondaryRole = [Microsoft.SqlServer.Management.smo.AvailabilityReplicaConnectionModeInSecondaryRole]::AllowNoConnections  #allow no connections so we don't get nailed with licencing...
                }
                #join the replica to the group
                [void]$grp.AvailabilityReplicas.Add($rep);
            }
            $grp.Create();

            #The above statement will NOT BLOODY SET THIS.  This is the only way I can seem to make this stick... (it won't even stick in ssms...)
            [void]$srv.ConnectionContext.ExecuteNonQuery("ALTER AVAILABILITY GROUP [$($grp.Name)] SET (AUTOMATED_BACKUP_PREFERENCE = PRIMARY)");

            #create readonly routing list for primary 
            $join = new-object System.Collections.Generic.List[string]
            foreach($Replica in $grp.AvailabilityReplicas | Where-Object{$_.AvailabilityMode -eq [Microsoft.SqlServer.Management.Smo.AvailabilityReplicaAvailabilityMode]::SynchronousCommit}){
                [void]$join.Add($Replica.Name);
            }
            [void]$join.Add($primary);
            # $primReplica = $grp.AvailabilityReplicas[$grp.PrimaryReplicaServerName]
            # $primReplica.ReadonlyRoutingConnectionUrl = "TCP://$($grp.PrimaryReplicaServerName).$(Get-Domain):5022"
            # $primReplica.ReadonlyRoutingList = $join
            # $primReplica.Alter();

            #join replicas and set readonly routing for secondaries
            foreach($Replica in $ComputerName | Where-Object{$_ -ne $primary}){
                $rSrv = New-Object Microsoft.SqlServer.Management.smo.Server ($Replica | Format-ServerName -AddPort)
                $rSrv.ConnectionContext.TrustServerCertificate = $true;
                $rSrv.JoinAvailabilityGroup($Name);
                # if($grp.AvailabilityReplicas[$Replica].AvailabilityMode -eq [Microsoft.SqlServer.Management.smo.AvailabilityReplicaAvailabilityMode]::SynchronousCommit){
                #     $rep.ReadonlyRoutingConnectionUrl = "TCP://$Replica.$(Get-Domain):5022"
                #     $rep.ReadOnlyRoutingList = $Replica,$primary;
                #     $rSrv.Alter();
                # }
                <#
                if($srv.AvailabilityGroups[$Name].AvailabilityReplicas[$Replica]){
                    #$ComputerName | Add-EventLogEntry -EntryType Warning -Message "Availablity replica $Replica already exists in availability group $Name."
                    return;
                }
                #>
                $rSrv.ConnectionContext.Disconnect();
            }

            # give the AG permission to create any database for seeding purposes (CSCI-6915)
            foreach($replica in $srv.AvailabilityGroups[0].AvailabilityReplicas){
                $replicaName = $replica.Name 
                $rSrv = New-Object Microsoft.SqlServer.Management.smo.Server ($replicaName | Format-ServerName -AddPort)
                $rSrv.ConnectionContext.TrustServerCertificate = $true;
                [void]$rSrv.ConnectionContext.ExecuteNonQuery("ALTER AVAILABILITY GROUP [$Name] GRANT CREATE ANY DATABASE;");
                $rSrv.ConnectionContext.Disconnect();
            }

        }
        catch{
            $_ |  Format-List -Force 
            $ComputerName | Add-EventLogEntry -EntryType Error -Message "There was an error adding availability group $Name on computer $ComputerName.`r`nDetailed Exception:`r`n$($_ | Format-List -Force | Out-String)" -throw 
        }
        finally{
            if($srv){
                $srv.ConnectionContext.Disconnect();
            }
        }
    }
    end{

    }
}