function Get-SqlDefaultConfiguration{
    [cmdletbinding()]
    param(

    )
    begin{

    }
    process{
        $parent = Split-Path -Path $PSScriptRoot -Parent
        $ConfigFile = [System.IO.Path]::Combine($parent, 'Config', 'baseInstall.json');
        if((Get-Jurisdiction) -eq 'test'){
            $ConfigFile = [System.IO.Path]::Combine($parent, 'Config', 'baseInstall.test.json');
        }
        return (get-content -Path $ConfigFile | ConvertFrom-Json)
    }
    end{
        
    }
}