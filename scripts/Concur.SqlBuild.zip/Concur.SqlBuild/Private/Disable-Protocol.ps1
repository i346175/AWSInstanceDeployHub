function Disable-Protocol{
    <#
      .SYNOPSIS
      Disables a SQL Server protocol and restarts SQL Server
      
      .DESCRIPTION
      This will disable either Named Pipes, Shared Memory or the TCP protocol for the default SQL Server instance
      and restart the SQL Server service to make the changes take effect
      
      .PARAMETER ComputerName
      The name(s) of Computer(s) to run against
      
      .PARAMETER Protocol
      The name of the protocol to disable - 'NM' (Named Pipes), 'SM' (Shared Memory), 'TCP'
      
      .EXAMPLE
      PS> Disable-Protocol -ComputerName SEAPR1DBBAT083 -Protocol NP
      
      .EXAMPLE
      PS> Disable-Protocol -ComputerName SEAPR1DBBAT083 -Protocol SM 
  
      .EXAMPLE
      PS> Disable-Protocol -ComputerName SEAPR1DBBAT083 -Protocol TCP
  
      .EXAMPLE
      PS> Disable-Protocol -ComputerName SEAPR1DBBAT083,SEAPR1DBBAT082 -Protocol NP
  
      .NOTES
      Disabling Shared Memory on a AlwaysOn cluster can prevent the AG coming online
      #>
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName, 
        [ValidateSet('SM','TCP','NP')]
        [string]$Protocol
    )
    begin{

    }
    process{

        foreach($Computer in $ComputerName){

            $Computer | Add-EventLogEntry -EntryType Verbose -Message "Disabling protocol $Protocol on server $Computer and restarting SQL Server service..."

            Invoke-Command  -ComputerName $Computer -ScriptBlock{
                [system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
                [system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SqlWmiManagement") | Out-Null

                $wmi = New-Object Microsoft.SqlServer.Management.smo.WMI.ManagedComputer $env:COMPUTERNAME
                
                $uri = "ManagedComputer[@Name='$env:COMPUTERNAME']/ServerInstance[@Name='MSSQLSERVER']/ServerProtocol[@Name='$using:Protocol']" 
                $prot = $wmi.GetSmoObject($uri)
                $prot.IsEnabled = $false  
                $prot.Alter() 

                #this function can't be used in the invoke-command, the Add-EventLogEntry only exists on the computer that is calling the invoke-command
                #remember, invoke-command is executing all the commands inside of it ON the remote computer
                #Add-EventLogEntry -EntryType Verbose -Message "SQL Server protocol $using:Protocol disabled on server $using:Computer"
                #Add-EventLogEntry -EntryType Verbose -Message "Restarting SQL Server Service on $using:Computer."
                
                Get-Service -Name MSSQLSERVER | Restart-Service -Force | Out-Null
                Start-Service -Name SQLSERVERAGENT 
            }

            $timer = [Diagnostics.Stopwatch]::StartNew()
            while(!(Get-Service -ComputerName $Computer -Name SQLSERVERAGENT -ErrorAction SilentlyContinue | Where-Object{$_.Status -eq 'Running'})){
                Start-Sleep -Seconds 5
                if($timer.Elapsed.TotalMinutes -gt 5){  
                    $timer.Stop();
                    $Computer | Add-EventLogEntry -EntryType Warning -Message "A time out occurred while trying to start the SqlServerAgent service on $Computer."
                    return;
                }
                try{
                    Invoke-Command -ComputerName $Computer -ScriptBlock{
                        Get-Service SQLSERVERAGENT | Start-Service 
                    }
                }
                catch{
                    $Computer | Add-EventLogEntry -EntryType Warning -Message "There was an error in trying to restart the sql server agent on computer $Computer"
                }
            }

        }
    }
    end{
  
    }
}