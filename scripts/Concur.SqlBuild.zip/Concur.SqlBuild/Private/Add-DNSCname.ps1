function Add-DNSCName {
    param (
        [Parameter(Mandatory)][bool]$listener
    )
    $Zones= @(
    "front.cnqr.tech.",
    "imaging.cnqr.tech.",
    "report.cnqr.tech.",
    "reportmigration.cnqr.tech.",
    "spend.cnqr.tech.",
    "travel.cnqr.tech.",
    "tools.cnqr.tech."
    )
    $localData = Get-WmiObject -Namespace root\cimv2 -Class Win32_ComputerSystem | Select-Object Name, Domain    
    $env:https_proxy = (Get-ItemPropertyValue -Path "HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings\" -Name "ProxyServer").split('//')[-1]
    # Commenting out the usage of an environment variable, and replacing with a registry key.
    $cname = $env:r53cname
    #$camConfig = Get-ItemProperty "HKLM:\SOFTWARE\camConfig"
    #Write-Host "$camConfig"
    #Write-Host "The cname is set to $cname."
    #$cname = $camConfig.R53listenerCname
    

    #Condition added as part of CSCI-6055
    if($cname.ToLower() -like "*dummy*"){ 
        Write-Information "CName [$cname] contains the keyword DUMMY and hence the Route53 C-record creation is SKIPPED."
        return;
    }
    else{
        $HostedZones = (aws route53 list-hosted-zones-by-name --no-verify-ssl) | ConvertFrom-Json
        if(!$HostedZones)
        {
            $localData.Name |  Add-EventLogEntry -Message "This script cannot continue due to inability to query AWS for Hosted Zones. Exiting."
        }
        foreach($hz in $HostedZones.HostedZones)
            {
            foreach($z in $Zones)
                {
                if($hz.Name -contains $z)
                    {
                    $dnsRealm = $hz.Name
                    $HostedZoneId = ($hz.Id).split('/')[-1]
                    }
                }
        }
        # Add check on whether or not record exists before attempting to create.
        if($listener)
        {
            $listenerRegName = Get-ItemPropertyValue -Path "HKLM:\Software\CamConfig\" -Name listener_name
            if($listenerRegName)
            {
                if($listenerRegName -contains ".")
                {
                $CNameHostValue = ($listenerRegName).split(".")[0] + "." + $localData.Domain    
                }
                else{
                $CNameHostValue = $listenerRegName + "." + $localData.Domain
                }
            }
            else {
                $localData.name | Add-EventLogEntry -EntryType Error -Message "listener_name not found in registry. Exiting."
                return
            }
        }
        else {
            $CNameHostValue = $localData.Name + "." + $localData.Domain
        }
        if($cname -contains ".")
        {
            $CNameValue = $cname.split(".")[0]
        }
        else {
            $CNameValue = $cname + "." + $dnsRealm
        }
        $pathtoCnameTemplate = "C:\\mssql-scripts\\dnsCRecordPayload.json"
        $pathtoCnameFile = "D:\\dnsCRecordPayload.json"
        ((Get-Content -Path $pathtoCnameTemplate -Raw) -replace 'hostfqdn',$CNameHostValue) | Set-Content -Path $pathtoCnameFile
        ((Get-Content -Path $pathtoCnameFile -Raw) -replace 'cnameShort',$CNameValue) | Set-Content -Path $pathtoCnameFile
        $creationResults = (aws route53 change-resource-record-sets --hosted-zone-id $HostedZoneId --change-batch file://$pathtoCnameFile --no-verify-ssl) | ConvertFrom-Json
        if([bool]$creationResults)
            {
                $localData.Name |  Add-EventLogEntry -Message  "Cname $cname successfully created."
                <# Commented this code as we no longer need C-records in .reportmigration.<envt>.cnqr.tech; Ref: CSCI-6013 
                    if($dnsRealm -like "reportmigration*")
                    {
                        Add-AltDNSCName -CNameValue $CNameValue
                    } 
                #>
            }
        else{
                $localData.Name |  Add-EventLogEntry -Message  "Cname $cname failed to create."
            }  
    }  
}