function Get-ComputerSubNetMask{
    param(
        [Parameter(Mandatory)]
        [string]$ComputerName
    )
    begin{

    }
    process{

        $mask = Invoke-Command -ComputerName $ComputerName -ScriptBlock{
            $mask = Get-CIMInstance -ClassName Win32_NetworkAdapterConfiguration -Filter "IPEnabled = true" | Where-Object{$null -ne $_.IPSubnet} | Select-Object -First 1 | Select-Object -ExpandProperty IPSubNet;
            if([System.String]::IsNullOrWhiteSpace($mask)){
                Write-Warning "Could not retrieve subnet mask on computer $env:COMPUTERNAME"
                return $null;
            }
            return $mask
        }
        return $mask;
    }
    end{

    }
}