function Test-Server{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName
    )
    begin{
        $objects = New-Object System.Collections.Generic.List[PSCustomObject]
    }
    process{
        foreach($Computer in $ComputerName){
            try{
                #ping ping
                if(!(Test-Connection -ComputerName $Computer -Quiet -Count 1)){
                    [void]$objects.Add([PSCustomObject]@{
                        ComputerName = $Computer 
                        Valid = $false
                    });
                    $Computer | Add-EventLogEntry -EntryType Error -Message "Computer $Computer could not be contacted."
                    return;
                }
                #test to ensure the services exists and are running
                'MSSQLSERVER', 'SQLSERVERAGENT' | ForEach-Object{
                    $Name = $_
                    $svc = Get-Service -Name $Name -ComputerName $Computer -ErrorAction SilentlyContinue
                    if(!($svc)){
                        [void]$objects.Add([PSCustomObject]@{
                            ComputerName = $Computer 
                            Valid = $false
                        });
                        $Computer | Add-EventLogEntry -EntryType Error -Message "No sql service $Name could be found on computer $Computer"
                        return;
                    }
                    #test if service is running...we should put in code to try to start it at some point in the future...
                    if(!($svc | Where-Object{$_.Status -eq 'Running'})){
                        [void]$objects.Add([PSCustomObject]@{
                            ComputerName = $Computer 
                            Valid = $false
                        });
                        $Computer | Add-EventLogEntry -EntryType Error -Message "The sql service $Name on computer $Computer is not running."
                        return;
                    }
                }
                
                [void]$objects.Add([PSCustomObject]@{
                    ComputerName = $Computer 
                    Valid = $true
                });
            }
            catch{
                throw $_ 
            }
            finally{
                
            }

        }
    }
    end{
        return ![bool]($objects | Where-Object{$_.Valid -eq $false})
    }
}