function Get-Password{
    <#
    .SYNOPSIS
    Gets a password from a pre-configured credential store
    
    .DESCRIPTION
    Gets a password from a pre-configured credential store
    
    .PARAMETER Name
    The name of the login to retrieve the credential for
    
    .EXAMPLE
    Get-Password -Name 'sa' 
    

    .NOTES
    The roletype defaults to DBMSC, because that's really what a default configuration is; it's a miscellaneous server with no configurations as of yet...
    #>
    
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline)]
        [string]$Name#,
        #[string]$RoleType = "dbsql",
        #[PSCredential]$Credential
    )
    begin{
        $config = Get-Configuration 
    }
    process{

        switch($config.credstore){
            ([CredStore]::Device42){
                $uri = [uri]::EscapeUriString("$($APIURL)/api/1.0/passwords?username=$($username)&plain_text=yes");
                $pwd = Get-RestAPIData -URL $uri -Credential $Credential | Select-Object -ExpandProperty Passwords 
                if([System.string]::IsNullOrEmpty($pwd)){
                    $env:COMPUTERNAME | Add-EventLogEntry -EntryType Warning -Message "The password for account $Name could not be retrieved from $uri."
                    return $null;
                }
            }
            ([CredStore]::Vault){
                if([System.String]::IsNullOrWhiteSpace($script:token)){
                    # if(!$Credential){
                    #     $env:COMPUTERNAME | Add-EventLogEntry -EntryType Error -Message "The token was not set and no credential was supplied in order to retrieve the token."
                    #     return $null;
                    # }
                    $script:token = Get-VaultToken #-Credential $Credential 
                    if([System.String]::IsNullOrEmpty($script:token)){
                        $env:COMPUTERNAME | Add-EventLogEntry -EntryType Warning -Message "Could not retrieve the vault token for account $Name on computer $env:COMPUTERNAME."
                        return $null;
                    }
                }

                # if([System.String]::IsNullOrWhiteSpace($script:token)){
                #     $env:COMPUTERNAME | Add-EventLogEntry -EntryType Error -Message "The token was not set so the password for $Name cannot be retrieved."
                #     return $null;
                # }

                #$location = "v1/secret/public/$RoleType/$Name"
                $location = "v1/$($config.vaultnamespace)/secret/$Name"
                $uri = [uri]::EscapeUriString("$($config.vaultaddress)/$location");

                $headers = @{}
                $headers.Add("X-Vault-Token", $script:token)
                $headers.Add("ContentType", "application/json")
                
                try{
                    #[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}
                    [System.Net.ServicePointManager]::CheckCertificateRevocationList = $false
                    [System.Net.ServicePointManager]::Expect100Continue = $false
                    [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

                    $pwd = Invoke-RestMethod -Uri $uri -Method Get -ContentType "application/json" -Headers $headers #-Proxy $config.proxy
                }
                catch{
                    $env:COMPUTERNAME | Add-EventLogEntry -EntryType Error -Message "The password for account $Name could not be retrieved." -throw
                    return $null;
                }
                finally{
                    [System.Net.ServicePointManager]::ServerCertificateValidationCallback = $null;
                }
                
                if(!($pwd) -or [System.String]::IsNullOrEmpty($pwd.data)){
                    $env:COMPUTERNAME | Add-EventLogEntry -EntryType Warning -Message "The password for account $Name could not be retrieved from $uri."
                    return $null;
                }
            }
        }
        if(Get-Member -InputObject $pwd.data -name "username" -Membertype Properties){
            $Name = $pwd.data.username 
        }
        return New-Object System.Management.Automation.PSCredential ($Name, (ConvertTo-SecureString $pwd.data.password -AsPlainText -Force))

    }
    end{

    }
}
