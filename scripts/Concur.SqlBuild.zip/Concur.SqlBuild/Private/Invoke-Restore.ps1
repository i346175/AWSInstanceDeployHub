function Invoke-Restore{
    <#
    .SYNOPSIS
    Restores a database to a server in nonrecovery mode
    
    .DESCRIPTION
    Restores a database to a server in nonrecovery mode
    
    .PARAMETER ComputerName
    The name of the computer to do the restore on
    
    .PARAMETER Name
    The name of the database
    
    .PARAMETER BackupFile
    The location of the backup file, eg:  D:\Backups\DatabaseName.bak
    
    .PARAMETER Force
    If provided, this will drop the database before doing the restore.  The restore does a replace regardless...
    
    .EXAMPLE
    $ComputerName | Invoke-Restore -Name eOperationsDBA -BackupFile 'd:\Backups\eOperationsDBA.bak'
    
    .NOTES
    General notes
    #>
    
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$Name,
        [Parameter(Mandatory)]
        [string]$BackupFile,
        [switch]$Force
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
        [void][System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended")
        $config = Get-SqlDefaultConfiguration
        $dataDir = $config.storage | Where-Object{$_.label -eq 'data'} | Select-Object -ExpandProperty path
        $logDir = $config.storage | Where-Object{$_.label -eq 'log'} | Select-Object -ExpandProperty path
    }
    process{

        foreach($Computer in $ComputerName){
            try{
                $exists = Invoke-Command -ComputerName $Computer -ScriptBlock{
                    
                    #create the data\log dirs if they don't exist...
                    New-Item -ItemType Directory -Path $using:dataDir -Force | Out-Null
                    New-Item -ItemType Directory -Path $using:logDir -Force | Out-Null

                    return (Test-Path -Path $using:BackupFile -PathType Leaf);
                }

                if(!$exists){
                    $Computer | Add-EventLogEntry -EntryType Warning -Message "The backup file $BackupFile was not found on computer $Computer.`r`nRestore cannot continue."
                    return;
                }

                $srv = New-Object Microsoft.SqlServer.Management.Smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                $srv.ConnectionContext.StatementTimeout = 0

                $backup = New-Object Microsoft.SqlServer.Management.Smo.BackupDeviceItem ($BackupFile, [Microsoft.SqlServer.Management.Smo.DeviceType]::File)
                
                $restore = New-Object Microsoft.SqlServer.Management.Smo.Restore
                $restore.Devices.Add($backup);
                $restore.NoRecovery = $true;
                $restore.ReplaceDatabase = $true
        
                $header = $restore.ReadBackupHeader($srv)
                if([System.String]::IsNullOrWhiteSpace($Name)){
                    $Name = $header.DatabaseName
                }
                $restore.Database = $Name
                if($Force -and $srv.Databases[$Name]){
                    $srv.KillDatabase($Name);
                }

                foreach($dbFile in $restore.ReadFileList($srv)){
                    switch($dbFile.Type){
                        'D'{
                            $fileName = Join-Path -Path $dataDir -ChildPath ([System.IO.Path]::GetFileName($dbFile.PhysicalName))
                            [void]$restore.RelocateFiles.Add((New-Object Microsoft.SqlServer.Management.Smo.RelocateFile($dbFile.LogicalName, $fileName)))
                        }
                        'L'{
                            $fileName = Join-Path -Path $logDir -ChildPath ([System.IO.Path]::GetFileName($dbFile.PhysicalName))
                            [void]$restore.RelocateFiles.Add((New-Object Microsoft.SqlServer.Management.Smo.RelocateFile($dbFile.LogicalName, $fileName)))
                        }
                    }
                }
                
                $srv.KillAllProcesses($Name);
                $restore.SqlRestore($srv);
                
            }
            catch{
                throw $_ 
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }

    }
    end{

    }
}