function Enable-Hadr{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName 
    )
    begin{

    }
    process{
        # The disabling of hadr if enabled is because sometimes the cluster is destroyed and rebuilt, and when this is done if you try
        # to create a new availability group it will fail due to the cluster being yanked out from under alwayson.  Instead, just 
        # check if it's enabled...and if it is, disable it, then re-enable it afterwards again.  
        foreach($Computer in $ComputerName){
            if((Test-HadrEnabled -ComputerName $Computer)){
                Invoke-Command -ComputerName $Computer -ScriptBlock{
                    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SqlWmiManagement") | Out-Null
                    $srv = New-Object Microsoft.SqlServer.Management.Smo.Wmi.ManagedComputer $env:COMPUTERNAME
                    $service = $srv.Services | Where-Object{$_.Name -eq 'MSSQLSERVER'}
                    $service.ChangeHadrServiceSetting($false);
                    
                    Get-Service -Name MSSQLSERVER | Restart-Service -Force | Out-Null
                    Get-Service -Name SQLSERVERAGENT | Start-Service
                }
            }
            Invoke-Command -ComputerName $Computer -ScriptBlock{
                [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SqlWmiManagement") | Out-Null
                $srv = New-Object Microsoft.SqlServer.Management.Smo.Wmi.ManagedComputer $env:COMPUTERNAME
                $service = $srv.Services | Where-Object{$_.Name -eq 'MSSQLSERVER'}
                $service.ChangeHadrServiceSetting($true);
                
                Get-Service -Name MSSQLSERVER | Restart-Service -Force | Out-Null
                Get-Service -Name SQLSERVERAGENT | Start-Service 
            }
        }
    }
    end{

    }
}