   
Function Add-AuditLogins{
   <#
   .SYNOPSIS
   Audit the successful and failed logins by writing to the windows Event Log - Security Log
   
   .DESCRIPTION
   Adds an entry to the event log of the specified computers
   
   .PARAMETER ComputerName
   The name of the computer(s) on which to add the event log entry
   
   #>
   
   [cmdletbinding()]
   param(
       [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
       [string[]]$ComputerName
   )
   begin{
        $config = Get-SqlDefaultConfiguration
        $AuditName=$config.audits | Where-Object{$_.name -eq 'TrackLogins'}
        $AuditSpecName=$config.audits | Where-Object{$_.name -eq 'TrackLogins'} | Select-Object -ExpandProperty auditspecname
        $UserRights = $config.audits | Where-Object{$_.name -eq 'TrackLogins'} | Select-Object -ExpandProperty privileges
        $SqlSA= $config.sqlserviceaccount
   }
   process{

       foreach($Computer in $ComputerName){
         try{
               ## configure the audit object access setting in Windows using auditpol
               Invoke-Command -ComputerName $Computer -ScriptBlock { "auditpol /set /subcategory:""application generated"" /success:enable /failure:enable" }
               
               ## grant the generate security audits permission to an account using secpol-secedit.exe
               
                foreach($right in $UserRights) {
                    Add-LocalUserRight -ComputerName $Computer -LocalUserRight $right
                }

               ## Create and Enable Audit on Sql Server
               $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
               $srv.ConnectionContext.TrustServerCertificate = $true
               $Audit = New-Object Microsoft.SqlServer.Management.Smo.Audit($srv, $Auditname)
               $AuditSpec = New-Object Microsoft.SqlServer.Management.Smo.ServerAuditSpecification($srv, $AuditSpecName)
               
               ## grant SERVER AUDIT to Sql service account
               $DBPermSet=[Microsoft.SqlServer.Management.Smo.ServerPermissionSet]::new()
               $DBPermSet.Add([Microsoft.SqlServer.Management.Smo.ServerPermission]::AlterAnyServerAudit)
               $srv.Grant($DBPermSet,$SqlSA)
               
               ## if it exists, disable then drop
               if($srv.Audits[$AuditName]){
                    $srv.Audits[$AuditName].Disable()
                    $srv.Audits[$AuditName].Drop()
               }

               ## create and enable audit to Security Log
               $Audit.DestinationType = [Microsoft.SqlServer.Management.Smo.AuditDestinationType]'SecurityLog'
               $Audit.QueueDelay=1000
               $Audit.OnFailure="CONTINUE"
               $Audit.Create()
               $Audit.Enable()

               ## if it exists, disable then drop
               if($srv.ServerAuditSpecifications[$AuditSpecName]){
                    $srv.ServerAuditSpecifications[$AuditSpecName].Disable()
                    $srv.ServerAuditSpecifications[$AuditSpecName].Drop()
               }

               $AuditSpec.AuditName=$AuditName

               ## Set audit action - Failed Logins
               $AuditActionType = [Microsoft.SqlServer.Management.Smo.AuditActionType]::FailedLoginGroup
               $SpecDetail = new-object Microsoft.SqlServer.Management.Smo.AuditSpecificationDetail($AuditActionType)
               $AuditSpec.AddAuditSpecificationDetail($SpecDetail)

               ## Set audit action - Successful Logins
               $AuditActionType = [Microsoft.SqlServer.Management.Smo.AuditActionType]::SuccessfulLoginGroup
               $SpecDetail = new-object Microsoft.SqlServer.Management.Smo.AuditSpecificationDetail($AuditActionType)
               $AuditSpec.AddAuditSpecificationDetail($SpecDetail)
               
               ## Create and enable audit spec
               $AuditSpec.Create()
               $AuditSpec.Enable()

        }
        catch{
            throw $_ 
        }
        finally{
            if($srv){
                $srv.ConnectionContext.Disconnect()
            }
        }
    }
}
end{
}
}
