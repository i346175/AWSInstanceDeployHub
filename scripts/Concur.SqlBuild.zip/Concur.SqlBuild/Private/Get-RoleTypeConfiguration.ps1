function Get-RoleTypeConfiguration{
    [cmdletbinding()]
    param(
        [string]$Name
    )
    begin{

    }
    process{
        $parent = Split-Path -Path $PSScriptRoot -Parent
        $configFile = [System.io.Path]::Combine($parent, "Config", "RoleTypes", "$name.json")
        if(!(Test-Path -Path $configFile -PathType Leaf)){
            throw "Configuration file $configFile could not be found."
        }
        return (Get-Content -Path $configFile | ConvertFrom-Json)
    }
    end{

    }
}