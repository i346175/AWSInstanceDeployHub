function Add-CTHost{
    <#
    .SYNOPSIS
    Adds a server's listener to the CT_HOST database in the current jurisdiction.
    
    .DESCRIPTION
    After a server has been configured, if the server is supposed to be in CT_HOST, the listener for said server should be in the
    CTH_SERVER_INSTANCE table with the appropriate port.

    .PARAMETER ComputerName
    The name of the computer(s) whose listener is to be added to CT_HOST
    
    .EXAMPLE
    Add-CTHost -ComputerName SEAPR1DB0000
    
    .NOTES
    Only servers of certain role types need their listeners added to CT_HOST, so this cmdlet will only be called for those servers.
    Note that for clusters, only their listeners, not their servers, should exist in CT_HOST.
    #>
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")

        $Config = Get-Configuration
        $Port = $Config.port 
    }
    process{

        foreach($Computer in $ComputerName){
            
            try{

                # get the listener
                $Listener = Get-Listener($Computer | Format-ServerName)

                if ([System.string]::IsNullOrEmpty($Listener)) {
                    Add-EventLogEntry -Computer $Computer -EntryType Warning -Message "Listener does not exist for computer $Computer."
                    return
                }

                # ensure the listener is not already in ct_host
                if (Test-CTHost -ComputerName $Computer) {
                    Add-EventLogEntry -Computer $Computer -EntryType Warning -Message "Listener $($Listener | Format-ServerName) is already in the CTH_SERVER_INSTANCE table in CT_HOST."
                    return
                }

                # add the listener to ct_host
                try{

                    # connect to ct_host server
                    $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Config.cthostserver | Format-ServerName -AddPort)
                    $srv.ConnectionContext.DatabaseName = $Config.cthostdbname

                    $cmd = "INSERT dbo.cth_server_instance 
                                (server_name, port_num, instance_name, linked_server_name)
                            VALUES 
                                ('$($Listener.ToUpper())', $Port, NULL, '$($Listener.ToUpper())')"

                    [void] $srv.ConnectionContext.ExecuteNonQuery($cmd)
                }
                catch{
                    Add-EventLogEntry -Computer $Computer -EntryType Warning -Message "There was an error in trying to add listener $($Listener | Format-ServerName) to CT_HOST"
                    return
                }
                finally {
                    if ($srv) {
                        $srv.ConnectionContext.Disconnect() 
                    }
                }
    
                # check that the INSERT was successful
                if (! (Test-CTHost -ComputerName $Computer)) {
                    Add-EventLogEntry -Computer $Computer -EntryType Warning -Message "Listener $($Listener | Format-ServerName) was not added to the CTH_SERVER_INSTANCE table in CT_HOST."
                    return
                }
            }
            catch {
                throw $_ 
            }
        }
    }
    end{

    }
}
