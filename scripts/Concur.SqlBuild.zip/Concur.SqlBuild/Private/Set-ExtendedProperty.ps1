function Set-ExtendedProperty{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [string]$DatabaseName = 'master',
        [Parameter(Mandatory)]
        [string]$Name,
        [Parameter(Mandatory)]
        [string]$Value 
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
        #$config = Get-SqlDefaultConfig 
    }
    process{

        foreach($Computer in $ComputerName){
            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                $db = $srv.Databases[$DatabaseName]
                if($db.ExtendedProperties[$Name]){
                    $db.ExtendedProperties[$Name].Drop();
                }
                $prop = New-Object Microsoft.SqlServer.Management.Smo.ExtendedProperty $db, $Name, $Value
                $prop.Create();
                
            }
            catch{
                $Computer | Add-EventLogEntry -EntryType Warning -Message "Could not set extended property $Name to $Value on database $DatabaseName on computer $Computer.`r`nDetailed Exception:`r`n$($_ | Format-List -Force | Out-String)"
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }
        
    }
    end{

    }
}