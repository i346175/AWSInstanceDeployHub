function Test-AlwaysOnGroup{
    <#
    .SYNOPSIS
    This tests one or more computers to see if an availability group with the name $Name exists.  If any one of the computers does not have the availability group, it returns false.
    
    .DESCRIPTION
    This tests one or more computers to see if an availability group with the name $Name exists.  If any one of the computers does not have the availability group, it returns false.
    
    .PARAMETER ComputerName
    One or more computers to test for the Availability Group
    
    .PARAMETER Name
    The name of the AvailabilityGroup
    
    .EXAMPLE
    'Server1', 'Server2', 'Server3' | Test-AvailabilityGroup -Name Expense
    
    .EXAMPLE 
    Test-AvailabilityGroup -ComputerName Server1 -Name Expense
    
    .NOTES
    If more than one $ComputerName is passed in and one of those computers does not have the availabilitygroup on it, the function returns false.  A warning message is returned stating 
    the computer that is missing the availability group.
    #>
    
    [cmdletbinding()]
    param(
        [string[]]$ComputerName,
        [string]$Name
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
        $objects = New-Object System.Collections.Generic.List[PSCustomObject]
    }
    process{

        foreach($Computer in $ComputerName){
            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                if(!$srv.AvailabilityGroups[$Name]){
                    $Computer | Add-EventLogEntry -EntryType Warning -Message "AvailabilityGroup $Name was not found on computer $Computer."
                    [void]$objects.Add([PSCustomObject]@{
                        ComputerName = $Computer
                        Exists = $false
                    });
                }
            }
            catch{
                throw $_
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }

    }
    end{
        #if ANY are false, return false.
        return ![bool]($objects | Where-Object{$_.Exists -eq $false})
    }
}