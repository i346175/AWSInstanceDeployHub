function Set-SqlMemory{
    <#
    .SYNOPSIS
    Sets the sql server configuration memory to OS max - 6GB
    
    .DESCRIPTION
    Sets the sql server configuration memory to OS max - 6GB
    
    .PARAMETER ComputerName
    The  name(s) of the computers to configure the memory on
    
    .EXAMPLE
    $Computers | Set-SqlMemory
    
    .EXAMPLE
    'Server1', 'Server2', 'Server3' | Set-SqlMemory

    .EXAMPLE
    Set-SqlMemory -ComputerName 'Server4'

    .NOTES
    
    #>
    
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
    }
    process{

        foreach($Computer in $ComputerName){
            $mem = [int](Get-CimInstance -ComputerName ($Computer | Format-ServerName) Win32_ComputerSystem | Select-Object @{n='Memory';e={[Math]::Round($_.TotalPhysicalMemory/1MB,0)}} | Select-Object -ExpandProperty Memory)
            
            #Condition to determin the memory to leave for OS as per CSCI-6032
            If($mem -gt 32768){ $osMem = 10240 }
            Else{ $osMem = 6144 }
            
            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-Servername -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                $srv.Configuration.MaxServerMemory.ConfigValue = ($mem - $osMem);  
                $srv.Alter();
            }
            catch{
                throw $_ 
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }


    }
    end{

    }
}
