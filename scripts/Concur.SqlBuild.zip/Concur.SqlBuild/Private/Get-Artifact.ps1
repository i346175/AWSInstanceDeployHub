function Get-Artifact{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Location,
        [Parameter(Mandatory)]
        [string]$Destination
        <#,
        [Parameter(Mandatory)]
        [pscredential]$Credential
        #>
    )
    begin{
        $config = Get-Configuration 
    }
    process{
        <#
        if($Credential.UserName -ne 'X-JFrog-Art-Api'){
            $Credential.UserName = 'X-JFrog-Art-Api'
        }
        #>
        if(Test-Path -Path $Destination -PathType Leaf){
            Remove-Item -Path $Destination -Force -ErrorAction SilentlyContinue | Out-Null
        }
        
        [System.Net.ServicePointManager]::CheckCertificateRevocationList = $false
        [System.Net.ServicePointManager]::Expect100Continue = $false
        [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12  #, [System.Net.SecurityProtocolType]::Tls11, [System.Net.SecurityProtocolType]::Tls 
        
        try{
            Invoke-WebRequest -Uri $Location -Method "Get" -ContentType "application/zip" -UseBasicParsing -OutFile $Destination #-Proxy $config.proxy
        }
        catch{
            $env:COMPUTERNAME | Add-EventLogEntry -EntryType Warning -Message "There was an error in downloading from artifactory location $location on computer $env:COMPUTERNAME "
            return;
        }

        if(!(Test-Path -Path $Destination -PathType Leaf)){
            Write-Warning "The file $Destination could not be found after the download completed."
            return;
        }

        return [PSCustomObject]@{
            Location = $Location
            Destination = $Destination
        };

    }
    end{
        
    }
}