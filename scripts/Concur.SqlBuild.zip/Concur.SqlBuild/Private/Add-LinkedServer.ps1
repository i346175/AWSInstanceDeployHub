function Add-LinkedServer{
    <#
    .SYNOPSIS
    Adds linked servers from the role configuration file to the computers passed in as the $ComputerName
    
    .DESCRIPTION
    Adds linked servers from the role configuration file to the computers passed in as the $ComputerName
    
    .PARAMETER ComputerName
    The name of the computer to add the linked servers to
    
    .PARAMETER RoleType
    The role type where the linked server configuration is found (Config/RoleTypes/$RoleType.json)
    
    .PARAMETER Force
    Forces the linked server to be dropped and re-created if it exists
    
    .EXAMPLE
    An example
    
    .NOTES
    If a linked server login exists on a given linked server already, it is dropped and re-added.
    #>
    
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$RoleType,
        [switch]$Force
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
        $config = Get-Configuration 
        $role = Get-RoleTypeConfiguration -Name $RoleType 
    }
    process{
        foreach($Computer in $ComputerName){
            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($ComputerName | Format-ServerName -AddPort)
                foreach($linkedServer in $role.linkedservers){
                    if($srv.LinkedServers[$linkedServer.name]){
                        if(!$Force){
                            $Computer | Add-EventLogEntry -EntryType Warning -Message "The linked server $($linkedServer.name) already exists on computer $Computer."
                            return;
                        }
                        $srv.LinkedServers[$linkedServer.name].Drop($true);
                    }
                    $linkedsrv = New-Object Microsoft.SqlServer.Management.smo.LinkedServer $srv, $linkedServer.Name 
                    $linkedsrv.DataSource = "$($linkedserver.datasource),$($config.port)"
                    $linkedsrv.ProductName = $linkedServer.productname 
                    $linkedsrv.DataAccess = $linkedServer.dataaccess
                    $linkedsrv.rpc = $linkedserver.rpc 
                    $linkedsrv.rpcout = $linkedserver.rpcout 
                    $linkedsrv.Create();
                    $srv.LinkedServers.Refresh();
                    foreach($login in $linkedServer.remotelogins){
                        if($srv.LinkedServers[$linkedServer.name].LinkedServerLogins[$login.name]){
                            $srv.LinkedServers[$linkedServer.name].LinkedServerLogins[$login.name].Drop();
                        }
                        $linkedLogin = New-Object Microsoft.SqlServer.Management.smo.LinkedServerLogin $linkedsrv, $login.name
                        [PSCredential]$Credential = Get-Password -Name $login.name 
                        if(!$Credential){
                            $Computer | Add-EventLogEntry -EntryType Warning -Message "The password for login $($login.name) could not be retrieved while setting up the linked server $($linkedServer.Name) on computer $Computer."
                            return;
                        }
                        $linkedLogin.SetRemotePassword($Credential.Password);
                        $linedLogin.Impersonate = $login.impersonate
                        $srv.LinkedServers[$linkedServer.name].LinkedServerLogins.Add($linkedLogin);
                        $srv.LinkedServers[$linkedServer.name].Alter();
                    }
                }
            }
            catch{
                throw $_ 
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }
    }
    end{

    }
}