function Test-HadrEnabled{
    param(
        [Parameter(Mandatory)]
        [string]$ComputerName
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")

        $config = Get-Configuration 
    }
    process{

        
        try{
            $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($ComputerName | Format-ServerName -AddPort)
            if([int]$srv.VersionMajor -lt 11){
                $ComputerName | Add-EventLogEntry -EntryType Warning -Message "HADR is not enabled on computer computer $ComputerName."
                return $false;
            }
            return $srv.IsHadrEnabled 
        }
        catch{
            throw $_ 
        }
        finally{
            $srv.ConnectionContext.Disconnect();
        }
    }
    end{

    }
}