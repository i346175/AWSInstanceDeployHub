function Get-CFNListenerIPAddresses{
    param(
        [Parameter(Mandatory)]
        [string[]]$ComputerName
    )
    begin{
        
    }
    process{

        <#
            $Global:MasterPrivateIP = '10.14.2.220' 
            $Global:MasterSecondaryIPs = @('10.14.2.201', '10.14.2.197' ) 
            $Global:Worker1PrivateIP = '10.14.6.42' 
            $Global:Worker1SecondaryIPs = @('10.14.6.122', '10.14.6.54' ) 
            $Global:Worker2PrivateIP = '10.14.10.47' 
            $Global:Worker2SecondaryIPs = @('10.14.10.253', '10.14.10.183' ) 
        #>
        # $nodes = Invoke-Command -ComputerName $ComputerName -ScriptBlock{
        #     Import-Module FailoverClusters

        #     $nodes = Get-Cluster | Get-ClusterNode | Select-Object -ExpandProperty Name
        #     return $nodes

        # }
        $objects = New-Object System.Collections.Generic.List[PSCustomObject] 
        foreach($node in $ComputerName){
            $path = "\\$node\c`$\cfn\temp\get_cluster_nodes_addresses.ps1"
            if(Test-Path -Path $path -PathType Leaf){
                $script = [ScriptBlock]::Create((get-content -Path $path -Raw))
                Invoke-Command -ScriptBlock $script 
                break;
            }
        }
        
        [void]$objects.Add([PSCustomObject]@{
            Name = "master"
            IP = $Global:MasterSecondaryIPs[1]
        });
        [void]$objects.Add([PSCustomObject]@{
            Name = "worker1"
            IP = $Global:Worker1SecondaryIPs[1]
        });
        #Condition added to skip Worker2 IP for 2-node cluster. Ref CSCI-5895
        If(Get-Variable -Name Worker2SecondaryIPs -ErrorAction SilentlyContinue){
            [void]$objects.Add([PSCustomObject]@{
                Name = "worker2"
                IP = $Global:Worker2SecondaryIPs[1]
            });
        }
        return $objects
        

    }
    end{
        
    }
}