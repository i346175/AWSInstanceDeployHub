function Set-ReadonlyRouting{
    param(
        [string]$ComputerName,
        [ValidateSet('ALL', 'READ_ONLY', 'NO')]
        [string]$SecondaryReplicaAccess = 'ALL'
    )
    begin{

        $Config = Get-Configuration 

        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
    }
    process{
 
        function ConvertTo-QuoteString{
            param(
                [string[]]$Array
            )
            $sb = New-Object System.Text.StringBuilder
            $Array | ForEach-Object{
                [void]$sb.Append("'$_',");
            }
            return $sb.ToString().Substring(0, $sb.ToString().Length-1)
        }
 
        function New-ReadonlyRoutingURL{
            param(
                [string]$ComputerName,
                [string]$GroupName
            )
 
            "
            ALTER AVAILABILITY GROUP [$GroupName]
            MODIFY REPLICA ON N'$ComputerName' WITH(
                SECONDARY_ROLE (READ_ONLY_ROUTING_URL = N'TCP://$ComputerName.$(Get-Domain):$($Config.Port)')
            );";
        }
 
        function New-ReadonlyRoutingString{
            param(
                [string]$Primary,
                [string[]]$Secondaries,
                [string]$GroupName
            )
            $sb = new-object System.Text.StringBuilder
 
            [void]$sb.Append("
            ALTER AVAILABILITY GROUP [$GroupName]
            MODIFY REPLICA ON  N'$Primary' WITH(
                SECONDARY_ROLE (ALLOW_CONNECTIONS = $SecondaryReplicaAccess)
            );");
 
            [void]$sb.Append("
            ALTER AVAILABILITY GROUP [$GroupName]
            MODIFY REPLICA ON N'$Primary' WITH(
                PRIMARY_ROLE (READ_ONLY_ROUTING_LIST=($(ConvertTo-QuoteString -Array $Secondaries),'$Primary'))
            );");
 
            return $sb.ToString();
        }
 
        $srv = new-object Microsoft.SqlServer.management.smo.Server "$ComputerName,$($Config.Port))"
        foreach($group in $srv.AvailabilityGroups){
            $Primary = $group.PrimaryReplicaServerName
            $Secondaries = New-Object System.Collections.Generic.List[string]
            $group.AvailabilityReplicas | Where-Object{$_.Name -ne $Primary -and $_.AvailabilityMode -ne [Microsoft.SqlServer.Management.Smo.AvailabilityReplicaAvailabilityMode]::AsynchronousCommit} | Select-Object -ExpandProperty Name | %{
            #$group.AvailabilityReplicas | Where-Object{$_.Name -ne $Primary -and $_.Name -notlike '*DR1*'} | Select-Object -ExpandProperty Name | %{
                [void]$Secondaries.Add($_);
            }
 
            $cmd = New-ReadonlyRoutingURL -ComputerName $Primary -GroupName $group.Name -Port $Port
            $srv = New-Object Microsoft.SqlServer.Management.Smo.Server "$Primary,$($Config.Port)"
            $srv.ConnectionContext.StatementTimeout = 0;
            [void]$srv.ConnectionContext.ExecuteNonQuery($cmd);
            $srv.ConnectionContext.Disconnect();
 
            $Secondaries | ForEach-Object{
                $cmd = New-ReadonlyRoutingURL -ComputerName $_ -GroupName $group.Name 
                $srv = New-Object Microsoft.SqlServer.Management.Smo.Server "$Primary,$($Config.Port)"
                $srv.ConnectionContext.StatementTimeout = 0;
                [void]$srv.ConnectionContext.ExecuteNonQuery($cmd);
                $srv.ConnectionContext.Disconnect();
            }
 
            $cmd = New-ReadonlyRoutingString -Primary $Primary -Secondaries $Secondaries -GroupName $group.Name
 
            $srv = New-Object Microsoft.SqlServer.Management.Smo.Server "$Primary,$Port"
            $srv.ConnectionContext.StatementTimeout = 0;
            [void]$srv.ConnectionContext.ExecuteNonQuery($cmd);
            $srv.ConnectionContext.Disconnect();
 
            $Secondaries.Clone() | ForEach-Object{
                $Secondary = $_
                [void]$Secondaries.Remove($Secondary);
                [void]$Secondaries.Add($Primary);
                $cmd = New-ReadonlyRoutingString -Primary $Secondary -Secondaries $Secondaries -Port $Port -GroupName $group.Name
 
                $srv = New-Object Microsoft.SqlServer.Management.Smo.Server "$Primary,$Port"
                $srv.ConnectionContext.StatementTimeout = 0;
                [void]$srv.ConnectionContext.ExecuteNonQuery($cmd);
                $srv.ConnectionContext.Disconnect();
            }
        }
    }
    end{
 
    }
}
 