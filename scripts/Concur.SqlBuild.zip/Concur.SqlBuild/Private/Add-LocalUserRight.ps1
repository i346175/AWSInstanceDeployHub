Function Add-LocalUserRight {
	[cmdletbinding()]
	param(
		[Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
		[string[]]$ComputerName,
        [string]$LocalUserRight
	)
			
	begin {

		$config = Get-SqlDefaultConfiguration

        ## AD account to use for Audit
		$accountToAdd = $config.sqlserviceaccount       
          
        ## User rights to add ex. "SeAuditPrivilege"
		$UserRight = $LocalUserRight
		
		$RetVal=$false
	}
	process{
	
		foreach($Computer in $ComputerName){

			$tempPath = [System.IO.Path]::Combine("\\$($Computer)", "c`$", "windows", "temp");
			
			$import = Join-Path -Path $tempPath -ChildPath "import.inf" 
			$export = Join-Path -Path $tempPath -ChildPath "export.inf" 
			$secedt = Join-Path -Path $tempPath -ChildPath "secedt.sdb" 
			
			$sidstr = $null

			try {
				$ntprincipal = new-object System.Security.Principal.NTAccount "$accountToAdd"
				$sid = $ntprincipal.Translate([System.Security.Principal.SecurityIdentifier])
				$sidstr = $sid.Value.ToString()
			} 
			catch {
				$sidstr = $null
			}
			
			$Computer | Add-EventLogEntry -EntryType Verbose -Message "Account: $($accountToAdd)"

			if([string]::IsNullOrEmpty($sidstr) ) {
				
				$Computer | Add-EventLogEntry -EntryType Error -Message "User [$accountToAdd] not found."
				return $RetVal;
			}

			$Computer | Add-EventLogEntry -EntryType Verbose -Message "Account SID: $($sidstr)"
			
			##Export current Local Security Policy
			try {
                $cmd={
                        $exportfile=$args[0]
                        SecEdit.exe /export /cfg $exportfile /quiet
                     }
				Invoke-Command -ComputerName $Computer -ScriptBlock $cmd -ArgumentList $export
			}
			catch {
				$Computer | Add-EventLogEntry -EntryType Error -Message "There was an error exporting local security policy configuration to a file on $Computer."
				return $RetVal;
			}

			$c = Get-Content -Path $export 
			$currentSetting = ""
           
			foreach($s in $c) {
			    if( $s -like "$($UserRight)*") {
				    $x = $s.split("=",[System.StringSplitOptions]::RemoveEmptyEntries)
				    $currentSetting = $x[1].Trim()
				}
			}
       

			if( $currentSetting -notlike "*$($sidstr)*" ) {
		
				##Add Setting for UserRight
				if( [string]::IsNullOrEmpty($currentSetting) ) {
					$currentSetting = "*$($sidstr)"
				} 
				else {
					$currentSetting = "*$($sidstr),$($currentSetting)"
				}
			
				# Populate the import file
				ForEach ($line in @("[Unicode]", `
					"Unicode=yes", `
					"[Version]", `
					"signature=`"`$CHICAGO$`"", `
					"Revision=1", `
					"[Privilege Rights]", `
					"$($UserRight) = $($currentSetting)")){
						Add-Content $import $line
					} 
				
				try {
                        $cmd={
                                $secedtfile=$args[0]
                                $importfile=$args[1]
                                secEdit.exe /configure /db $secedtfile /cfg $importfile /areas USER_RIGHTS /quiet
                             }

					    Invoke-Command -ComputerName $Computer -ScriptBlock $cmd -ArgumentList $secedt, $import
						$RetVal = $true
				
                }
				catch{
					
					$Computer | Add-EventLogEntry -EntryType Error -Message "There was an error in executing secEdit.exe on computer $Computer. `r`nException Details:`r`n$($_ | Format-List -Force | Out-String)"
					
				} 
			
			} 
			else {
				    
					$Computer | Add-EventLogEntry -EntryType Error -Message "No action required! [$accountToAdd] already been granted rights for $UserRight on $Computer."
					$RetVal = $true
			}

			if(Test-Path $import) {Remove-Item -Path $import -Force}
			if(Test-Path $export) {Remove-Item -Path $export -Force}
			if(Test-Path $secedt) {Remove-Item -Path $secedt -Force}
	
			return $RetVal
		}
		
	}
}
	
