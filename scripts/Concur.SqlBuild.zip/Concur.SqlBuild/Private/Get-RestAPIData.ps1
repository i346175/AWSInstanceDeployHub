function Get-RestAPIData{
    param(
        [string]$URL,
        [pscredential]$Credential
    )

    $userName = $Credential.UserName
    #$password = $Credential.GetNetworkCredential().Password

    $dllload = [System.Reflection.Assembly]::LoadWithPartialName("System.Web.Extensions")
    $dllload = [System.Reflection.Assembly]::LoadWithPartialName("System.Security")
    #[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}
    [System.Net.ServicePointManager]::CheckCertificateRevocationList = $false
    [System.Net.ServicePointManager]::Expect100Continue = $false
    [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
    $jsonSer = New-Object System.Web.Script.Serialization.JavaScriptSerializer

    $auth =  [string]::format('Basic {0}', [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes( [string]::format( "{0}:{1}", $userName, $Credential.GetNetworkCredential().Password))))
    $req = [System.Net.WebRequest]::Create($URL)
    $req.headers.Add("Authorization", $auth )
    $req.Method = "GET"
    #$req.UserAgent = "Concur Compute";
    $req.Proxy = $null
    try{
        $resp = $req.GetResponse()
    }
    catch{
        Write-error "There was an error retrieving the rest api data from $URL.`r`nDetails:`r`n$($_ | format-list -Force | Out-String)"
        return $null;
    }
    $reader = new-object System.IO.StreamReader($resp.GetResponseStream())
    $jsonstring = $reader.ReadToEnd()
    return $jsonstring | ConvertFrom-Json 
}
