function Test-Database{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$Name
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
        $objects = New-Object System.Collections.Generic.List[PSCustomObject]
    }
    process{
        foreach($Computer in $ComputerName){
            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                if(!$srv.Databases[$Name]){
                    [void]$objects.Add([PSCustomObject]@{
                        ComputerName = $Computer
                        DatabaseName = $Name
                        Exists = $false
                    });
                    $Computer | Add-EventLogEntry -EntryType Warning -Message "Could not find database $DatabaseName on computer $Computer."
                    return;
                }
            }
            catch{
                throw $_ 
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
            [void]$objects.Add([PSCustomObject]@{
                ComputerName = $Computer
                DatabaseName = $Name
                Exists = $true
            });

        }
    }
    end{
        return ![bool]($objects | Where-Object{$_.Exists -eq $false})
    }
}