function Show-SqlInstance{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [string]$Name = 'MSSQLSERVER'
    )
    begin{

    }
    process{


        foreach($Computer in $ComputerName){
            Invoke-Command -ComputerName $Computer -ScriptBlock{
                $hklmRootNode = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server"
                $props = Get-ItemProperty "$hklmRootNode\Instance Names\SQL"
                $instances = $props.psobject.properties | Where-Object{$_.Value -like "*$using:Name"} | Select-Object Value
                foreach($inst in $instances){
                    $key = "$hklmRootNode\$($inst.Value)\MSSQLServer\SuperSocketNetLib"
                    Set-ItemProperty -Name HideInstance -Path $key -Value 0
                }
                Restart-Service -Name MSSQLSERVER -Force | Out-Null
                Get-Service -Name SQLSERVERAGENT | Start-Service
            }
        }

    }
    end{

    }
}
