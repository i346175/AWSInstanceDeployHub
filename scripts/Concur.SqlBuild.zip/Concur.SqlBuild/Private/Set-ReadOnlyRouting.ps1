function Set-ReadOnlyRouting{
    param(
        [Parameter(Mandatory)]
        [string[]]$ComputerName 
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
        $config = Get-Configuration 
    }
    process{

        if(!($ComputerName | Test-Listener)){
            $ComputerName | Add-EventLogEntry -EntryType Warning -Message "No listener counld be found on the alwayson group."
            return;
        }

        try{

            $srv = new-object Microsoft.SqlServer.Management.smo.Server (($ComputerName | Select-Object -First 1) | Format-ServerName -AddPort)
            $primaryName = $srv.AvailabilityGroups[0].PrimaryReplicaServerName
            $srv = new-object Microsoft.SqlServer.Management.smo.Server ($primaryName | Format-ServerName -AddPort)

            foreach($group in $srv.AvailabilityGroups){
                foreach($replica in $group.AvailabilityReplicas){
                    $replica.ReadonlyRoutingConnectionUrl = "tcp://$($replica.Name).$(Get-Domain):$($config.port)"
                    $replica.Alter();
                }
            }
            
            foreach($group in $srv.AvailabilityGroups){
                foreach($replica in $group.AvailabilityReplicas | Where-Object{$_.AvailabilityMode -ne [Microsoft.SqlServer.Management.smo.AvailabilityReplicaAvailabilityMode]::AsynchronousCommit}){
                    
                    #add the synchronous replicas omitting the current replica, as we want the non-current replica
                    #to be the first choice in the read list and then fall back to the current replica...
                    $route = new-object System.Collections.Generic.List[string];
                    $group.AvailabilityReplicas | where-object{$_.Name -ne $replica.Name -and $_.AvailabilityMode -ne [Microsoft.SqlServer.Management.smo.AvailabilityReplicaAvailabilityMode]::AsynchronousCommit} | ForEach-Object{
                        [void]$route.Add($_.Name);
                    }
                    [void]$route.Add($replica.Name);

                    <#
                        I detest setting this up this way...I didn't want to HAVE to load the SqlServer module,
                        nor could I find a way to set the routing list, as $Replica.ReadonlyRoutingList is a readonly
                        property...and $replica.SetLoadBalancedReadOnlyRoutingList does indeed take a generic.list as 
                        and argument...yet continually errors on trying to set this property, even though we're passing 
                        in the correct type...(I suspect this is a 2016+ only setting...)
                        I dunno.  Maybe the Set-SqlAvailabilityReplica is the right way to go?  I suspect it's cheating and 
                        just running straight up sql under the covers...
                    #>
                    Set-SqlAvailabilityReplica -InputObject $replica -ReadOnlyRoutingList $route
                }
            }

        }
        catch{
            $ComputerName | Add-EventLogEntry -EntryType Error -Message "There was an error in setting up the readonly routing on computer $ComputerName.`r`nDetailed Exception:`r`n$($_ | Format-List -Force | Out-String)" -throw 
        }
        finally{
            if($srv){
                $srv.ConnectionContext.Disconnect();
            }
        }

    }
    end{

    }
}