function Grant-UserRight {
    <#
     .SYNOPSIS
       Assigns user rights to accounts
     .DESCRIPTION
       Assigns one or more user rights (privileges) to one or more accounts. If you specify privileges already granted to the account, they are ignored.
     .PARAMETER Account
       Logon name of the account. More than one account can be listed. If the account is not found on the computer, the default domain is searched. To specify a domain, you may use either "DOMAIN\username" or "username@domain.dns" formats. SIDs may be also be specified.
     .PARAMETER Right
       Name of the right to grant. More than one right may be listed.
   
       Possible values: 
         SeTrustedCredManAccessPrivilege              Access Credential Manager as a trusted caller
         SeNetworkLogonRight                          Access this computer from the network
         SeTcbPrivilege                               Act as part of the operating system
         SeMachineAccountPrivilege                    Add workstations to domain
         SeIncreaseQuotaPrivilege                     Adjust memory quotas for a process
         SeInteractiveLogonRight                      Allow log on locally
         SeRemoteInteractiveLogonRight                Allow log on through Remote Desktop Services
         SeBackupPrivilege                            Back up files and directories
         SeChangeNotifyPrivilege                      Bypass traverse checking
         SeSystemtimePrivilege                        Change the system time
         SeTimeZonePrivilege                          Change the time zone
         SeCreatePagefilePrivilege                    Create a pagefile
         SeCreateTokenPrivilege                       Create a token object
         SeCreateGlobalPrivilege                      Create global objects
         SeCreatePermanentPrivilege                   Create permanent shared objects
         SeCreateSymbolicLinkPrivilege                Create symbolic links
         SeDebugPrivilege                             Debug programs
         SeDenyNetworkLogonRight                      Deny access this computer from the network
         SeDenyBatchLogonRight                        Deny log on as a batch job
         SeDenyServiceLogonRight                      Deny log on as a service
         SeDenyInteractiveLogonRight                  Deny log on locally
         SeDenyRemoteInteractiveLogonRight            Deny log on through Remote Desktop Services
         SeEnableDelegationPrivilege                  Enable computer and user accounts to be trusted for delegation
         SeRemoteShutdownPrivilege                    Force shutdown from a remote system
         SeAuditPrivilege                             Generate security audits
         SeImpersonatePrivilege                       Impersonate a client after authentication
         SeIncreaseWorkingSetPrivilege                Increase a process working set
         SeIncreaseBasePriorityPrivilege              Increase scheduling priority
         SeLoadDriverPrivilege                        Load and unload device drivers
         SeLockMemoryPrivilege                        Lock pages in memory
         SeBatchLogonRight                            Log on as a batch job
         SeServiceLogonRight                          Log on as a service
         SeSecurityPrivilege                          Manage auditing and security log
         SeRelabelPrivilege                           Modify an object label
         SeSystemEnvironmentPrivilege                 Modify firmware environment values
         SeDelegateSessionUserImpersonatePrivilege    Obtain an impersonation token for another user in the same session
         SeManageVolumePrivilege                      Perform volume maintenance tasks
         SeProfileSingleProcessPrivilege              Profile single process
         SeSystemProfilePrivilege                     Profile system performance
         SeUnsolicitedInputPrivilege                  "Read unsolicited input from a terminal device"
         SeUndockPrivilege                            Remove computer from docking station
         SeAssignPrimaryTokenPrivilege                Replace a process level token
         SeRestorePrivilege                           Restore files and directories
         SeShutdownPrivilege                          Shut down the system
         SeSyncAgentPrivilege                         Synchronize directory service data
         SeTakeOwnershipPrivilege                     Take ownership of files or other objects
     .PARAMETER Computer
       Specifies the name of the computer on which to run this cmdlet. If the input for this parameter is omitted, then the cmdlet runs on the local computer.
     .EXAMPLE
       Grant-UserRight "bilbo.baggins" SeServiceLogonRight
   
       Grants bilbo.baggins the "Logon as a service" right on the local computer.
     .EXAMPLE
       Grant-UserRight -Account "Edward","Karen" -Right SeServiceLogonRight,SeCreateTokenPrivilege -Computer TESTPC
   
       Grants both Edward and Karen, "Logon as a service" and "Create a token object" rights on the TESTPC system.
     .EXAMPLE
       Grant-UserRight -Account "S-1-1-0" -Right SeNetworkLogonRight
   
       Grants "Everyone" the "Access this computer from the network" right on the local computer.
     .INPUTS
       String Account
       PS_LSA.Rights Right
       String Computer
     .OUTPUTS
       None
     .LINK
       http://msdn.microsoft.com/en-us/library/ms721786.aspx
       http://msdn.microsoft.com/en-us/library/bb530716.aspx
    #>
       [CmdletBinding(SupportsShouldProcess=$true)]
       param (
           [Parameter(Position=0, Mandatory=$true, ValueFromPipelineByPropertyName=$true, ValueFromPipeline=$true)]
           [Alias('User','Username','SID')][String[]] $Account,
           [Parameter(Position=1, Mandatory=$true, ValueFromPipelineByPropertyName=$true)]
           [Alias('Privilege')] [PS_LSA.Rights[]] $Right,
           [Parameter(ValueFromPipelineByPropertyName=$true, HelpMessage="Computer name")]
           [Alias('System','ComputerName','Host')][String] $Computer
       )
       process {
           $lsa = New-Object PS_LSA.LsaWrapper($Computer)
           foreach ($Acct in $Account) {
               foreach ($Priv in $Right) {
                   if ($PSCmdlet.ShouldProcess($Acct, "Grant $Priv right")) { $lsa.AddPrivilege($Acct,$Priv) }
               }
           }
       }
   } # Assigns user rights to accounts
   