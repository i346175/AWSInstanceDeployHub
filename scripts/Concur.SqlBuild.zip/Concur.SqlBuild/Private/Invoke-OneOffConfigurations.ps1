Function Invoke-OneOffConfigurations{
    <#
    .SYNOPSIS
    Runs one-off configuration script, if any

    .DESCRIPTION
    Runs one-off configuration script, if any

    .PARAMETER ComputerName
    The name of the computer against which the script runs

    .EXAMPLE
    $ComputerName | Invoke-OneOffConfigurations

    .NOTES
    General notes
    #>

    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName
    )
    begin{
    }
    process{
        foreach($Computer in $ComputerName){
            try{
                $session = Get-ServerSession -ComputerName $Computer
                $cfg = Get-Configuration
                Invoke-Command -Session $session -ScriptBlock {
                    $global:config = $using:cfg
                    #transform $env:microservice to variable start with capital letter and store to variable $microservice
                    $microservice = $env:microservice.substring(0,1).ToUpper() + $env:microservice.substring(1)

                    . "C:\Program Files\WindowsPowerShell\Modules\Concur.SqlBuild\Config\One-offs\$microservice\deploy.ps1"
                }
                $session | Remove-PSSession
            }
            catch{
                write-warning "$($_.exception.message)"
                Add-EventLogEntry -Computer $Computer -EntryType Error -Message "Could not deploy one-off configurations on $($Computer | Format-ServerName)" -throw
                return;
            }
        }
    }
    end{

    }
}