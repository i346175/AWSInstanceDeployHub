function Get-Configuration{
    [cmdletbinding()]
    param(

    )
    begin{

    }
    process{
        $parent = Split-Path -Path $PSScriptRoot -Parent
        $ConfigFile = [System.IO.Path]::Combine($parent, 'Config', 'config.json');
        if(!(Test-Path -Path $ConfigFile -PathType Leaf)){
            throw "Could not find configuration file $ConfigFile"
        }
        return (Get-Content -Path $ConfigFile | ConvertFrom-Json).jurisdiction | Where-Object{$_.jurisdiction -eq (Get-jurisdiction)}
    }
    end{

    }
}