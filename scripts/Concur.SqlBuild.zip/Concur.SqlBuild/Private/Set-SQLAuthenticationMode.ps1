function Set-SQLAuthenticationMode{
    <#
      .SYNOPSIS
      Sets the authentication mode for SQL Server
      
      .DESCRIPTION
      This will enable either Integrated or Mixed authentication mode for the default SQL Server instance
      and restart the SQL Server service to make the changes take effect
      
      .PARAMETER ComputerName
      The name(s) of Computer(s) to run against
      
      .PARAMETER Mode
      The name of the mode to enable - 'Integrated' (Windows only), 'Mixed' (Windows & SQL)
      
      .EXAMPLE
      PS> Set-SQLAuthenticationMode -ComputerName SEAPR1DBBAT083 -Mode Integrated
      
      .EXAMPLE
      PS> Set-SQLAuthenticationMode -ComputerName SEAPR1DBBAT083 -Mode Mixed 
  
      .EXAMPLE
      PS> Set-SQLAuthenticationMode -ComputerName SEAPR1DBBAT083,SEAPR1DBBAT082 -Protocol Integrated
  
      #>
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName, 
        [ValidateSet('Integrated','Mixed')]
        [string]$Mode
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
    }
    process{

        foreach($Computer in $ComputerName){
            try{
                $Computer | Add-EventLogEntry -EntryType Verbose -Message "Setting SQL authentication mode to $Mode on server $Computer and restarting SQL Server service..."

                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                $srv.Settings.LoginMode = [Microsoft.SqlServer.Management.SMO.ServerLoginMode]::$Mode
                $srv.Alter() 
            }
            catch{
                $Computer | Add-EventLogEntry -EntryType Warning -Message "There was an error setting the sql authentication mode on computer $Computer to $Mode.`t`nDetailed Exception:`r`n$($_ |  Format-List -Force | Out-String)"
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
            
            # Invoke-Command  -ComputerName $Computer -ScriptBlock{
            #     [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
            #     [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
            #     [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
            #     $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer)
            #     $srv.Settings.LoginMode = [Microsoft.SqlServer.Management.SMO.ServerLoginMode]::$using:Mode
            #     $srv.Alter() 
                
            #     Get-Service -Name MSSQLSERVER | Restart-Service -Force
            #     Start-Service -Name SQLSERVERAGENT 
            # }
        }
    }
    end{
  
    }
}