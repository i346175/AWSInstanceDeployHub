function Set-SqlServiceAccount{
    <#
    .SYNOPSIS
    Sets the sql server service account to the account provided in the $ServiceAccount credential
    
    .DESCRIPTION
    Sets the sql server service account to the account provided in the $ServiceAccount credential
    
    .PARAMETER ComputerName
    The name(s) of the computers to set the service account on
    
    .PARAMETER ServiceName
    The name of the service account to set up.  Must be MSSQLSERVER or SQLSERVERAGENT
    
    .PARAMETER ServiceAccount
    The credential to set the service account to.  If 'localsystem' is passed in, the password is blanked, as PSCredential objects will not work with 
    a password that is an empty string
    
    .EXAMPLE
    $Credential = New-Object System.Management.Automation.PSCredential ("localsystem", $(ConvertTo-SecureString "localsystem" -AsPlainText -Force))
    $ComputerName | Set-SqlServiceAccount -ServiceName MSSQLSERVER -ServiceAccount $Credential 
    
    .NOTES
    If 'localsystem' is provided as the username, the password will be set to an empty string in the invoke-command on the server.
    #>
    
    [CmdletBinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [ValidateSet('MSSQLSERVER', 'SQLSERVERAGENT')]
        [string]$ServiceName = 'MSSQLSERVER',
        [PSCredential]$ServiceAccount
    )
    begin{

    }
    process{

        foreach($Computer in $ComputerName){
            $service = Get-SqlServiceAccount -ComputerName $Computer | Where-Object{$_.Name -eq $ServiceName}
            if($Service.NonFQDNServiceAccount.ToString().ToUpper() -eq $ServiceAccount.UserName.ToUpper()){
                $Computer | Add-EventLogEntry -EntryType Warning -Message "The service account for the $ServiceName service on computer $Computer is already set to use $($ServiceAccount.UserName)"
                return;
            }

            if($ServiceAccount.UserName -ne 'localsystem'){
                if(!(Test-ADCredential -Credential $ServiceAccount)){
                    $Computer | Add-EventLogEntry -EntryType Error -Message "The password for account $($ServiceAccount.UserName) was not correct." -throw
                    return;
                }
            }

            #obviously this will need to somehow call vault at some point in the future...
            try{
                Invoke-Command -ComputerName $Computer -ScriptBlock{
                    param(
                        $UserName,
                        $Password = ''
                    )

                    if($UserName.ToLower() -eq 'localsystem'){
                        $Password = ''
                    }
        
                    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SqlWmiManagement") | Out-Null
                    $srv = New-Object Microsoft.SqlServer.Management.Smo.Wmi.ManagedComputer $env:COMPUTERNAME
                    $service = $srv.Services | Where-Object{$_.name -eq $using:ServiceName}
                    $service.SetServiceAccount($UserName, $Password);
                    Restart-Service -name $using:ServiceName -Force | Out-Null
        
                    if($using:ServiceName -eq 'MSSQLSERVER'){
                        Start-Service -Name MSSQLSERVER -ErrorAction SilentlyContinue
                        Start-Service -Name SQLSERVERAGENT -ErrorAction SilentlyContinue
                    }
        
                } -ArgumentList (($ServiceAccount.UserName | Format-LoginName -DomainType DN), $ServiceAccount.GetNetworkCredential().Password) 
            }
            catch{
                $Computer | Add-EventLogEntry -EntryType Error -Message "There was an issue setting the service account $($ServiceAccount.UserName) on computer $Computer.`r`nDetailed Exception:`r`n$($_ | Format-List -Force | Out-String)" -throw
                return;
            }

        }

    }
    end{

    }
}
