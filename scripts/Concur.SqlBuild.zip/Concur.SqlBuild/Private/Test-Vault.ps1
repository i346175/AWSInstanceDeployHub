function Test-Vault{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory)]
        [PSCredential]$Credential,
        [string]$Name = 'dbsql'
    )
    begin{
        $config = Get-DefaultConfiguration 
    }
    process{
        try{
            $pwd = Get-Password -Name $config.sqlserviceaccount 
            if(!$pwd){
                $env:COMPUTERNAME | Add-EventLogEntry -EntryType Warning -Message "The password for $($config.sqlserviceaccount) could not be found in vault under the $Name role type."
                return $false;
            }
            
        }
        catch{
            $env:COMPUTERNAME | Add-EventLogEntry -EntryType Warning -Message ($_ | Format-List -Force | Out-String)
            return $false;
        }
    }
    end{

    }
}