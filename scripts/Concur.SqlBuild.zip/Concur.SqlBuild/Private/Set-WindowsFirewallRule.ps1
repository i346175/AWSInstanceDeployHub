function Set-WindowsFirewallRule{
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$Name,
        [Parameter(Mandatory)]
        [int]$Port,
        [ValidateSet('Inbound', 'OutBound')]
        [string]$Direction = 'Inbound',
        [ValidateSet('TCP', 'UDP')]
        [string]$Protocol = 'TCP',
        [ValidateSet('NotConfigured', 'Allow', 'Block')]
        [string]$Action = 'Allow'
    )
    begin{

    }
    process{

        if(!(Test-Connection -ComputerName ($Computer | Format-ServerName) -Count 1 -Quiet)){
            Add-EventLogEntry -Computer $Computer -EntryType Error -Message "Could not connect to computer $($Computer | Format-ServerName)" -throw
            return;
        }

        foreach($Computer in $ComputerName){
            try{
                Invoke-Command -ComputerName $Computer -ScriptBlock{
                    New-NetFirewallRule -DisplayName $using:Name -Direction $using:Direction -Protocol $using:Protocol -LocalPort $using:Port -Action $using:Action | Out-Null
                }
            }
            catch{
                Add-EventLogEntry -Computer $Computer -EntryType Error -Message "Could not set firewall rule $Name on $($Computer | Format-ServerName)`r`n(Name: $Name, Port: $Port, Protocol: $Protocol, Direction:$Direction, Action: $Action)" -throw
                return;
            }
        }

        # 'EC2AMAZ-GC6HTQ7', 'EC2AMAZ-0N5FN3S', 'EC2AMAZ-TI07TEV' | %{
        #     Write-Host $_ -ForegroundColor Green
         
        #     Invoke-Command -ComputerName $_ -ScriptBlock{
         
        #         #general sql ports
        #         New-NetFirewallRule -DisplayName "SQL Server" -Direction Inbound –Protocol TCP –LocalPort 2020 -Action allow
        #         New-NetFirewallRule -DisplayName "SQL Admin Connection" -Direction Inbound –Protocol TCP –LocalPort 1434 -Action allow
        #         New-NetFirewallRule -DisplayName "SQL Database Management" -Direction Inbound –Protocol UDP –LocalPort 1434 -Action allow
         
        #         #port 5022 for AA
        #         New-NetFirewallRule -DisplayName "SQL Server Mirroring" -Direction Inbound –Protocol TCP –LocalPort 5022 -Action allow
        #         New-NetFirewallRule -DisplayName "SQL Server Mirroring" -Direction OutBound –Protocol TCP –LocalPort 5022 -Action allow
        #     }
        # }
    }
    end{
        
    }
}