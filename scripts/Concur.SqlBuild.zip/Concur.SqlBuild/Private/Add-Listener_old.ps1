function Add-Listener_old{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline)]
        [string]$ComputerName,
        [Parameter(Mandatory)]
        [PSCredential]$Credential,
        [Parameter(Mandatory)]
        [string[]]$ListenerIPs,
        [string]$RoleType = 'dbsql',
        [string]$Name
    )
    begin{
        $Config = Get-Configuration 
        $roleConfig = Get-RoleTypeConfiguration -Name $RoleType 

        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
    }
    process{

        $mask = Get-ComputerSubnetMask -ComputerName $ComputerName 
        if([System.String]::IsNullOrWhiteSpace($mask)){
            $ComputerName | Add-EventLogEntry -EntryType Error -Message "Could not get the subnet mask on computer $ComputerName`r`nThe listener was notcreated."
            return;
        }

        function Get-RandomName{
            param(
                [string]$ComputerName
            )
        
            
                
            $charcodes = 97..122
            $numChars = 48..57
                
            # Convert allowed character codes to characters
            $allowedChars = $charcodes | ForEach-Object { [char][byte]$_ }
            $allowedChars = $allowedChars + $numChars | ForEach-Object { [char][byte]$_ }
            $LengthOfName = 8
        
            if($ComputerName.ToLower().StartsWith('vpc')){
                # Generate computer name
                $lst = ($allowedChars | Get-Random -Count $LengthOfName) -join ""
                $lst = $lst.Insert(4, '-')
                $lst = $lst.Insert(0, ($ComputerName.ToLower().SubString(0, $ComputerName.ToLower().IndexOf('-')+1))).Replace('vpc', 'lst')
                return $lst
            }
        
            $lst = ($allowedChars | Get-Random -Count $LengthOfName) -join ""
            $lst = "lst-$($lst.Insert(4, '-'))"
            return $lst
        
        }

        if([System.String]::IsNullOrWhiteSpace($Name)){
            $Name = Get-RandomName -ComputerName $ComputerName
        }
        
        
        if([System.String]::IsNullOrWhiteSpace($name)){
            $ComputerName | Add-EventLogEntry -EntryType Error -Message "Could not create a random listener name for computer $ComputerName.`r`nDetailed Exception:`r`n$($_ | Format-List -Force | Out-String)"
            return;
        }

        $ComputerName | Add-EventLogEntry -EntryType Information -Message "Listener Name is: $Name"

        try{
            $srv = new-object Microsoft.SqlServer.Management.smo.Server ($ComputerName | Format-ServerName -AddPort)
            if(!(Test-AlwaysOnGroup -ComputerName $ComputerName -Name $roleConfig.availabilitygroupname)){
                $ComputerName | Add-EventLogEntry -EntryType Error -Message "An AvailabilityGroup could not be found on computer $ComputerName.`r`nDetailed Exception:`r`n$($_ | Format-List -Force | Out-String)"
                return;
            }

            #NOTE:  This should not be handled this way...but due to time constraints...
            if($srv.AvailabilityGroups[0].AvailabilityGroupListeners.Count -gt 0){
                $ComputerName | Add-EventLogEntry -EntryType Warning -Message "An AvailabilityGroupListener already exists on the availability group on $ComputerName."
                return;
            }
            $ComputerName = $srv.AvailabilityGroups[0].PrimaryReplicaServerName
        }
        catch{
            $ComputerName | Add-EventLogEntry -EntryType Error -Message "Could not retrieve primary replica name from $ComputerName.`r`nDetailed Exception:`r`n$($_ | Format-List -Force | Out-String)"
            return;
        }
        finally{
            if($srv){
                $srv.ConnectionContext.Disconnect();
            }
        }


        $ClusterName = Invoke-Command -ComputerName $ComputerName -ScriptBlock{
            return Get-Cluster | Select-Object -ExpandProperty name
        }

        if([System.String]::IsNullOrWhiteSpace($ClusterName)){
            throw "Could not get name of cluster for computer $ComputerName"
            $ComputerName | Add-EventLogEntry -EntryType Error -Message "Could not get cluster name for computer $ComputerName.`r`nDetailed Exception:`r`n$($_ | Format-List -Force | Out-String)"
            return;
        }      

        $username = $Credential.GetNetworkCredential().UserName | Format-LoginName -Separator '@'

        $bString = [System.Runtime.InteropServices.marshal]::SecureStringToBSTR($Credential.Password)
        $password = [System.Runtime.InteropServices.marshal]::PtrToStringAuto($bString)
        $base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f $username,$password)))
     
        [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

        try{

            $payload = @{
                location = 'tools'
                domain = (Get-Domain).ToLower()
                listenerName = $Name.ToLower()
                clusterName = $ClusterName.ToLower()
            }

            $uri = "$($Config.listenerapi)/adAgent/createListener"
            Invoke-RestMethod -Uri $uri -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -Method Post -ContentType 'application/json' -Body ($payload | ConvertTo-Json -Compress) 
        }
        catch{
            $ComputerName | Add-EventLogEntry -EntryType Error -Message "There was an error in calling the createListener API located at $uri on computer $ComputerName.`r`nDetailed Exception:`r`n$($_ | Format-List -Force | Out-String)"
            return;
        }

        try{
            $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($ComputerName | Format-ServerName -AddPort)
            $listener = New-Object Microsoft.SqlServer.Management.Smo.AvailabilityGroupListener $srv.AvailabilityGroups[0], $Name 
            $listener.PortNumber = $Config.Port 

            foreach($ip in $ListenerIPs){
                $listenerIP = New-Object Microsoft.SqlServer.Management.Smo.AvailabilityGroupListenerIPAddress($listener)
                $listenerIP.IsDHCP = $false
                $listenerIP.IPAddress = $ip
                $listenerIP.SubnetIP = $ip.Substring(0,$ip.LastIndexOf('.'))+'.0'
                $listenerIP.SubnetMask = $mask #$config.listenersubnet #'255.255.255.0'  #'255.255.248.0'     # was 255.255.255.0
                $listener.AvailabilityGroupListenerIPAddresses.Add($listenerIP)
            }
            $listener.Create();

            Set-SPN -ComputerName $Name.ToLower() -AccountName $roleConfig.sqlserviceaccount -Credential $Credential 

        }
        catch{
            $ComputerName | Add-EventLogEntry -EntryType Error -Message "There was an error creating the listener on computer $ComputerName.`r`nDetailed Exception:`r`n$($_ | Format-List -Force | Out-String)"
        }
        finally{
            if($srv){
                $srv.ConnectionContext.Disconnect();
            }
        }


    }
    end{

    }
}