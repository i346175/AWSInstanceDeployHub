function Test-EndPoint{
    <#
    .SYNOPSIS
    Tests if an endpoint exists
    
    .DESCRIPTION
    Tests if an endpoint exists
    
    .PARAMETER ComputerName
    The name of the computer to test endpoint existance
    
    .PARAMETER Name
    The name of the endpoint to test for
    
    .EXAMPLE
    $ComputerName | Test-EndPoint -Name 'hadr_endpoint'
    
    .EXAMPLE
    Test-EndPoint -ComputerName 'computername' -Name 'hadr_endpoint'

    .NOTES
    General notes
    #>
    
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$Name
    )
    begin{
        $objects = New-Object System.Collections.Generic.List[PSCustomObject]
    }
    process{
        foreach($Computer in $ComputerName){
            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                if(!($srv.Endpoints[$Name])){
                    [void]$objects.Add([PSCustomObject]@{
                        ComputerName = $Computer
                        Exists = $false
                    });
                    return;
                }
                [void]$objects.Add([PSCustomObject]@{
                    ComputerName = $Computer
                    Exists = $true
                });
            }
            catch{
                throw $_ 
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }
    }
    end{
        return ![bool]($objects | Where-Object{$_.Exists -eq $false})
    }
}