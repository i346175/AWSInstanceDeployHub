function Invoke-ClusterListenerConfiguration{
    <#
    .SYNOPSIS
    Sets the cluster listener configuration
    
    .DESCRIPTION
    Sets the cluster listener configuration
    
    .PARAMETER ComputerName
    The name of the computer 
    
    .EXAMPLE
    An example
    
    .NOTES
    General notes
    #>
    
    [cmdletbinding()]
    param(
        [Parameter(Mandatory)]
        [string[]]$ComputerName
    )
    begin{

    }
    process{

        $Computer = $ComputerName | Select-Object -First 1 

        if(!($Computer | Test-Listener)){
            $Computer | Add-EventLogEntry -EntryType Warning -Message "No listener counld be found on the alwayson group."
            return;
        }

        Invoke-Command -ComputerName $Computer -ScriptBlock{
            Get-Cluster | Get-ClusterResource | Where-Object{$_.ResourceType -eq 'SQL Server Availability Group'} | ForEach-Object{
                $Name = $_.Name 
                Get-Cluster | Get-ClusterResource | Where-Object{$_.OwnerGroup -eq $Name -and $_.ResourceType -eq 'Network Name'} | Set-ClusterParameter RegisterAllProvidersIP 0 
                Get-Cluster | Get-ClusterResource | Where-Object{$_.OwnerGroup -eq $Name -and $_.ResourceType -eq 'Network Name'} | Set-ClusterParameter HostRecordTTL 120
            }
        
            Get-Cluster | Get-ClusterResource | Where-Object{$_.ResourceType -eq 'SQL Server Availability Group'} | Stop-ClusterResource
            Get-Cluster | Get-ClusterResource | Where-Object{$_.ResourceType -eq 'SQL Server Availability Group'} | Start-ClusterResource
        }

    }
    end{

    }
}