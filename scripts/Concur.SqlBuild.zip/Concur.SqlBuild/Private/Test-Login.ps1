function Test-Login{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$Name 
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
        $objects = New-Object System.Collections.Generic.List[PSCustomObject]
    }
    process{
        foreach($Computer in $ComputerName){
            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                if($srv.Logins[$Name]){
                    [void]$objects.Add([PSCustomObject]@{
                        ComputerName = $Computer
                        Exists = $true
                    });
                    return;
                }
                #$Computer | Add-EventLogEntry -EntryType Warning -Message "Login $Name could not be found on computer $Computer."
                [void]$objects.Add([PSCustomObject]@{
                    ComputerName = $Computer
                    Exists = $false
                });
            }
            catch{
                throw $_ 
            }
            finally{
                $srv.ConnectionContext.Disconnect()
            }
            
        }
    }
    end{
        return ![bool]($objects | Where-Object{$_.Exists -eq $false})
    }
}