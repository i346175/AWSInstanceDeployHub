function Test-ADCredential {
    <#
    .SYNOPSIS
    Tests whether or not a credential is valid or not
    
    .DESCRIPTION
    Tests whether or not a credential is valid or not
    
    .PARAMETER Credential
    The credential you want to check
    
    .PARAMETER Domain
    The domain to check the credential against
    
    .OUTPUTS
    True or False
    
    .EXAMPLE
    Test-ADCredential -Credential (get-credential)
    
    .NOTES
    General notes
    #>    
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory)]
        [PSCredential]$Credential
    )
    begin{
        Add-Type -AssemblyName System.DirectoryServices.AccountManagement
    }
    process{
        $ct = [System.DirectoryServices.AccountManagement.ContextType]::Domain
        $pc = New-Object System.DirectoryServices.AccountManagement.PrincipalContext($ct, (Get-Domain))
        return $pc.ValidateCredentials(($Credential.GetNetworkCredential().UserName), ($Credential.GetNetworkCredential().Password));
    }
    end{

    }
    
}
    
    
    
    
    
    