function Add-Login{
    [cmdletbinding(DefaultParameterSetName='default')]
    param(
        [Parameter(Mandatory, ParameterSetName='sqllogin', ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [Parameter(Mandatory, ParameterSetName='default', ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory, ParameterSetName='default')]
        [Parameter(Mandatory, ParameterSetName='sqllogin')]
        [string]$Name,
        [Parameter(ParameterSetName='default')]
        [Parameter(ParameterSetName='sqllogin')]
        [string[]]$ServerRole,
        [Parameter(ParameterSetName = 'sqllogin')]
        [string]$SID
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
    }
    process{
            
        foreach($Computer in $ComputerName){
            try{
                
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                if($Computer | Test-Login -Name ($Name | Format-LoginName -DomainType DN)){
                    $Computer | Add-EventLogEntry -EntryType Warning -Message "Login $Name already exists on computer $Computer"
                    return;
                }

                $LogType = Get-LoginType -Name $Name

                if($LogType.LoginType -ne [LoginType]::SqlLogin){
                    $Name = $Name | Format-LoginName -DomainType DN
                    $Login = New-Object Microsoft.SqlServer.Management.Smo.Login($srv, $Name)
                    $Login.LoginType = [Microsoft.SqlServer.Management.Smo.LoginType]$LogType.LoginType 
                    $Login.Create();
                    $srv.Logins.Refresh();
                    foreach($role in $ServerRole){
                        $srv.Roles[$role].AddMember($Name);
                    }
                    return;
                }

                #if the login can't be determined in AD it assumed to be a sql login.  If the SID is missing,
                #it's assumed that the login is incorrectly specified in the config file.
                if([System.String]::IsNullOrWhiteSpace($SID)){
                    $Computer | Add-EventLogEntry -EntryType Warning -Message "Login $Name does not exist in AD as a user or a group and the required SID was not supplied for the login.`r`nThe login will not be added to computer $Computer."
                    return;
                }

                try{
                    $Credential = Get-Password -Name $Name 
                }
                catch{
                    $Computer | Add-EventLogEntry -EntryType Warning -Message "The password for login $Name could not be retrieved on computer $Computer."
                    return;
                }

                #$Credential = New-Object System.Management.Automation.PSCredential ('TestLogin', (ConvertTo-SecureString 'P@55w0rd0%^&' -AsPlainText -Force))

                #$Login = $srv.Logins | Where-Object{$_.sid -eq ($SID | Convert-HexStringToByte)}
                if(Test-SID -ComputerName $Computer -SID $SID){
                    $Computer | Add-EventLogEntry -EntryType Warning -Message "The login $($Name) is already using sid $sid on computer $Computer."
                    return;
                }

                $Login = New-Object Microsoft.SqlServer.Management.Smo.Login($srv, ($Credential.GetNetworkCredential().UserName))
                $Login.LoginType = [Microsoft.SqlServer.Management.Smo.LoginType]::SqlLogin
                $Login.SID = ($SID | Convert-HexStringToByte);
                $Login.PasswordPolicyEnforced = $true;
                $Login.PasswordExpirationEnabled = $true;
                $Login.Create($Credential.Password, [Microsoft.SqlServer.Management.smo.LoginCreateOptions]::MustChange);
                foreach($role in $ServerRole){
                    $srv.Roles[$role].AddMember($name);
                }
                return;
            }
            catch{
                $Computer | Add-EventLogEntry -EntryType Warning -Message "There was an error adding login $($Name) to computer $Computer.`r`nDetailed Exception:`r`n$($_ | Format-List -Force | Out-String)"
                return;
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }

    }
    end{

    }
}