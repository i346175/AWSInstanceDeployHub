function Invoke-RoleTypeConfiguration{
    <#
    .SYNOPSIS
    Configures a sql server to the properties specified in the role type
    
    .DESCRIPTION
    Configures a sql server to a specified role type        
    
    .PARAMETER ComputerName
    The name(s) of the computers to configure
    
    .PARAMETER Name
    The name of the role (db0, dbexp0, dbexp1...etc..)
    
    .EXAMPLE
    $ComputerName | Invoke-RoleConfiguration -Name db0
    
    .NOTES
    General notes
    #>
    
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [string]$Name = 'dbsql',
        [Parameter(Mandatory)]
        [PSCredential]$Credential,
        [string]$ListenerName
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
        $roleConfig = Get-RoleTypeConfiguration -Name $Name
    }
    process{
        try{
            if(!$roleConfig){
                $ComputerName | Add-EventLogEntry -EntryType Error -Message "The role type information for role $Name was not loaded."
            }

            if(!(Test-ADCredential -Credential $Credential)){
                $ComputerName | Add-EventLogEntry -EntryType Error -Message "The AD account credential $($Credential.UserName) could not be validated."
                return;
            }

            if(![System.String]::IsNullOrWhiteSpace($ListenerName) -and (Test-Connection -ComputerName $ListenerName -Count 2 -Quiet)){
                $ComputerName | Add-EventLogEntry -EntryType Error -Message "The listener name $ListenerName is already in use."
                return;
            }
            
            foreach($db in $roleConfig.dbs){
                $ComputerName | Get-Backup -URI $db.uri -Destination $db.bakfile 
                $ComputerName | Invoke-Restore -Name $db.name -BackupFile $db.bakfile  
            }
        }
        catch{
            $ComputerName | Add-EventLogEntry -EntryType Error -Message "There was an error while configuring $ComputerName for SQL backup and restoration.`r`nDetailed Exception:$($_ | Format-List -Force | Out-String)"
        }
        try{
            if (Get-Service -Name ClusSvc -ErrorAction SilentlyContinue) {
                #do alwayson initial config here...Adding both group and database
                
                #$ComputerName | Add-AvailabilityGroup -Name $roleConfig.availabilitygroupname
                Add-AvailabilityGroup -ComputerName $ComputerName -Name $roleConfig.availabilitygroupname -DatabaseHealthTrigger
                foreach($db in $roleConfig.dbs | Where-Object{$_.hadr -eq $true}){
                    $ComputerName | Add-AvailabilityDatabase -Name $db.name -GroupName $roleConfig.availabilitygroupname
                }

                #create listener here...
                $IPs = Get-CFNListenerIPAddresses -ComputerName $ComputerName | Select-Object -ExpandProperty IP 

                if(!($IPs)){
                    $ComputerName | Add-EventLogEntry -EntryType Error -Message "No IP addresses for the listeners were found on computer $ComputerName.`r`nDetailed Exception:$($_ | Format-List -Force | Out-String)"
                }
                else{
                    $env:COMPUTERNAME | Add-Listener -Credential $Credential -ListenerIPs $IPs -Name $ListenerName
                    Invoke-ClusterListenerConfiguration -ComputerName $ComputerName 
                    #NOTE:  This code below is not finished...
                    Set-ReadOnlyRouting -ComputerName $ComputerName
                }
                # Create the DNS CName based on the Listener's name. 
                Add-DNSCname -listener $True
                
                # Create SQL Listener EC2 Tags on all nodes of the cluster. Refer: CSCI-6009
                $SQLListener = Get-ItemPropertyValue -Path "HKLM:\Software\CamConfig\" -Name listener_name
                Add-ListenerEc2Tag -ComputerName $ComputerName -ListenerName $SQLListener
            }
            else 
            {
             # Create the DNS CName based on the Computer name. 
             Add-DNSCname -listener $False
            }
        }
        catch{
            $ComputerName | Add-EventLogEntry -EntryType Error -Message "There was an error while configuring $($ComputerName)'s cluster configuration.`r`nDetailed Exception:$($_ | Format-List -Force | Out-String)"
        }
        try{
            #if blank, just skip.  They don't HAVE to have sql files...
            if(![System.String]::IsNullOrEmpty($roleConfig.dbscriptlocation)){
                $ComputerName | Invoke-SqlScripts -Name $roleConfig.dbscriptlocation 
            }
            
            #this one works a bit differently from the rest...this reads the config file directly and just creates the linked servers..
            #this should work like the rest do
            #TODO:  Make this pass in the linked server params...
            #$ComputerName | Add-LinkedServer -RoleType $Name -Force

            foreach($cnfg in $roleConfig.sp_config){
                $ComputerName | Set-SPConfiguration -Name $cnfg.Name -Value $cnfg.Value 
            }

            foreach($login in $roleConfig.logins){
                #$ComputerName | Add-Login @login
                if($login.PSObject.Properties.Name -match 'sid'){
                    $ComputerName | Add-Login -Name $login.Name -ServerRole $login.serverrole -SID $login.sid 
                }
                else{
                    $ComputerName | Add-Login -Name $login.Name -ServerRole $login.serverrole 
                }
            }

            # if([bool]$roleConfig.incthost){
            #     $ComputerName | Add-CTHost 
            # }
        }
        catch{
            $ComputerName | Add-EventLogEntry -EntryType Error -Message "There was an error while configuring computer $ComputerName for role type $Name.`r`nDetailed Exception:$($_ | Format-List -Force | Out-String)"
        }
    }
    end{

    }
}