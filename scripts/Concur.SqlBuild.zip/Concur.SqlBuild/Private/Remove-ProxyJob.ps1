function Remove-ProxyJob{
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$ProxyName
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
    }
    process{
        foreach($Computer in $ComputerName){
            try{
                
                $jobNames = new-object System.Collections.Generic.List[string];

                $srv = new-object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                foreach($job in $srv.JobServer.Jobs){
                    foreach($jobstep in $job.JobSteps | Where-Object{$_.ProxyName -eq $ProxyName}){
                        [void]$jobNames.Add($job.Name);
                    }
                }

                foreach($Name in $jobNames){
                    $srv.JobServer.Jobs[$Name].Drop();
                }

            }
            catch{
                $Computer | Add-EventLogEntry -EntryType Warning -Message "There was an error dropping the proxy jobs from the server.`r`nThe detailed exception is:`r`n$($_ | Format-List -Force | Out-String)"
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
            
        }
    }
    end{

    }
}