function Test-SqlConnection{
<#
.SYNOPSIS
Test a sql server connection on a server

.DESCRIPTION
Test a sql server connection on a server

.PARAMETER ServerName
The name of the server

.PARAMETER retry
The number of times to retry the connection

.PARAMETER ConnectTimeout
The amount of time in seconds to try to connect before timing out

.PARAMETER SleepSeconds
The number of seconds to sleep between retries

.OUTPUTS
True or False 

.EXAMPLE
Test-SqlConnection -ComputerName SEAPR1DB1001 -rety 5 -ConnectTimeout 60 -SleepSeconds 5

.NOTES
General notes
#>    
    [cmdletbinding()]
    param(
        [Parameter(Mandatory=$true, ValueFromPipeline=$true)]
        [Alias('ComputerName', 'CN', 'PhysicalName')]
        [string]$ServerName,
        [Parameter(Mandatory=$false)]
        [ValidateRange(1,10)]
        [int]$retry = 4,
        [Parameter(Mandatory=$false)]
        [ValidateRange(1,10)]
        [int]$ConnectTimeout = 5,
        [Parameter(Mandatory=$false)]
        [ValidateRange(1,120)]
        [int]$SleepSeconds = 5
    )
    begin{
        
    }
    process{

        $ServerName = $ServerName | Format-ServerName -AddPort -AddTCPPrefix

        $sqlConn = New-Object Microsoft.SqlServer.Management.Common.ServerConnection $ServerName
        #need to set both, if you just set connecttimeout it will still do 60 seconds if 
        #statementtimeout is not set.  SMO is full of these kinds of things...
        $sqlConn.ConnectTimeout = $ConnectTimeout
        $sqlConn.StatementTimeout = $ConnectTimeout  
        [int]$i = 1;

        while($i -le $retry){
            try{
                Write-Verbose "Connecting to server $($ServerName | Format-ServerName);  Count = $i"
                $sqlConn.Connect();
                if($sqlConn.IsOpen){
                    Write-Verbose "Connection to $($ServerName | Format-ServerName) succeeded."
                    return $true;
                }

                Write-Verbose "Connection to $($ServerName | Format-ServerName) failed.  Sleeping for $SleepSeconds seconds..."

                Start-Sleep -Seconds $SleepSeconds
                $i++;
            }
            catch{
                Write-Verbose "Connection to $($ServerName | Format-ServerName) failed.  `nException:  $($_ | out-string)"
                Write-Verbose "Sleeping for $SleepSeconds seconds..."
                Start-Sleep -Seconds $SleepSeconds
                $i++;
            }
            finally{
                $sqlConn.Disconnect();
            }
        }
        return $false;
    }
    end{

    }
}

