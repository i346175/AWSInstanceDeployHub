using namespace Microsoft.SqlServer.Management.Common;
using namespace Microsoft.SqlServer.Management.smo;
using namespace System.Collections.Generic;

function Set-TempDB{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [switch]$Force
    )
    begin{
        $mainConfig = Get-Configuration #just to get the port to pass to the invoke-command below to reset tempdb files...
        $config = Get-SqlDefaultConfiguration
        $tempDBDir = $config.storage | Where-Object{$_.label -eq 'tempdb'} | Select-Object -ExpandProperty path
        $tempLogDir = $config.storage | Where-Object{$_.label -eq 'log'} | Select-Object -ExpandProperty path
    }
    process{

        foreach($Computer in $ComputerName){
            $local = $env:computername -eq $Computer 

            $srv = [Server]::new(($Computer | Format-ServerName -AddPort));
            $srv.ConnectionContext.TrustServerCertificate = $true;

            if($local){
                $pathExists = (Test-Path -Path $tempDBDir -PathType Container)
            }
            else{
                $pathExists = Invoke-Command -ComputerName $Computer -ScriptBlock{
                    if(!(Test-Path -Path $using:tempDBDir -PathType Container)){
                        New-Item -ItemType Directory -Path $using:tempDBDir -Force | Out-Null
                    }
                    return (Test-Path -Path $using:tempDBDir -PathType Container)
                }
            }

            if(!$pathExists){
                $Computer | Add-EventLogEntry -EntryType Warning -Message "The default directory for tempdb $tempDBDir was not found on computer $Computer."
                throw "The default directory for tempdb $tempDBDir was not found on computer $Computer."
            }


            
            # tempdb files can have worktable pages that make it nigh impossible
            # to drop the database files.  The only way to consistently drop the files is to 
            # stop the service, restart it in mimimal mode (-f) and only allow specific connections (/m"fixTempDB" via the ApplicationName below) 
            # and drop the files that way.  Unfortunately, this doesn't drop the files on disk; we have to manually remove the files
            $tempdb = $srv.Databases | Where-Object{$_.Name -eq 'tempdb'}
            if($Force){
                $tempFiles = New-Object System.Collections.Generic.List[PSCustomObject]
                foreach($FileGroup in $tempdb.FileGroups){
                    foreach($File in $FileGroup.Files){  #} | Where-Object{$_.Name -ne 'tempdev'}){
                        [void]$tempFiles.Add([PSCustomObject]@{
                            Name = $File.Name
                            FileName = $File.FileName 
                            Command = "ALTER DATABASE tempdb REMOVE FILE $($File.Name);"
                        });
                    }
                }


                if($local){
                    Get-Service MSSQLSERVER | Stop-Service -Force | Out-Null
                    NET START MSSQLSERVER /f /m"fixTempDB" | Out-Null
                    #just some time for recovery...
                    Start-Sleep -Seconds 3
                }
                else{
                    invoke-command -ComputerName $Computer -ScriptBlock{
                        Get-Service MSSQLSERVER | Stop-Service -Force | Out-Null
                        NET START MSSQLSERVER /f /m"fixTempDB" | Out-Null
                        #just some time for recovery...
                        Start-Sleep -Seconds 3
                    }
                }
                    

                try{
                    #drop all files except tempdev
                    $srvCn = [ServerConnection]::new(($Computer | Format-ServerName -AddPort));
                    $srvCn.TrustServerCertificate = $true;
                    $srvCn.ApplicationName = 'fixTempDB';
                    foreach($file in $tempFiles | Where-Object{$_.Name -ne 'tempdev'}){
                        [void]$srvCn.ExecuteNonQuery($file.Command);
                        if($local){
                            Remove-Item -Path $file.FileName -Force | Out-Null;
                        }
                        else{
                            Invoke-Command -ComputerName $Computer -ScriptBlock{
                                param(
                                    $fileName
                                )
                                    
                                Remove-Item -Path $fileName -Force | Out-Null;

                            } -ArgumentList $file.FileName
                        }
                            
                    }
                        
                    #we don't care if the database file is already on this path...update the location anyway...
                    $cmd = "ALTER DATABASE tempdb 
                    MODIFY FILE (NAME = tempdev, FILENAME = '$($tempDBDir)\tempdb.mdf');"
                    [void]$srvCn.ExecuteNonQuery($cmd);

                    if($local){
                        NET STOP MSSQLSERVER | Out-Null
                    }
                    else{
                        Invoke-Command -ComputerName $Computer -ScriptBlock{
                            NET STOP MSSQLSERVER | Out-Null
                        }
                    }
                        
                }
                catch{
                    throw "Error in setting tempdb on $Computer`r`nException:`r`n$($_ | Format-List -Force | Out-String)" 
                }
                finally{
                    $srvCn.Disconnect();
                    if($local){
                        Get-Service MSSQLSERVER | Stop-Service -Force | Out-Null
                        Get-Service MSSQLSERVER | Start-Service | Out-Null
                        Get-Service SQLSERVERAGENT | Start-Service | Out-Null
                    }
                    else{
                        Invoke-Command -ComputerName $Computer -ScriptBlock{
                            Get-Service MSSQLSERVER | Stop-Service -Force | Out-Null
                            Get-Service MSSQLSERVER | Start-Service | Out-Null
                            Get-Service SQLSERVERAGENT | Start-Service | Out-Null
                        }
                    }
                        
                }
            }
            else{
                foreach($FileGroup in $tempdb.FileGroups){
                    foreach($File in $FileGroup.Files | Where-Object{$_.Name -ne 'tempdev'}){
                        if($local){
                            Restart-Service MSSQLSERVER -Force | Out-Null
                        }
                        else{
                            Invoke-Command -ComputerName $Computer -ScriptBlock{
                                Restart-Service MSSQLSERVER -Force | Out-Null
                            }
                        }
                        
                        $cmd = "USE tempdb; 
                            DBCC SHRINKFILE('$($File.Name)', EMPTYFILE);
                            ALTER DATABASE tempdb REMOVE FILE $($File.Name);"
                        try{
                            [void]$srv.ConnectionContext.ExecuteNonQuery($cmd);
                        }
                        catch{                       
                            $Computer | Add-EventLogEntry -EntryType Warning -Message "There was an error in trying to shrink or remove file $($File.Name) on computer $Computer"
                        }
                    }
                }
            }
            

            #TODO:  Acutally check that the tempdb has come out of recovery...I only hit this error once...but it still should check
            Start-Sleep -Seconds 5

            #shrink and resize tempdev file
            [void]$srv.ConnectionContext.ExecuteNonQuery("USE tempdb; DBCC SHRINKFILE(tempdev,50)");
            [void]$srv.ConnectionContext.ExecuteNonQuery("ALTER DATABASE tempdb MODIFY FILE(NAME = tempdev, FILENAME = '$(Join-Path -Path $tempDBDir -ChildPath 'tempdb.mdf')', SIZE = 50MB);");

            $coreCount = Get-CimInstance -ComputerName $Computer -ClassName 'Win32_Processor' | Measure-Object -Property NumberOfLogicalProcessors -Sum | Select-Object -ExpandProperty Sum
            $DeviceID = [System.IO.Path]::GetPathRoot($tempDBDir).ToString().Substring(0,1)
        
            if($local){
                $drive = Get-Volume | Where-Object{$_.DriveLetter -eq $DeviceID}
                $drvSpace = [PSCustomObject]@{
                    FreeSpaceMB = ($drive.SizeRemaining/1MB)
                    SizeMB = ($drive.Size/1MB)
                }
            }
            else{
                $drvSpace = Invoke-Command -ComputerName $Computer -ScriptBlock{
                    Get-Volume | Where-Object{$_.DriveLetter -eq $using:DeviceID} | %{
                        return [PSCustomObject]@{
                            FreeSpaceMB = ($_.SizeRemaining/1MB)
                            SizeMB = ($_.Size/1MB)
                        }
                    }
                }
            }

            if($null -eq $drvSpace){
                $Computer | Add-EventLogEntry -EntryType Error -Message "Could not get drive space for computer $Computer for device $DeviceID.  Cannot continue configuring tempdb..."
                return;
            }

            $size = [PSCustomObject]@{
                Size = $drvSpace.SizeMB 
                FreeSpace = $drvSpace.FreeSpaceMB 
                TenPctSize = (($drvSpace.SizeMB / 100) * 10)
                TenPctFreeSpace = (($drvSpace.FreeSpaceMB / 100) * 10)
            }
            $fileSizeMB = (($size.FreeSpace - $size.TenPctFreeSpace) / $coreCount)
            
            #resize tempdev file...
            #I was getting an error 'MODIFY FILE failed. Size is greater than MAXSIZE' sometimes in here, hence the 
            #completely dirty no good $fileSizeGB+1 for the MAXSIZE
            #TODO:  Find out why the above is happening...
            try{
                #[void]$srv.ConnectionContext.ExecuteNonQuery("ALTER DATABASE tempdb MODIFY FILE (NAME = tempdev, SIZE = $($fileSizeGB)GB, MAXSIZE = $($fileSizeGB+1)GB);");
                [void]$srv.ConnectionContext.ExecuteNonQuery("ALTER DATABASE tempdb MODIFY FILE (NAME = tempdev, SIZE = $([Math]::Truncate($fileSizeMB))MB, MAXSIZE = $([Math]::Truncate($fileSizeMB))MB);");
            }
            catch{
                $Computer | Add-EventLogEntry -EntryType Error -Message "There was an error while trying to set the size for the tempdev temp db data file on computer $Computer.`r`nThe exception was:`r`n$($_ | Format-List -Force | Out-String)"
            }
                #create tempdev1 through corecount-1 for tempdb files
            1..($coreCount-1) | ForEach-Object{
                try{
                    [void]$srv.ConnectionContext.ExecuteNonQuery("ALTER DATABASE tempdb ADD FILE (NAME = tempdev$($_), FILENAME = '$($tempDBDir)\tempdb_$($_).mdf', SIZE = $([Math]::Truncate($fileSizeMB))MB, MAXSIZE = $([Math]::Truncate($fileSizeMB))MB);");
                }
                catch{
                    $Computer | Add-EventLogEntry -EntryType Error -Message "There was an error while trying to set the size for the tempdev$($_) temp db data file on computer $Computer.`r`nThe exception was:`r`n$($_ | Format-List -Force | Out-String)"
                }
            }
            $srv.ConnectionContext.Disconnect();
        }

    }
    end{

    }
}
