function Revoke-ConnectAccess{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [string]$Name = 'guest'
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
    }
    process{
        foreach($Computer in $ComputerName){
            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                $perm = New-Object Microsoft.SqlServer.Management.smo.DatabasePermissionSet([Microsoft.SqlServer.Management.smo.DatabasePermission]::Connect)
                foreach($Database in $srv.Databases | Where-Object{!$_.IsSystemObject}){
                    if($Computer | Test-DatabaseUser -DatabaseName $Database.Name -Name $Name){
                        [void]$Database.Revoke($perm, $Name);
                    }
                }
            }
            catch{
                throw $_ 
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }
    }
    end{

    }
}