function Add-WindowsLogin{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$Name,
        [string]$LocalGroup,
        [string[]]$Right
    )
    begin{

    }
    process{
        
        $Name = $Name | Format-LoginName -DomainType NoDomain

        foreach($Computer in $ComputerName){
            
            if(!(Get-ADObject -Filter {(sAMAccountName -eq $Name)} -ErrorAction SilentlyContinue)){
                $Computer | Add-EventLogEntry -EntryType Warning -Message "Login or group $Name could not be found in Active Directory.  User or Group $Name was not added to computer $Computer."
                return;
            }

            if(![System.String]::IsNullOrWhiteSpace($LocalGroup)){
                invoke-command -ComputerName $Computer -ScriptBlock{

                    Add-LocalGroupMember -Group $using:LocalGroup -Member $using:Name -ErrorAction SilentlyContinue

                    # if($null -eq (net localgroup Administrators | Where-Object{$_ -match "$using:Name"})){
                    #     $GroupObj = [ADSI]"WinNT://$env:COMPUTERNAME/$using:LocalGroup"
                    #     $GroupObj.Add("WinNT://$using:Name")
                    # }
                }
            }

            if($Right){
                Grant-UserRight -ComputerName $Computer -Account $Name -Right $Right
            }
            
        }
    }
    end{

    }
}