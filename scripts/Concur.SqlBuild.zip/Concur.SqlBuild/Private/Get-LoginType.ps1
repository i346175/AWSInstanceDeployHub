function Get-LoginType{
    [cmdletbinding()]
    param(
        [string]$Name
    )
    begin{

    }
    process{
        
        $Name = $Name | Format-LoginName -DomainType NoDomain
        $obj = Get-ADUser -filter{samaccountname -eq $Name} -ErrorAction SilentlyContinue
        if($obj){
            return [PSCustomObject]@{
                Name = $obj.samaccountname 
                LoginType = [LoginType]::WindowsUser
            }
        }
        $obj = Get-ADGroup -filter{samaccountname -eq $Name} -ErrorAction SilentlyContinue
        if($obj){
            return [PSCustomObject]@{
                Name = $obj.samaccountname 
                LoginType = [LoginType]::WindowsGroup
            }
        }
        return [PSCustomObject]@{
            Name = $Name
            LoginType = [LoginType]::SqlLogin
        }
    }
    end{

    }
}