function Set-SqlPath{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
        $config = Get-SqlDefaultConfiguration
    }
    process{

        foreach($Computer in $ComputerName){
            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                $srv.DefaultFile = $config.storage | Where-Object{$_.label -eq 'data'} | Select-Object -ExpandProperty path 
                $srv.DefaultLog = $config.storage | Where-Object{$_.label -eq 'log'} | Select-Object -ExpandProperty path 
                $srv.BackupDirectory = $config.storage | Where-Object{$_.label -eq 'backup'} | Select-Object -ExpandProperty path 
                $srv.Alter();
            }
            catch{
                $Computer | Add-EventLogEntry -EntryType Warning -Message "Could not set either the data, log, or backup path on computer $Computer"
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }

            try{

                foreach($path in $config.storage | Select-Object -ExpandProperty path){
                    Invoke-Command -ComputerName $Computer -ScriptBlock{
                        New-Item -ItemType Directory -Path $using:path -Force | Out-Null
                    } 
                }

            }
            catch{
                $Computer | Add-EventLogEntry -EntryType Warning -Message "Could not create the directories for data, log, or backup on computer $Computer"
            }

        }

    }
    end{

    }
}