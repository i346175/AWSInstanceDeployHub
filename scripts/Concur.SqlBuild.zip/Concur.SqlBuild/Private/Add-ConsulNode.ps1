function Add-ConsulNode{
    param(
        [Parameter(Mandatory)]
        [string]$ServiceName,
        [Parameter(Mandatory)]
        [string]$ComputerName,
        [Parameter(Mandatory)]
        [string]$IPAddress,
        [Parameter(Mandatory)]
        [PSCredential]$Credential,
        [string[]]$Tags,
        [string]$Role = 'dbsql',
        [int]$Port = 2020
    )

    $token = Get-VaultToken #-Credential $Credential
    if([System.String]::IsNullOrWhiteSpace($token)){
        throw "Untable to retrieve vault token.  Cannot continue."
    }

    $headers = @{}
    $headers.Add("X-Vault-Token", $token)
    $headers.Add("ContentType", "application/json")
    try{
        $result = Invoke-RestMethod -Uri "https://vault.service.cnqr.tech/v1/consul/creds/dbsql" -Headers $headers 
        $token = $result.data.token
    }
    catch{
        $_ | Format-List -Force
        throw $_ 
    }

    $payload = [ordered]@{
        Datacenter = 'uspscc'
        Node = "$Role-$ComputerName"
        Address = "$IPAddress"
        NodeMeta = [ordered]@{
            status = 'up'
        }
        Service = [ordered]@{
            Service = "$ServiceName"
            Tags = @($Tage)
            Address = "$IPAddress"
            Port = $Port
        }
    }
    $json = $payload | ConvertTo-Json 

    $headers = @{}
    $headers.Add("X-Consul-Token", $token)
    $headers.Add("ContentType", "application/json")

    [System.Net.ServicePointManager]::CheckCertificateRevocationList = $false
    [System.Net.ServicePointManager]::Expect100Continue = $false
    [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

    $uri = [uri]::EscapeUriString("https://consul.service.cnqr.tech/v1/catalog/register");


    try{
        Invoke-RestMethod -Uri $uri -Method Put -ContentType 'application/json' -Body $json -Headers $headers | fl -Force
    }
    catch{
        $_ | Format-List -Force
    }

}