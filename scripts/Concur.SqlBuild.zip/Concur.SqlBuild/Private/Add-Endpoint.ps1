function Add-Endpoint{
    <#
    .SYNOPSIS
    Adds an andpoint to a computer
    
    .DESCRIPTION
    Adds an andpoint to a computer
    
    .PARAMETER ComputerName
    The name of the computer(s) to add the endpoint to
    
    .PARAMETER Name
    The name of the service account to grant the connection permission on...
    
    .EXAMPLE
    $ComputerName | Add-Endpoint -Name 'sa_sqlacct'
    
    .NOTES
    https://support.microsoft.com/en-us/help/2847723/cannot-create-a-high-availability-group-in-microsoft-sql-server-2012
    This code is required due to the security constraints.  If the system account doesn't have the alter availability group, the 
    creation of the availability group will fail...
    #>
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$Name 
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
        $Config = Get-Configuration
    }
    process{
 
        <#
        https://support.microsoft.com/en-us/help/2847723/cannot-create-a-high-availability-group-in-microsoft-sql-server-2012
        This code is required due to the security constraints.  If the system account doesn't have the alter availability group, the 
        creation of the availability group will fail...
        #>

        $Name = $Name | Format-LoginName -DomainType DN 

        if($ComputerName | Test-EndPoint -Name 'Hadr_endpoint'){
            $ComputerName | Add-EventLogEntry -EntryType Warning -Message "There is already an endpoint named $Name on computer(s) $($ComputerName -join ', ')"
            return;
        }
 
        foreach($Computer in $ComputerName){
            $cmd = "GRANT ALTER ANY AVAILABILITY GROUP TO [NT AUTHORITY\SYSTEM];
            GRANT CONNECT SQL TO [NT AUTHORITY\SYSTEM];
            GRANT VIEW SERVER STATE TO [NT AUTHORITY\SYSTEM];"
            
            $endPoint = "
            CREATE ENDPOINT [Hadr_endpoint]
                STATE=STARTED
                AS TCP (LISTENER_PORT = 5022, LISTENER_IP = ALL)
                FOR DATA_MIRRORING (ROLE = ALL, AUTHENTICATION = WINDOWS NEGOTIATE
            , ENCRYPTION = REQUIRED ALGORITHM AES)"
            
            try{
                $srv = new-object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                [void]$srv.ConnectionContext.ExecuteNonQuery($cmd);
                [void]$srv.ConnectionContext.ExecuteNonQuery($endPoint);
                [void]$srv.ConnectionContext.ExecuteNonQuery("GRANT CONNECT ON ENDPOINT::[Hadr_endpoint] TO [$Name];");
            }
            catch{
                $Computer | Add-EventLogEntry -EntryType Error -Message "There was an error in adding the endpoint to computer $Computer.`r`nDetailed Exception:`r`n$($_ | Format-List -Force | Out-String)"
                return;
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }

        }

    }
    end{

    }
}