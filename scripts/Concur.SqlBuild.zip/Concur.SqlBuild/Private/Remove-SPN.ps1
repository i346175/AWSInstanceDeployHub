function Remove-SPN{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$AccountName,
        [Parameter(Mandatory)]
        [PSCredential]$Credential
    )
    begin{
        $config = Get-Configuration 
    }
    process{
        
        foreach($Computer in $ComputerName){
            
            <#
            ComputerName   : vpc19-cqm4-9s70
            Specification  : 2020
            ServiceClass   : MSSQLSvc
            sAMAccountName : VPC19-CQM4-9S70$
            SPN            : MSSQLSvc/vpc19-cqm4-9s70.devtest.system.cnqr.tech:2020
            #>
    
            $username = ($Credential.GetNetworkCredential().UserName | Format-LoginName -Separator '@').ToLower()
     
            $bString = [System.Runtime.InteropServices.marshal]::SecureStringToBSTR($Credential.Password)
            $password = [System.Runtime.InteropServices.marshal]::PtrToStringAuto($bString)
            $base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f $username,$password)))
     
            #[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}
            [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
     
            $url = "$($config.spnapi)/spnAgent/spnDel"

            #of note, this thing is unforgiving...note the computerName.  if the 'N' is not capitolized...it will error.
            #the port must also be an int.  Your payload should look like this:
            <#
            {
                "domain":  "devtest.system.cnqr.tech",
                "computerName":  "vpc19-vvki-5vxn",
                "user":  "sa_sqlacct",
                "service":  "MSSQLSvc",
                "port":  2020
            }
            of note, the only way I could log into this was with a username in the format of:  snewman@devtest.system.cnqr.tech
            #>
            $payload = [ordered]@{
                domain = (Get-Domain).ToLower()
                computerName = $Computer.ToLower() 
                user = $AccountName.ToLower()
                service = 'MSSQLSvc'
                port = [int]$config.port
            }
            try{
                Invoke-RestMethod -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -ContentType "application/json" -Method Post -Uri $url -Body ($payload | ConvertTo-Json -Compress) -Proxy $config.proxy
            }
            catch{
                $Computer | Add-EventLogEntry -EntryType Warning -Message "There was an error removing the spn for account $AccountName to computer $Computer.`r`nDetailed Exception:`r`n$($_ | Format-List -Force | Out-String)"
                return;
            }

        }
    }
    end{

    }
}