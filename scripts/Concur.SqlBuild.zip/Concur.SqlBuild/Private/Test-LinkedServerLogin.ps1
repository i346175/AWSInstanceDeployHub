function Test-LinkedServerLogin{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$LinkedServerName,
        [Parameter(Mandatory)]
        [string]$Name 
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
        $objects = New-Object System.Collections.Generic.List[PSCustomObject]
    }
    process{
        foreach($Computer in $ComputerName){

            try{

                if(!($Computer | Test-LinkedServer -Name $LinkedServerName)){
                    [void]$objects.Add([PSCustomObject]@{
                        ComputerName = $Computer
                        Exists = $false
                    });
                    $Computer | Add-EventLogEntry -EntryType Warning -Message "Linked server $LinkedServerName was not found on computer $Computer while checking for the linked server login $Name."
                    continue;
                }

                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                if(!$srv.LinkedServers[$LinkedServerName].LinkedServerLogins[$Name]){
                    $Computer | Add-EventLogEntry -EntryType Warning -Message "Linked server login $Name was not found in $LinkedServerName on computer $Computer."
                    [void]$objects.Add([PSCustomObject]@{
                        ComputerName = $Computer
                        Exists = $false
                    });
                    $Computer | Add-EventLogEntry -EntryType Warning -Message "Linked server login $Name was not found on computer $Computer."
                    return;
                }
            }
            catch{
                throw $_ 
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }
    }
    end{
        return ![bool]($objects | Where-Object{$_.Exists -eq $false})
    }
}