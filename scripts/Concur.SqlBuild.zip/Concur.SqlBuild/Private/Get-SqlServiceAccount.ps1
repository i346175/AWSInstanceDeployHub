function Get-SqlServiceAccount{
    <#
    .SYNOPSIS
    Gets the account that the sql server service is currently running as
    
    .DESCRIPTION
    Gets the account that the sql server service is currently running as
    
    .PARAMETER ComputerName
    The name of the computer that the sql server service is running on

    .OUTPUTS
    Name           : MSSQLSERVER
    DisplayName    : SQL Server (MSSQLSERVER)
    Type           : SqlServer
    StartMode      : Auto
    ServiceState   : Running
    ServiceAccount : concurasp\sa_sqlacctsea_Q1Y19
    PSComputerName : seapr1db0001
    RunspaceId     : dfb23338-b3f0-4bd6-9121-63b2d75bf306

    Name           : SQLBrowser
    DisplayName    : SQL Server Browser
    Type           : SqlBrowser
    StartMode      : Disabled
    ServiceState   : Stopped
    ServiceAccount : NT AUTHORITY\LOCALSERVICE
    PSComputerName : seapr1db0001
    RunspaceId     : dfb23338-b3f0-4bd6-9121-63b2d75bf306

    Name           : SQLSERVERAGENT
    DisplayName    : SQL Server Agent (MSSQLSERVER)
    Type           : SqlAgent
    StartMode      : Auto
    ServiceState   : Running
    ServiceAccount : concurasp\sa_sqlacctsea_Q1Y19
    PSComputerName : seapr1db0001
    RunspaceId     : dfb23338-b3f0-4bd6-9121-63b2d75bf306
    
    .EXAMPLE
    Get-SqlServiceAccount -ComputerName seapr1db0001
    .NOTES
    

    #> 
    param(
        $ComputerName
    )

    if($ComputerName.ToUpper() -eq $env:COMPUTERNAME.ToUpper()){
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SqlWmiManagement")
        $wmi = New-Object ("Microsoft.SqlServer.Management.Smo.Wmi.ManagedComputer") $env:COMPUTERNAME
        [scriptblock]$sb = {
            if($_.ServiceAccount.Contains('\')){
                return $_.ServiceAccount.Split('\')[1]
            }
            return $_.ServiceAccount
        }
        #return $wmi.Services | Select-Object Name, DisplayName, Type, StartMode, ServiceState, ServiceAccount, @{n='NonFQDNServiceAccount'; e={$_.ServiceAccount.Split('\')[1]}} 
        return $wmi.Services | Select-Object Name, DisplayName, Type, StartMode, ServiceState, ServiceAccount, @{n='NonFQDNServiceAccount'; e=$sb} 
    }

    Invoke-Command -ComputerName $ComputerName -ScriptBlock{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SqlWmiManagement")
        $wmi = New-Object ("Microsoft.SqlServer.Management.Smo.Wmi.ManagedComputer") $env:COMPUTERNAME
        [scriptblock]$sb = {
            if($_.ServiceAccount.Contains('\')){
                return $_.ServiceAccount.Split('\')[1]
            }
            return $_.ServiceAccount
        }
        #$wmi.Services | Select-Object Name, DisplayName, Type, StartMode, ServiceState, ServiceAccount, @{n='NonFQDNServiceAccount'; e={$_.ServiceAccount.Split('\')[1]}}
        $wmi.Services | Select-Object Name, DisplayName, Type, StartMode, ServiceState, ServiceAccount, @{n='NonFQDNServiceAccount'; e=$sb}
    }

}