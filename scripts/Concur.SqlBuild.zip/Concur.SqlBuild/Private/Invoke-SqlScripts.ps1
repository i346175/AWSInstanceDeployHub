function Invoke-SqlScripts{
    <#
    .SYNOPSIS
    This executes the sql scripts from the sql\(jurisdiction) directory
    
    .DESCRIPTION
    This executes the sql scripts from the sql\(jurisdiction) directory
    
    .PARAMETER ComputerName
    The name(s) of the computers on which to apply the sql scripts
    
    .EXAMPLE
    $ComputerName | Invoke-SqlScripts 
    
    .EXAMPLE
    Invoke-SqlScripts -ComputerName <ComputerName>

    .NOTES
    General notes
    #>
    
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
        $config = Get-Configuration 
    }
    process{
        foreach($Computer in $ComputerName){
            try{
                $parent = Split-Path -Path $PSScriptRoot -Parent
                $sqlDir = [System.IO.Path]::Combine($parent, 'Config', 'sql', $config.jurisdiction);
                $srv = new-object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                foreach($file in (Get-ChildItem -Path $sqlDir -File | Where-Object{$_.Extension -eq '.sql'})){
                    $Name = $file.Name 
                    try{
                        [void]$srv.ConnectionContext.ExecuteNonQuery((Get-Content -Path $file.FullName | Out-String));
                    }
                    catch{
                        $Computer | Add-EventLogEntry -EntryType Warning -Message "There was an error executing file $Name on computer $Computer.`r`nException Details:`r`n$($_ | Format-List -Force | Out-String)"
                    }
                }
    
            }
            catch{
                $ComputerName | Add-EventLogEntry -EntryType Error -Message "There was an error executing file $Name on computer $Computer.`r`nException Details:`r`n$($_ | Format-List -Force | Out-String)"
                return;
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }
    }
    end{

    }
}