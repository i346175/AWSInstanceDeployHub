function Get-EventLogEntry{
    <#
    .SYNOPSIS
    This retrieves event log information for every computer supplied in the $ComputerName parameter
    
    .DESCRIPTION
    This retrieves event log information for every computer supplied in the $ComputerName parameter
    
    .PARAMETER ComputerName
    The name(s) of the computers that you want to see the event login information for
    
    .PARAMETER LogName
    The name of the event log (Application, System. Setup...etc...)
    
    .PARAMETER Source
    The source or 'ProviderName' of the application that published the error
    
    .PARAMETER EntryType
    The type of entry.  For example, Informational, Wanring, Error...etc..
    
    .PARAMETER MaxEvents
    The maximum number of events to return.  The default is 100.
    
    .EXAMPLE
    'seapr1db0500', 'seapr1db3016' | Get-EventLogEntry -LogName Application -Source MSSQLSERVER -EntryType Error

    .EXAMPLE 
    Get-EventLogEntry -ComputerName 'Server1','Server2' -LogName Application -Source MSSQLSERVER -EntryType Error -MaxEvents 1000
    
    .NOTES
    General notes
    #>
    
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        $LogName = 'Setup',
        $Source = 'SqlConfig',
        [ValidateSet('Information', 'Warning', 'Error', 'Verbose')]
        [string]$EntryType = 'Information',
        [int]$MaxEvents = 100
    )
    begin{
        $objects = New-Object System.Collections.Generic.List[PSCustomObject]
    }
    process{

        $filter = @{ 
            LogName=$LogName; 
            ProviderName=$Source;
            Level=[int][System.Diagnostics.EventLogEntryType]$EntryType 
            #StartTime=$Date; Id='1003' 
        }

        #some of the logging might log events to the local event log, so append the computer where this is running to the list...
        $ComputerName = $ComputerName + $env:COMPUTERNAME
        foreach($Computer in $ComputerName){
            foreach($evt in (Get-WinEvent -ComputerName $Computer -FilterHashtable $filter -MaxEvents $MaxEvents )){
                [void]$objects.Add([PSCustomObject]@{
                    ComputerName = $Computer 
                    TimeCreated = $evt.TimeCreated 
                    ProviderName = $evt.ProviderName 
                    Id = $evt.Id 
                    Message = $evt.Message
                });
            }
        }
    }
    end{
        return $objects
    }
}
