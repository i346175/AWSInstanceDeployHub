function Get-AvailabilityGroup{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName 
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")

        $objects = New-Object System.Collections.Generic.List[PSCustomObject]
    }
    process{

        foreach($Computer in $ComputerName){
            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                if($srv.AvailabilityGroups.Count -eq 0){
                    return $null;
                }
                foreach($Group in $srv.AvailabilityGroups){
                    [void]$objects.Add([PSCustomObject]@{
                        ComputerName = $Computer 
                        Name = $Group.Name 
                        PrimaryReplicaName = $Group.PrimaryReplicaServerName
                        Replicas = $Group.AvailabilityReplicas | Select-Object -ExpandProperty Name
                        Listeners = $Group.AvailabilityGroupListeners | Select-Object -ExpandProperty Name 
                    });
                }

            }
            catch{
                throw $_ 
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }

    }
    end{
        return $objects;
    }
}