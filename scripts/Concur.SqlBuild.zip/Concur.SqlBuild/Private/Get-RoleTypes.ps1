function Get-RoleTypes{
    [CmdletBinding()]
    param(
        
    )

    $objects = New-Object System.Collections.Generic.List[PSCustomObject]

    $parent = Split-Path -Path $PSScriptRoot -Parent
    $configFiles = [System.io.Path]::Combine($parent, "Config", "RoleTypes")

    Get-ChildItem -Path $configFiles -File | Where-Object{$_.Extension -eq ".json"} | ForEach-Object{
        [void]$objects.Add([PSCustomObject]@{
            Name = $_.BaseName
            FullName = $_.FullName
        });
    }

    return $objects;

}