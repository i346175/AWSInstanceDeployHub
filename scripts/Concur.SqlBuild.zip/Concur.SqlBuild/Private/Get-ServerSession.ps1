function Get-ServerSession{
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string]$ComputerName
    )
    begin{
        $regexIP = "^([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$"
    }
    process{
        if($ComputerName -match $regexIP){
            throw "You must supply a computer name and not an IP address for domain connected computers."
        }
        $option = New-PSSessionOption -ProxyAccessType NoProxyServer
        $session = New-PSSession -ComputerName $ComputerName -SessionOption $option
        return $session
    }
    end{
    }
}

