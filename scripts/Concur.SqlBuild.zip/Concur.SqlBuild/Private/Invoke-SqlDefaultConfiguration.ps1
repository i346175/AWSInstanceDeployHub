function Invoke-SqlDefaultConfiguration{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [PSCredential]$Credential,
        [string]$TimeZone = 'Pacific Standard Time'
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
        $Config = Get-SqlDefaultConfiguration
        $StdConfig = Get-Configuration 
    }
    process{
        
        try{

            if(![System.TimezoneInfo]::FindSystemTimeZoneById($TimeZone)){
                $ComputerName | Add-EventLogEntry -EntryType Error -Message "A time zone with the name $TimeZone could not be found." -throw 
                return;
            }

            foreach($Computer in $ComputerName){
                Invoke-Command -ComputerName $Computer -ScriptBlock{
                    Set-TimeZone -Id $using:TimeZone 
                }

                # enable tags in metadata
                Invoke-Command -ComputerName $Computer -ScriptBlock{
                    $instanceID = Invoke-WebRequest -Uri "http://169.254.169.254/latest/meta-data/instance-id" -UseBasicParsing | Select-Object -ExpandProperty content
                    aws ec2 modify-instance-metadata-options --instance-id $instanceID --instance-metadata-tags enabled > $null;
                }

                # set VPC Name environment variable
                $dName = Get-ADComputer $Computer | Select-Object -ExpandProperty DistinguishedName
                $vpcName = $dName.split(',')[1].split('=')[-1].ToLower();
                if([System.String]::IsNullOrWhiteSpace($vpcName)){
                    $ComputerName | Add-EventLogEntry -EntryType Warning -Message "There was an error getting the vpc name from the DistinguishedName for computer $Computer.`r`nThe VPCName environment variable was not set."
                    continue;
                }
                Invoke-Command -ComputerName $Computer -ScriptBlock{
                    [System.Environment]::SetEnvironmentVariable('VPCName',$using:vpcName,[System.EnvironmentVariableTarget]::Machine)
                } 
 
 
                
            }

            #set firewall rules before attempting anything...
            [int]$standardPort = $StdConfig.port
            $ComputerName | Set-WindowsFirewallRule -Name 'Sql Server' -Port $standardPort
            $ComputerName | Set-WindowsFirewallRule -Name 'Sql Admin Connection' -Port ($standardPort + 1)
            $ComputerName | Set-WindowsFirewallRule -Name 'Sql Database Management' -Port 1434 -Protocol UDP
            $ComputerName | Set-WindowsFirewallRule -Name 'Sql Server Mirroring' -Port 5022 
            $ComputerName | Set-WindowsFirewallRule -Name 'Sql Server Mirroring' -Port 5022 -Direction OutBound

        #         New-NetFirewallRule -DisplayName "SQL Server" -Direction Inbound –Protocol TCP –LocalPort 2020 -Action allow
        #         New-NetFirewallRule -DisplayName "SQL Admin Connection" -Direction Inbound –Protocol TCP –LocalPort 1434 -Action allow
        #         New-NetFirewallRule -DisplayName "SQL Database Management" -Direction Inbound –Protocol UDP –LocalPort 1434 -Action allow
         
        #         #port 5022 for AA
        #         New-NetFirewallRule -DisplayName "SQL Server Mirroring" -Direction Inbound –Protocol TCP –LocalPort 5022 -Action allow
        #         New-NetFirewallRule -DisplayName "SQL Server Mirroring" -Direction OutBound –Protocol TCP –LocalPort 5022 -Action allow

            $ComputerName | Add-EventLogEntry -EntryType Information -Message "Starting default configuration of computer $ComputerName."

            #enable protocols for subsequent runs.  If they're disabled it reeks havok with some of the operations being performed in the configuration process...
            $ComputerName | Enable-Protocol -Protocol SM
            $ComputerName | Enable-Protocol -Protocol NP

            #initial validity test...
            if(!($ComputerName | Test-Server)){
                throw "Install cannot proceed."
            }

            #TODO:  Enable this code once they get the domain stuff fixed...
            # if(!(Test-ADCredential -Credential $Credential)){
            #     $ComputerName | Add-EventLogEntry -EntryType Error -Message "The AD account credential $($Credential.UserName) could not be validated."
            #     return;
            # }

            #set the agent in the registry before the port in case of subsequent runs...otherwise if this is run again the agent 
            #won't be able to start because the protocols would have been disabled.  This adds the host to the registry for the agent
            #so it can connect regardless of whether or not named pipes is enabled...
            $ComputerName | Set-SqlAgentHost 

            #this token must be set before doing any add-login type of stuff.  The token is required to retrieve 
            #credentials from vault
            $script:token = Get-VaultToken #-Credential $Credential
            if([System.String]::IsNullOrEmpty($script:token)){
                $ComputerName | Add-EventLogEntry -EntryType Error -Message "The token was not retrieved for credential $($Credential.UserName).`r`nConfiguration cannot continue."
                return;
            }

            #this needs to happen before anything else...but needs the token above..
            $ComputerName | Set-SPN -AccountName $config.sqlserviceaccount -Credential $Credential

            #Set -sql server port
            $ComputerName | Set-SqlServerPort 

            #add the mssqlagent account (admin verbotten)
            $Right = $Config.windowslogins | Where-Object{$_.name -eq 'sa_sqlagentacct'} | Select-Object -ExpandProperty right
            $ComputerName | Add-WindowsLogin -Name $config.sqlagentaccount -Right $Right 
            
            $ComputerName | Add-WindowsLogin -Name $config.sqlserviceaccount -LocalGroup 'Administrators' -Right 'SeLockMemoryPrivilege'

            $ComputerName | Set-SqlServiceAccount -ServiceName MSSQLSERVER -ServiceAccount (Get-Password -Name $config.sqlserviceaccount)
            #TODO:  Fix this when the spn issue is worked out...
            #$ComputerName | Set-SPN -AccountName $config.sqlserviceaccount -Credential $Credential

            #add the sqlserveragent account to sysadmin in sql server
            $ComputerName | Add-Login -Name $Config.sqlagentaccount -ServerRole 'sysadmin'
            $ComputerName | Add-Login -Name $Config.sqlserviceaccount 

            $ComputerName | Set-SqlServiceAccount -ServiceName SQLSERVERAGENT -ServiceAccount (Get-Password -Name $config.sqlagentaccount)

            #add windows logins to OS
            foreach($WinLogin in $Config.WindowsLogins){
                $ComputerName | Add-WindowsLogin -Name $WinLogin.Name -LocalGroup $WinLogin.localgroup
            }

            #add the sql server service and agent account as admins on the box (defaults to admins)
            #this should be taken care of by the code ^^
            #$ComputerName | Add-WindowsLogin -Name $config.sqlserviceaccount
            #$ComputerName | Add-WindowsLogin -Name $config.sqlagentaccount
            #$ComputerName | Add-WindowsLogin -Name $config.sqlauditaccount
            #$ComputerName | Add-WindowsLogin -Name $config.sqlbackupaccount


            #set the localsystem account temporarily so that when we do tempdb it has the perform volume maintenance right,
            #otherwise, it will take ages...
            #credential objects do not like blank passwords...so the set-SqlServiceAccount looks for 'localsystem'
            #and blanks the password automatically
            <#
                Weird behavior...when the login was NT Service\SQLSERVERAGENT or SQLSERVER...if the service is restarted under these 
                credentials, an error is thrown because said services to not have the 'login as a service' right.
                Hence, we're setting it to local system to avoid this error...
            #>
            #$Credential = New-Object System.Management.Automation.PSCredential ("localsystem", $(ConvertTo-SecureString "localsystem" -AsPlainText -Force))

            #add the endpoint to the computer....these permissions are required for alwayson creation...
            if (Get-Service -Name ClusSvc -ErrorAction SilentlyContinue) {
                $ComputerName | Add-Endpoint -Name $Config.sqlserviceaccount
            }
            #enable only windows auth...
            #$ComputerName | Set-SQLAuthenticationMode -Mode Integrated
            $ComputerName | Set-SqlAuthenticationMode -Mode $config.LoginMode

            #set the # of sql audit files to 12 
            $ComputerName | Set-SqlErrorNumlogs 

            #apply trace flags
            $TFList = $Config.traceflags
            if (Get-Service -Name ClusSvc -ErrorAction SilentlyContinue) { $TFList += '3459' }
            $ComputerName | Add-Traceflag -TraceFlag $TFList

            #apply sp_config 
            foreach($cnfg in $Config.sp_config){
                $ComputerName | Set-SPConfiguration -Name $cnfg.Name -Value $cnfg.Value 
            }

            #apply logins
            foreach($login in $Config.logins){            
                #$ComputerName | Add-Login @login

                if($login.PSObject.Properties.Name -match 'sid'){
                    $ComputerName | Add-Login -Name $login.Name -ServerRole $login.serverrole -SID $login.sid 
                }
                else{
                    $ComputerName | Add-Login -Name $login.Name -ServerRole $login.serverrole 
                }
            }

            #add proxy accounts
            foreach($proxy in $Config.Proxies){
                $ComputerName | Add-ProxyAccount -Name $proxy.name -AccountName $proxy.credential -Subsystem $proxy.subsystem
            }

            #tempdb
            $ComputerName | Set-TempDB -Force

            #set memory on sql
            $ComputerName | Set-SqlMemory 

            #set paths (creates remote dirs and sets sql properties...)
            $ComputerName | Set-SqlPath 
            
            #this MUST come before the Invoke-SqlScripts as it expects the 'flat' login to exist and not 'sa'
            #rename sa
            $ComputerName | Rename-SqlLogin -Name 'sa' -NewName $Config.salogin

            #execute custom sql scripts
            $ComputerName | Invoke-SqlScripts #-Name $Config.dbscriptlocation 

            #disable sa login
            $ComputerName | Disable-Login -Name $Config.salogin

            #set sql audit level
            $ComputerName | Set-SqlAuditLevel -Name $Config.sqlauditlevel

            #revoke connect to guest account from any non-system database...
            $ComputerName | Revoke-ConnectAccess -Name 'guest'

            #remove orphaned users from non-system databases
            $ComputerName | Remove-OrphanedDBUsers

            #disable trustworthy on all databases except for model & tempdb
            $ComputerName | Disable-DBTrustWorthy

            #EnableSQLLoginAudit
            $ComputerName | Set-ServerAudit -Enabled $([System.Convert]::ToBoolean($StdConfig.enableServerAudit))

            #Enable Delegation on servers belonging to MicroService = cthost | expense | spend-impl | outtask
            $ComputerName | Enable-Delegation -SQLServiceAccount $Config.sqlserviceaccount -TCPPort $standardPort
            
            #Deploy one-off configurations
            $ComputerName | Invoke-OneOffConfigurations

            #fips
            <#  Commented the FIPS enabling as we use FIPS AMIs
            if($StdConfig.enableFIPs){
                $ComputerName | Set-FIPs
            }
            #>

            #add audit
            #$ComputerName | Add-AuditLogins 

            # NOTE: !!  The alwayson configuration will not work if these are disabled...
            #disabling of all non-used protocols
            #$ComputerName | Disable-Protocol -Protocol NP 
            #this might play up with adding databases to alwayson...
            #$ComputerName | Disable-Protocol -Protocol SM

            #this is not a requirement for clusters...
            #create alias'  -->  These are needed due to the Hide-SqlInstance..hiding instances apparently borks clusters...
            #$ComputerName | Add-SqlServerAlias -Name $_         
            #keep this step until last...this does a restart and I don't trust this won't bork the cluster...
            $ComputerName | Hide-SqlInstance 


            #grant connect permission on the hadr_endpoint to the sql service account
            #$ComputerName | Set-EndpointConnectPermission -Name $config.sqlserviceaccount

            #set cluster configuration options
            #Invoke-ClusterListenerNameConfiguration -Name $ComputerName 
        }
        catch{
            $_ | Format-List -Force 
            Get-PSCallStack | Format-Table -AutoSize
        }
        
        
    }
    end{
        
    }
}
