function Get-Jurisdiction{
    #this is just wrong.  The jurisdiction should not be the domain, as seapr1 and parpr1 share a domain...unfortunately
    #the Get-Configuration calls this...so we can't really call get-configuration to determine the jurisdiction...so we 
    #have to figure out some way to determine this...this will break 
    return  $env:USERDOMAIN.ToLower();  
}