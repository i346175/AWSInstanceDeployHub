function Format-ServerName{
    <#
    .SYNOPSIS
    This cmdlet formats a server name to either remove the 'tcp:' prefix and port, or add them given the -AddPort or -AddTCPPrefix.  When both of these are omitted, the 
    ComputerName will return only the name of the computer without the 'tcp:' prefix or the port appended.
    
    .DESCRIPTION
    This cmdlet formats a server name to either remove the 'tcp:' prefix and port, or add them given the -AddPort or -AddTCPPrefix
    
    .PARAMETER ComputerName
    The name of the computer(s) to format
    
    .PARAMETER AddPort
    When supplied, the $ComputerName(s) will have the $SqlPort appended to the ComputerName
    
    .PARAMETER AddTCPPrefix
    When supplied, the $ComputerName(s) will have 'tcp: prepended to the ComputerName
    
    .PARAMETER FQDN
    This will fully-qualify the computer name.

    .EXAMPLE
    'SEAPR1DB3016' | Format-ServerName -AddPort -AddTCPPrefix
    
    .EXAMPLE
    Get-Servers | Format-ServerName 

    .NOTES
    General notes
    #>
    
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [Alias('ServerName', 'CN', 'PhysicalName')]
        [string[]]$ComputerName,
        [switch]$AddPort,
        [switch]$AddTCPPrefix,
        [switch]$FQDN
    )
    begin{
        $objects = New-Object System.Collections.Generic.List[string]
        $config = Get-Configuration 
    }
    process{

        foreach($Computer in $ComputerName){
            $Computer = $Computer.Split(',')[0].ToUpper().Replace('TCP:','')

            if($FQDN){
                $Computer = "$Computer.$(Get-Domain)"
            }

            if($AddPort){
                $Computer = "$Computer,$($config.port)"
            }
    
            if($AddTCPPrefix){
                $Computer = "tcp:$Computer"
            }
    
            [void]$objects.Add($Computer);
        }
    }
    end{
        return $objects;
    }
}