function Test-SqlServerAlias{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$Name
    )
    begin{
        $config = Get-Configuration 
        $objects = New-Object System.Collections.Generic.List[PSCustomObject]
    }
    process{
        $Port = $config.port
        $x86Alias = "HKLM:\Software\Microsoft\MSSQLServer\Client\ConnectTo"
        $x64Alias = "HKLM:\Software\Wow6432Node\Microsoft\MSSQLServer\Client\ConnectTo"
        $keyVal = "DBMSSOCN,$($Name.ToUpper()),$Port"

        foreach($Computer in $ComputerName){

            $x86Alias, $x64Alias | ForEach-Object{
                $path = $_
                $exists = invoke-command -ComputerName $Computer -ScriptBlock{
                    if(![bool](Get-ItemProperty -Path $using:path -Name $using:Name -ErrorAction SilentlyContinue)){
                        return $false
                    }
                    $val = (Get-ItemPropertyValue -Path $using:path -Name $using:Name).ToUpper()
                    if($val -ne $using:keyVal){
                        return $false
                    }
                    return $true;
                }

                [void]$objects.Add([PSCustomObject]@{
                    ComputerName = $Computer
                    Path = $path
                    Exists = $exists
                });

            }
        }
    }
    end{
        return ![bool]($objects | Where-Object{$_.Exists -eq $false})
    }
}