function Get-DriveSpace{
<#
.SYNOPSIS
Returns the drive information for a computer

.DESCRIPTION
Returns the drive information for a computer

.PARAMETER ComputerName
The names of the computers you want to see the drive information for

.OUTPUTS
An generic list of PSCustomObjects:
    DeviceID = D:
    Size = 123456 (in bytes)
    FreeSpace = 987654 (in bytes)
    VolumeName = name of the folume
    SizeGB = Size of drive in GB
    FreeSpaceGB = GB of free space on drive
    FreeSpacePercent = Free space percent of drive
    SpaceUsedGB = Space used on drive in GB

.EXAMPLE
Get-DriveSpace -ComputerName SEAPR1DB1001

.NOTES
General notes
#>
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)] 
        [Alias('CN', 'ServerName', 'PhysicalName')]
        [string[]]$ComputerName
    )
    begin{
        $objects = New-Object System.Collections.Generic.List[PSCustomObject]
    }
    process{

        foreach($Computer in $ComputerName | Format-ServerName){
            Get-WMIObject Win32_LogicalDisk -filter "DriveType=3" -ComputerName $Computer -ErrorAction Stop | ForEach-Object{
                [void]$objects.Add([PSCustomObject]@{
                    ComputerName = $Computer
                    DeviceID = $_.DeviceID 
                    Drive = $_.DeviceID 
                    Size = $_.Size 
                    FreeSpace = $_.FreeSpace 
                    VolumeName = $_.VolumeName
                    SizeGB = [Math]::Round(($_.Size/1GB),2)
                    FreeSpaceGB = [Math]::Round(($_.FreeSpace/1GB),2)
                    FreeSpacePercent = [Math]::Round((($_.FreeSpace/1GB) / ($_.Size/1GB) * 100),0)
                    SpaceUsedGB = [Math]::Round(($_.Size - $_.FreeSpace)/1GB,2)
                });
            }
        }

    }
    end{
        return $objects;        
    }

}

