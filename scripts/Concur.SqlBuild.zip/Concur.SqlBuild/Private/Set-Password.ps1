function Set-Password{
    [cmdletbinding()]
    param(
        # [string]$RoleType = 'dbsql',
        [Parameter(Mandatory)]
        [PSCredential]$Account
        #[Parameter(Mandatory)]
        #[pscredential]$Credential

    )
    begin{
        $config = Get-Configuration 
    }
    process{

        $Name = $Account.GetNetworkCredential().UserName

        switch($config.credstore){
            ([CredStore]::Device42){

            }
            ([CredStore]::Vault){
                if([System.String]::IsNullOrWhiteSpace($script:token)){
                    $script:token = Get-VaultToken #-Credential $Credential 
                    if([System.String]::IsNullOrEmpty($script:token)){
                        $env:COMPUTERNAME | Add-EventLogEntry -EntryType Warning -Message "Could not retrieve the vault token for account $Name on computer $env:COMPUTERNAME."
                        return $null;
                    }
                }
                
                $headers = @{}
                $headers.Add("X-Vault-Token", $script:token)
                $headers.Add("ContentType", "application/json")

                #[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}
                [System.Net.ServicePointManager]::CheckCertificateRevocationList = $false
                [System.Net.ServicePointManager]::Expect100Continue = $false
                [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

                <#
                curl -k --tlsv1.2 -L -H "X-Vault-Token: s.rDsYjaqJDkC1LpoB85v3qshf" -H 
                "Content-Type: application/json" -X POST -d '{"a":1, "b":2}' https://10.13.0.102/v1/secret/public/pcl57t/test8
                #>

                #$location = "v1/secret/public/$RoleType/$Name"
                $location = "v1/$($config.vaultnamespace)/secret/$Name"

                $uri = [uri]::EscapeUriString("$($config.vaultaddress)/$location");

                $payload = @{
                    password = $Account.GetNetworkCredential().Password
                    createdby = $env:USERNAME
                    createdate = (get-date).ToString('yyyyMMdd HH:mm:ss')
                    computername = $env:COMPUTERNAME
                }
                $json = $payload | ConvertTo-Json 

                $result = Invoke-RestMethod -Uri $uri -Method Post -ContentType 'application/json' -Body $json -Headers $headers #-Proxy $config.proxy
                $result
            }
        }

    }
    end{

    }
}