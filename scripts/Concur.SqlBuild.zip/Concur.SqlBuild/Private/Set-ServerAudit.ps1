function Set-ServerAudit{
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [Alias('PhysicalName')]
        [string[]]$ComputerName,
        [bool]$Enabled = $true
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
    }
    process{
        If($Enabled){
            foreach($Computer in $ComputerName){
                try{
                    $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                    $srv.ConnectionContext.TrustServerCertificate = $true;
                    
                    $AuditLogPath = 'M:\MSSQL\Audit'
                    If(!(Test-Path -Path $AuditLogPath)){
                        New-Item -ItemType Directory -Path $AuditLogPath -Force | Out-Null
                    }
                    $sqlquery = "
                        IF EXISTS(SELECT TOP 1 1 FROM sys.server_audits WHERE name = 'TrackLogins')
                        BEGIN
                            ALTER SERVER AUDIT [TrackLogins] WITH (
                                STATE = OFF
                            );
                            DROP SERVER AUDIT TrackLogins;
                        END

                        IF EXISTS(SELECT TOP 1 1 FROM sys.server_audit_specifications WHERE name = 'TrackAllLogins')
                        BEGIN
                            ALTER SERVER AUDIT SPECIFICATION [TrackAllLogins] WITH(
                                STATE = OFF
                            );
                            DROP SERVER AUDIT SPECIFICATION TrackAllLogins;
                        END
                        
                        CREATE SERVER AUDIT [TrackLogins]
                        TO FILE 
                        (	FILEPATH = N'$($AuditLogPath)'
                            ,MAXSIZE = 1 GB
                            ,MAX_FILES = 10
                        );
                        
                        CREATE SERVER AUDIT SPECIFICATION TrackAllLogins
                        FOR SERVER AUDIT TrackLogins
                        ADD (FAILED_LOGIN_GROUP),
                        ADD (SUCCESSFUL_LOGIN_GROUP),
                        ADD (AUDIT_CHANGE_GROUP)
                        WITH (STATE = ON);
                        
                        ALTER SERVER AUDIT TrackLogins
                        WITH (STATE = ON);    
                    " 
                    [void]$srv.ConnectionContext.ExecuteNonQuery("$sqlquery");
                }
                catch{
                    throw $_ 
                }
                finally{
                    if($srv){
                        $srv.ConnectionContext.Disconnect()
                    }
                }
            }
        }
    }
    end{

    }
}