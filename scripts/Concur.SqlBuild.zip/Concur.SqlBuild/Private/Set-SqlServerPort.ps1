function Set-SqlServerPort{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName
    )
    begin{
        $config = Get-Configuration 
    }
    process{

        foreach($Computer in $ComputerName){

            #Write-Verbose "Changing port on server $Computer to port $Port and restarting sql server service..."
            Invoke-Command -ComputerName $Computer -ScriptBlock{
                param(
                    [int]$Port
                )
                [system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
                [system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SqlWmiManagement") | Out-Null

                # this sets all the ports the the $Port instead of just IPALL because otherwise it will generate 
                # vulnerability if they see port 1433 (even though the port is not even enabled (－‸ლ) )
                $wmi = New-Object Microsoft.SqlServer.Management.smo.WMI.ManagedComputer $env:COMPUTERNAME
                $wmi.ServerInstances['mssqlserver'].ServerProtocols['tcp'].IPAddresses | ForEach-Object{
                    if($_.IPAddressProperties['TcpPort'].Writable){
                        $_.IPAddressProperties['TcpPort'].Value = [string]$Port;
                    }
                }
                $wmi.ServerInstances['mssqlserver'].ServerProtocols['tcp'].Alter();

                
                # $mc = new-object Microsoft.SqlServer.Management.Smo.Wmi.ManagedComputer $using:Computer
                # $Instance = $mc.ServerInstances['MSSQLSERVER']

                # $protocol = $Instance.ServerProtocols['Tcp']
                # $ip = $protocol.IPAddresses['IPAll']
                # $ip.IPAddressProperties['TcpDynamicPorts'].Value = ''
                # $ipProps = $ip.IPAddressProperties['TcpPort']
                # #if it's already set, just boot...
                # if($ipProps.Value -eq [string]$Port){
                #     return;
                # }
                # $ipProps.Value = [string]$Port
                # $protocol.Alter()

                Get-Service -Name MSSQLSERVER | Restart-Service -Force | Out-Null 
                Get-Service -Name SQLSERVERAGENT | Start-Service

            } -ArgumentList ($config.port)

        }
    
    }
}