function Test-ProtocolDisabled{
    <#
    .SYNOPSIS
    Tests if a SQL Server protocol is disabled
    
    .DESCRIPTION
    Returns false if one of the stated SQL Server Protocols is not enabled, otherwise true if enabled
    
    .PARAMETER ComputerName
    The name(s) of Computer(s) to run against
    
    .PARAMETER Name
    The name of the protocol to test - 'NM' (Named Pipes), 'SM' (Shared Memory), 'TCP'
    
    .EXAMPLE
    PS> Test-ProtocolDisabled -ComputerName SEAPR1DBBAT083 -Protocol NP
    
    .EXAMPLE
    PS> Test-ProtocolDisabled -ComputerName SEAPR1DBBAT083 -Protocol SM 

    .EXAMPLE
    PS> Test-ProtocolDisabled -ComputerName SEAPR1DBBAT083 -Protocol TCP

    .EXAMPLE
    PS> Test-ProtocolDisabled -ComputerName SEAPR1DBBAT083,SEAPR1DBBAT082 -Protocol NP

    #>
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [ValidateSet('SM','TCP','NP')]
        [string]$Protocol
    )
    begin{
        $objects = New-Object System.Collections.Generic.List[PSCustomObject]
    }
    process{
        foreach($Computer in $ComputerName){
           
            [system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
            [system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SqlWmiManagement") | Out-Null

            $wmi = New-Object Microsoft.SqlServer.Management.smo.WMI.ManagedComputer $Computer
            $uri = "ManagedComputer[@Name='$Computer']/ServerInstance[@Name='MSSQLSERVER']/ServerProtocol[@Name='$Protocol']" 
            $prot = $wmi.GetSmoObject($uri)
               
            if($prot.IsEnabled -eq $true){
                $Computer | Add-EventLogEntry -EntryType Warning -Message "The sql server protocol $Protocol is not disabled on computer $Computer"
                     
                [void]$objects.Add([PSCustomObject]@{
                    ComputerName = $Computer
                    IsDisabled = $false
                })
            }
   
        }
    }
    end{
        return ![bool]($objects | Where-Object{$_.IsDisabled -eq $false})
    }
}