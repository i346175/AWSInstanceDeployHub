function Test-Listener{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
        $objects = New-Object System.Collections.Generic.List[PSCustomObject]
    }
    process{
        foreach($Computer in $ComputerName){

            # verify the server is up
            if(!(Test-Connection -ComputerName ($Computer | Format-ServerName) -Count 1 -Quiet)){
                [void]$objects.Add([PSCustomObject]@{
                    ComputerName = $Computer
                    Exists = $false
                });
                Add-EventLogEntry -Computer $Computer -EntryType Warning -Message "Could not connect to computer $($Computer | Format-ServerName)"
                return
            }

            # verify the server's sql server is up
            if(!(Test-SqlConnection -ServerName ($Computer | Format-ServerName))){
                [void]$objects.Add([PSCustomObject]@{
                    ComputerName = $Computer
                    Exists = $false
                });
                Add-EventLogEntry -Computer $Computer -EntryType Warning -Message "Could not connect to SQL Server on computer $($Computer | Format-ServerName)"
                return;
            }

            # get the AG
            $ag = Get-AvailabilityGroup -ComputerName $Computer

            if (! $ag) {
                [void]$objects.Add([PSCustomObject]@{
                    ComputerName = $Computer
                    Exists = $false
                });
                Add-EventLogEntry -Computer $Computer -EntryType Warning -Message "Could not find Availability Group for computer $($Computer | Format-ServerName)"
                return;
            }

            # get the listener from the AG
            $Listener = $ag.Listeners

            if (! $Listener) {
                [void]$objects.Add([PSCustomObject]@{
                    ComputerName = $Computer
                    Exists = $false
                });
                Add-EventLogEntry -Computer $Computer -EntryType Warning -Message "Could not find listener for computer $($Computer | Format-ServerName)"
                return;
            }
        }
    }    
    end{
        return ![bool]($objects | Where-Object{$_.Exists -eq $false})
    }
}
