function Test-ProxyEnabled{
    param(
        [string]$ComputerName = $env:ComputerName
    )
    begin{

    }
    process{
        $enabled = Get-ItemProperty -Path "Registry::HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -Name ProxyEnable
        return [bool]$enabled.ProxyEnable;
    }
    end{

    }
}