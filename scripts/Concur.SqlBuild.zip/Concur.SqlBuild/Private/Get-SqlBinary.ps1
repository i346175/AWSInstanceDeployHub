function Get-SqlBinary{
    [cmdletbinding(DefaultParameterSetName='default')]
    param(
        [Parameter(Mandatory, ParameterSetName='default')]
        [string]$Version = 'Latest',
        [Parameter(ParameterSetName='default')]
        [ValidateSet('Enterprise', 'Standard', 'Development')]
        [string]$Edition = 'Enterprise',
        [Parameter(ParameterSetName='default')]
        [string]$Year = 2016,
        [Parameter(ParameterSetName='default')]
        [string]$ServicePack,
        [Parameter(ParameterSetName='default')]
        [Parameter(ParameterSetName='url')]
        [string]$Destination,
        [Parameter(ParameterSetName='url')]
        $URL,
        [Parameter(Mandatory, ParameterSetName='default')]
        [Parameter(Mandatory, ParameterSetName='url')]
        [PSCredential]$Credential 
    )
    begin{
        $Config = Get-Configuration 
    }
    process{

        switch($PSCmdlet.ParameterSetName){
            'url'{
                Get-Artifact -location $URL -Destination $Destination -Credential $Credential 
            }
            'default'{

            }
        }
        #https://artifactory.concurtech.net/artifactory/util-sandbox-local/SqlServer2016Enterprise.zip

    }
    end{

    }
}