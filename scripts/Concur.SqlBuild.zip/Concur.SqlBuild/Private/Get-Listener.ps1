function Get-Listener{
    <#
    .SYNOPSIS
    Returns a server's Availability Group listener.
    
    .DESCRIPTION
    Returns a server's Availability Group listener.

    .PARAMETER ComputerName
    The name of the computer(s) whose listener is to be returned
    
    .EXAMPLE
    Get-Listener -ComputerName SEAPR1DB0000
    
    .NOTES
    Notes.
    #>
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")

        $Listener = ""
    }
    process{

        foreach($Computer in $ComputerName){

            # verify the server is up
            if(!(Test-Connection -ComputerName ($Computer | Format-ServerName) -Count 1 -Quiet)){
                Add-EventLogEntry -Computer $Computer -EntryType Warning -Message "Could not connect to computer $($Computer | Format-ServerName)"
                return;
            }

            # verify the server's sql server is up
            if(!(Test-SqlConnection -ServerName ($Computer | Format-ServerName))){
                Add-EventLogEntry -Computer $Computer -EntryType Warning -Message "Could not connect to SQL Server on computer $($Computer | Format-ServerName)"
                return;
            }

            # get the AG
            $ag = Get-AvailabilityGroup -ComputerName $Computer

            if (! $ag) {
                Add-EventLogEntry -Computer $Computer -EntryType Warning -Message "Could not find Availability Group for computer $($Computer | Format-ServerName)"
                return;
            }

            # get the listener from the AG
            $Listener = $ag.Listeners

            if (! $Listener) {
                Add-EventLogEntry -Computer $Computer -EntryType Warning -Message "Could not find listener for computer $($Computer | Format-ServerName)"
                return;
            }

            # test that the listener is up
            if (! (Test-Connection -ComputerName ($Listener | Format-ServerName) -Count 1 -Quiet)){
                Add-EventLogEntry -Computer $Computer -EntryType Warning -Message "Could not connect to listener $($Listener | Format-ServerName)"
                return;
            }
        }
    }
    end{
        return $Listener
    }
}
