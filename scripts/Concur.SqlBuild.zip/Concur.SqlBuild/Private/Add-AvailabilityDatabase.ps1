function Add-AvailabilityDatabase{
    <#
    .SYNOPSIS
    Adds a database to an availabilitygroup
    
    .DESCRIPTION
    Adds a database to an availabilitygroup
    
    .PARAMETER ComputerName
    The name of the computer on which to add the availability database
    
    .PARAMETER Name
    The name of the database
    
    .PARAMETER GroupName
    The name of the availability group.  If more than one availabilitygroup exists, this is required.  If there is only one availabilitygroup, this is no required, and 
    the name will be set to the availabilitygroup on the server.
    
    .EXAMPLE
    $ComputerName | Add-AlwaysOnDatabase -Name eOperationsDBA
    
    .NOTES
    This expects that the databases being added to the availabilitygroup have already been restored and are all in a RESTORING state.
    #>
    
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$Name,
        [string]$GroupName
    )
    begin{

    }
    process{
        foreach($Computer in $ComputerName){
            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                if($srv.AvailabilityGroups.Count -gt 1 -and !$srv.AvailabilityGroups[$GroupName]){
                    $Computer | Add-EventLogEntry -EntryType Error -Message "If there is more than one AvailabilityGroup on a server the GroupName parameter must be specified."
                    return;
                }
                if($srv.AvailabilityGroups.Count -eq 1){
                    $GroupName = $srv.AvailabilityGroups[0].Name 
                }
                
                #test to ensure that the db exists on the replicas...
                $replicaNames = New-Object System.Collections.Generic.List[string]
                foreach($Replica in $srv.AvailabilityGroups[$GroupName].AvailabilityReplicas){
                    #test that the database exists on the replica servers and is in a restoring state...
                    [void]$replicaNames.Add($Replica.Name);
                    try{
                        $replSrv = New-Object Microsoft.SqlServer.Management.smo.Server ($Replica.Name | Format-ServerName -AddPort)
                        if(!($replSrv.Databases[$Name] | Where-Object{$_.Status -eq [Microsoft.SqlServer.Management.Smo.DatabaseStatus]::Restoring})){
                            $Computer | Add-EventLogEntry -EntryType Warning -Message "Database $Name either does not exist or is not in a restoring state on computer $Computer."
                            return;
                        }
                    }
                    catch{
                        throw $_ 
                    }
                    finally{
                        if($replSrv){
                            $replSrv.ConnectionContext.Disconnect();
                        }
                    }
                }

                #add primary
                $primaryReplica = $srv.AvailabilityGroups[$GroupName].PrimaryReplicaServerName
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($primaryReplica | Format-ServerName -AddPort)
                if($srv.availabilityGroups[$GroupName].AvailabilityDatabases[$Name]){
                    $Computer | Add-EventLogEntry -EntryType Warning -Message "Database $Name already exists on availability group $GroupName on computer $Computer."
                    return;
                }
                $ADDB = New-Object Microsoft.SqlServer.Management.smo.AvailabilityGroupDatabase($srv.AvailabilityGroups[$GroupName], $Name)
                $ADDB.Create();
                $srv.ConnectionContext.Disconnect();

                foreach($replicaName in $replicaNames | Where-Object{$_ -ne $primaryReplica}){
                    $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($replicaName | Format-ServerName -AddPort)
                    $Group = $srv.AvailabilityGroups[$GroupName]
                    if(!($Group.AvailabilityDatabases[$Name].IsJoined)){
                        $Group.AvailabilityDatabases[$Name].JoinAvailabilityGroup();
                    }
                    $srv.ConnectionContext.Disconnect();
                }

                

            }
            catch{
                throw $_ 
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }
    }
    end{

    }
}