function Hide-SqlInstance{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,

        [ValidateNotNullOrEmpty()]
        [string]$Name = 'MSSQLSERVER',

        [switch]$Force
    )
    begin{

    }
    process{

        # skip this...the sb does this test and will skip if already set...
        # if(($ComputerName | Test-SqlInstanceHidden)){
        #     return;
        # }

        [ScriptBlock]$hide = {
            param(
                $Name,
                $Force
            )
            
            if(Get-Service -Name 'ClusSvc' -ErrorAction SilentlyContinue){
                Write-Warning "Cannot hide the $Name sql instance on computer $env:computername due to the ClusSvc service existing."
                return;
            }

            $hklmRootNode = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server"
            $props = Get-ItemProperty "$hklmRootNode\Instance Names\SQL"
            $instances = $props.psobject.properties | Where-Object{$_.Value -like "*$Name"} | Select-Object Value
            foreach($inst in $instances){
                $key = "$hklmRootNode\$($inst.Value)\MSSQLServer\SuperSocketNetLib"
                Set-ItemProperty -Name HideInstance -Path $key -Value 1
            }
            if($Force){
                Restart-Service -Name MSSQLSERVER -Force | Out-Null
                Get-Service -Name SQLSERVERAGENT | Start-Service
            }
        }

        foreach($Computer in $ComputerName){
            $params = @{
                ComputerName = $Computer
                ScriptBlock = $hide
                ArgumentList = $Name,$Force
            }
            if($Computer -eq $env:COMPUTERNAME){
                $params.Remove('ComputerName');
            }
            Invoke-Command @params
        }

    }
    end{

    }
}