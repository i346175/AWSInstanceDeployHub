function Create-SQLListenerCNO {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory=$true)]
        [string]$ClusterName,
        [Parameter(Mandatory=$true)]
        [string]$ListenerName,
        [Parameter(Mandatory=$true)]
        [PSCredential]$Credential
    )

    begin {
        Add-Type -AssemblyName System.DirectoryServices -PassThru | Out-Null
    }

    process {
        <#
            DistinguishedName : CN=lst-xv98-k5oh,OU=DB Cluster Names,OU=Servers,OU=integration,DC=integration,DC=system,DC=cnqr,DC=tech
            DNSHostName       : lst-xv98-k5oh.integration.system.cnqr.tech    
        #>

        $maxRetries = 5  # Set the maximum number of retries
        $retryCount = 0  # Initialize retry counter
        $sleepDuration = 5  # Initial wait time (seconds)

        do {
            try {
                $DistinguishedName = (Get-ADComputer "$ClusterName").DistinguishedName.split(',')
                $OU1 = $DistinguishedName[1].Replace('OU=', '')
                $OU2 = $DistinguishedName[2].Replace('OU=', '')
                $OU3 = $DistinguishedName[3].Replace('OU=', '')
                $DC1 = $DistinguishedName[4].Replace('DC=', '')
                $DC2 = $DistinguishedName[5].Replace('DC=', '')
                $DC3 = $DistinguishedName[6].Replace('DC=', '')
                $DC4 = $DistinguishedName[7].Replace('DC=', '')
                $ListenerNameFQDN = "$($ListenerName).$($DC1).$($DC2).$($DC3).$($DC4)"

                if (-not (Test-Path "AD:CN=$($ListenerName),OU=$($OU1),OU=$($OU2),OU=$($OU3),DC=$($DC1),DC=$($DC2),DC=$($DC3),DC=$($DC4)")) {
                    # Create VCO for AAG
                    New-ADComputer -Name "$ListenerName" -SamAccountName "$ListenerName" -Path "OU=$($OU1),OU=$($OU2),OU=$($OU3),DC=$($DC1),DC=$($DC2),DC=$($DC3),DC=$($DC4)" -Description "AlwaysOn Availability Group Listener Account" -Enabled $false -DNSHostName $ListenerNameFQDN -Credential $Credential
                    # Wait for AD synchronization
                    Start-Sleep -Seconds 10
                }

                $path = "AD:\$((Get-ADComputer -Identity $ListenerName).DistinguishedName)"
                $acl = Get-Acl -Path $path
                $ClusterSID = New-Object System.Security.Principal.SecurityIdentifier (Get-ADComputer -Identity $ClusterName).SID
                $ace = New-Object System.DirectoryServices.ActiveDirectoryAccessRule($ClusterSID, 'GenericAll', 'Allow')
                $acl.AddAccessRule($ace)
                Set-Acl -Path $path -AclObject $acl

                # Listener creation successful, break the loop
                break
            } catch {
                # Handle potential errors 
                Write-Error $_.Exception.Message
                $retryCount++

                if ($retryCount -lt $maxRetries) {
                    Start-Sleep -Seconds ($sleepDuration)  # Use plain delay
                    $sleepDuration = $sleepDuration * 2  # Double wait time for next retry
                } else {
                    throw "Listener creation failed after $maxRetries retries."
                }
            }
        } while ($retryCount -lt $maxRetries)
    }

    end {
    }
}