function Remove-OrphanedDBUsers{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName 
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
    }
    process{
        foreach($Computer in $ComputerName){
            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                foreach($Database in $srv.Databases | Where-Object{!$_.IsSystemObject -and $_.Status -eq [Microsoft.SqlServer.Management.smo.DatabaseStatus]::Normal -and !$_.IsDatabaseSnapshot -and !$_.ReadOnly}){
                    foreach($User in $Database.Users | Where-Object{[System.String]::IsNullOrEmpty($_.Login) -and $_.AuthenticationType -ne [Microsoft.SqlServer.Management.smo.AuthenticationType]::None}){
                        $UserName = $User.Name 
                        if($Database.Schemas[$UserName]){
                            $ownedObjects = $Database.Schemas[$UserName].EnumOwnedObjects()
                            if($ownedObjects.Count -gt 0){
                                #Write-Warning "Could not removed orphaned user $UserName from database $($Database.Name) because the user's default schema $schema owns objects within the database."
                                $Computer | Add-EventLogEntry -EntryType Warning -Message "Could not removed orphaned user $UserName because the user has a schema that owns objects within the database $($Database.Name)."
                                continue;
                            }
                            $Database.Schemas[$UserName].Drop();
                        }
                        $User.Drop();
                    }
                }
            }
            catch{
                throw $_ 
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }
    }
    end{

    }
}