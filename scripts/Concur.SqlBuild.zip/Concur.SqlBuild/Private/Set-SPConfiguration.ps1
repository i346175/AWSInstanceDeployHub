function Set-SPConfiguration{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$Name,
        [Parameter(Mandatory)]
        [string]$Value
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
        $Config = Get-SqlDefaultConfiguration
    }
    process{

        foreach($Computer in $ComputerName){
            try{
                $srv = new-object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                if(!($srv.ConnectionContext.ExecuteScalar("SELECT 1 FROM sys.configurations WHERE [name] = '$Name'"))){ 
                    $Computer | Add-EventLogEntry -EntryType Warning -Message "Configuration $Name is not a valid configuration in sp_configure."
                    return;
                }
                [void]$srv.ConnectionContext.ExecuteNonQuery("EXEC sp_configure '$Name', '$Value'; RECONFIGURE;");
            }
            catch{
                throw $_
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }

    }
    end{

    }
}