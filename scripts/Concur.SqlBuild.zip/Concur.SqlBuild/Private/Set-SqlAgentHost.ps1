function Set-SqlAgentHost{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName
    )
    begin{
        $config = Get-Configuration 
    }
    process{
        foreach($Computer in $ComputerName){
            Invoke-Command -ComputerName $Computer -ArgumentList $config.port -ScriptBlock{
                param(
                    $port
                )

                $hklmRootNode = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server"
                $props = Get-ItemProperty "$hklmRootNode\Instance Names\SQL"
                $instances = $props.psobject.properties | Where-Object{$_.Value -like 'MSSQL*'} | Select-Object Value
    
                $instances | ForEach-Object{
                    $inst = $_.Value;
                    $key = "$hklmRootNode\$inst\SqlServerAgent"
                    Set-ItemProperty -Name ServerHost -Path $key -Value "$env:COMPUTERNAME,$port"
                }
            }
        }
    }
    end{

    }
}