function Grant-TokenPrivilege {
    <#
     .SYNOPSIS
       Enables privileges in the current process token.
     .DESCRIPTION
       Enables one or more privileges for the current process token. If a privilege cannot be enabled, an exception is thrown.
     .PARAMETER Privilege
       Name of the privilege to enable. More than one privilege may be listed.
   
       Possible values: 
         SeTrustedCredManAccessPrivilege              Access Credential Manager as a trusted caller
         SeNetworkLogonRight                          Access this computer from the network
         SeTcbPrivilege                               Act as part of the operating system
         SeMachineAccountPrivilege                    Add workstations to domain
         SeIncreaseQuotaPrivilege                     Adjust memory quotas for a process
         SeInteractiveLogonRight                      Allow log on locally
         SeRemoteInteractiveLogonRight                Allow log on through Remote Desktop Services
         SeBackupPrivilege                            Back up files and directories
         SeChangeNotifyPrivilege                      Bypass traverse checking
         SeSystemtimePrivilege                        Change the system time
         SeTimeZonePrivilege                          Change the time zone
         SeCreatePagefilePrivilege                    Create a pagefile
         SeCreateTokenPrivilege                       Create a token object
         SeCreateGlobalPrivilege                      Create global objects
         SeCreatePermanentPrivilege                   Create permanent shared objects
         SeCreateSymbolicLinkPrivilege                Create symbolic links
         SeDebugPrivilege                             Debug programs
         SeDenyNetworkLogonRight                      Deny access this computer from the network
         SeDenyBatchLogonRight                        Deny log on as a batch job
         SeDenyServiceLogonRight                      Deny log on as a service
         SeDenyInteractiveLogonRight                  Deny log on locally
         SeDenyRemoteInteractiveLogonRight            Deny log on through Remote Desktop Services
         SeEnableDelegationPrivilege                  Enable computer and user accounts to be trusted for delegation
         SeRemoteShutdownPrivilege                    Force shutdown from a remote system
         SeAuditPrivilege                             Generate security audits
         SeImpersonatePrivilege                       Impersonate a client after authentication
         SeIncreaseWorkingSetPrivilege                Increase a process working set
         SeIncreaseBasePriorityPrivilege              Increase scheduling priority
         SeLoadDriverPrivilege                        Load and unload device drivers
         SeLockMemoryPrivilege                        Lock pages in memory
         SeBatchLogonRight                            Log on as a batch job
         SeServiceLogonRight                          Log on as a service
         SeSecurityPrivilege                          Manage auditing and security log
         SeRelabelPrivilege                           Modify an object label
         SeSystemEnvironmentPrivilege                 Modify firmware environment values
         SeDelegateSessionUserImpersonatePrivilege    Obtain an impersonation token for another user in the same session
         SeManageVolumePrivilege                      Perform volume maintenance tasks
         SeProfileSingleProcessPrivilege              Profile single process
         SeSystemProfilePrivilege                     Profile system performance
         SeUnsolicitedInputPrivilege                  "Read unsolicited input from a terminal device"
         SeUndockPrivilege                            Remove computer from docking station
         SeAssignPrimaryTokenPrivilege                Replace a process level token
         SeRestorePrivilege                           Restore files and directories
         SeShutdownPrivilege                          Shut down the system
         SeSyncAgentPrivilege                         Synchronize directory service data
         SeTakeOwnershipPrivilege                     Take ownership of files or other objects
     .EXAMPLE
       Grant-TokenPrivilege SeIncreaseWorkingSetPrivilege
   
       Enables the "Increase a process working set" privilege for the current process.
     .INPUTS
       PS_LSA.Rights Right
     .OUTPUTS
       None
     .LINK
       http://msdn.microsoft.com/en-us/library/aa375202.aspx
       http://msdn.microsoft.com/en-us/library/bb530716.aspx
    #>
       [CmdletBinding()]
       param (
           [Parameter(Position=0, Mandatory=$true, ValueFromPipelineByPropertyName=$true, ValueFromPipeline=$true)]
           [Alias('Right')] [PS_LSA.Rights[]] $Privilege
       )
       process {
           foreach ($Priv in $Privilege) {
               try { [PS_LSA.TokenManipulator]::AddPrivilege($Priv) }
               catch [System.ComponentModel.Win32Exception] {
                   throw New-Object System.ComponentModel.Win32Exception("$($_.Exception.Message) ($Priv)", $_.Exception)
               }
           }
       }
   } # Enables privileges in the current process token
   