 function Set-SPN{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$AccountName,
        [Parameter(Mandatory)]
        [PSCredential]$Credential,
        [switch]$Delete
    )
    begin{
        $config = Get-Configuration 
    }
    process{

        foreach($Computer in $ComputerName){
            
            $spn = Get-SPN -ComputerName $Computer -ServiceClass MSSQLSvc -Specification $config.port
            #[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}
            [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
     
            if($Delete){ $key = 'Remove' }
            else{ $key = 'Add' }
            $port = [int]$config.port
            $domain =  $(Get-Domain).split('.')[0]
            $user = $AccountName.ToLower()

            try{
                if(!(Get-WindowsFeature | Where-Object{$_.Installed -and $_.Name -eq 'RSAT-AD-PowerShell'})){
                    Install-WindowsFeature RSAT-AD-PowerShell | Out-Null
                    Import-Module ActiveDirectory | Out-Null
                }

                #iterate through fqdn and non-fqdn computer name...
                ($Computer | Format-ServerName -FQDN), ($Computer | Format-ServerName) | ForEach-Object{
                    $Name = $_ 
                    $spnName = "MSSQLSvc/$($Name):$($port)"

                    if(!($Delete)){
                        if(!($spn | Where-Object{$_.spn -eq $spnName -and $_.sAMAccountName -eq $AccountName})){
                            try{
                                Set-ADUser -Identity $user -Server $domain -ServicePrincipalNames @{$key="$spnName"} -Credential $Credential
                            }
                            catch{
                                $Computer | Add-EventLogEntry -EntryType Warning -Message "There was an error adding SPN $spnName on account $AccountName on computer $Computer.`r`nDetailed Exception:`r`n$($_ | Format-List -Force | Out-String)"
                                return;
                            }
                        }
                        else{
                            $Computer | Add-EventLogEntry -EntryType Warning -Message "An SPN for computer $Name already exists on account $AccountName for the MSSQLSvc class and port $port."
                        }
                    }
                    else{
                        if($spn | Where-Object{$_.spn -eq $spnName -and $_.sAMAccountName -eq $AccountName}){
                            try{
                                Set-ADUser -Identity $user -Server $domain -ServicePrincipalNames @{$key="$spnName"} -Credential $Credential
                            }
                            catch{
                                $Computer | Add-EventLogEntry -EntryType Warning -Message "There was an error adding SPN $spnName on account $AccountName on computer $Computer.`r`nDetailed Exception:`r`n$($_ | Format-List -Force | Out-String)"
                                return;
                            }
                        }
                        else{
                            $Computer | Add-EventLogEntry -EntryType Warning -Message "An SPN for computer $Name already DOES NOT exist on account $AccountName for the MSSQLSvc class and port $port."
                        }
                    }
                }
            }
            catch{
                $Computer | Add-EventLogEntry -EntryType Error -Message "There was an error adding the spn for account $AccountName to computer $Computer.`r`nDetailed Exception:`r`n$($_ | Format-List -Force | Out-String)" -throw
                return;
            }
        }
    }
    end{
    }
} 
