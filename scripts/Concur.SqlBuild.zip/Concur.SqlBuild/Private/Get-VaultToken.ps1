function Get-VaultToken{
    <#
    .SYNOPSIS
    Gets a temporary token from vault
    
    .DESCRIPTION
    Gets a temporary token from vault
    
    .PARAMETER location
    Parameter description
    
    .EXAMPLE
    An example
    
    .NOTES
    General notes
    #>
    
    [cmdletbinding()]
    param(
        #[Parameter(Mandatory)]
        #[PSCredential]$Credential,
        #[string]$location = 'v1/auth/ldap/login'
    )
    begin{
        $config = Get-Configuration 
    }
    process{

            try{
                $env:AWS_REGION = $config.awsregion
                $env:VAULT_NAMESPACE= $config.vaultnamespace
                $env:VAULT_ADDR = $config.vaultaddress

                $role = $env:VAULT_NAMESPACE.split('/')[1]

                Push-Location 
                set-location C:\Vault
                #the commented one below worked fine in pscc...
                #$results = $(. ./vault login -method=aws role=$role)
                #but it doesn't work in INTEGRATION...in integration you have to have the 'region=...' in the line...whatever...
                $results = $(. ./vault login -method=aws role=$role region=$($config.awsregion))
                $token = ($results | Select-String -Pattern '^token' -List)[0].ToString().Replace('token','').Trim() 
                return $token
            }
            catch{
                $env:COMPUTERNAME | Add-EventLogEntry -EntryType Warning -Message "There was an error in getting the vault token.`r`nDetailed Exception:`r`n$($_ | Format-List -Force | Out-String)"
            }
            finally{
                Pop-Location
            }

        # if(!(Test-ADCredentials -Credential $Credential)){
        #     throw "Invalid credentials supplied"
        # }
        # try{
        #     $uri = [uri]::EscapeUriString("$($config.credurl)/$location/$($Credential.GetNetworkCredential().UserName)");
        #     $payload = "{`"password`":`"$($Credential.GetNetworkCredential().Password)`"}"

        #     [System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}
        #     [System.Net.ServicePointManager]::CheckCertificateRevocationList = $false
        #     [System.Net.ServicePointManager]::Expect100Continue = $false
        #     [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
        #     $result = Invoke-RestMethod -Uri $uri -Method Post -ContentType 'application/json' -Body $payload #-Proxy $config.proxy
        #     return $result.auth.client_token
        # }
        # catch{
        #     $env:COMPUTERNAME | Add-EventLogEntry -EntryType Warning -Message "There was an error in getting the vault token.`r`nDetailed Exception:`r`n$($_ | Format-List -Force | Out-String)"
        #     return $null;
        # }
        # finally{
        #     [System.Net.ServicePointManager]::ServerCertificateValidationCallback = $null
        # }

    }
    end{

    }
}


<#

function Get-VaultToken{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory)]
        [PSCredential]$Credential,
        [string]$location = 'https://10.13.5.129:443/v1/auth/ldap/login'
    )
    
        $uri = [uri]::EscapeUriString("$location/$($Credential.GetNetworkCredential().UserName)");
        $payload = "{`"password`":`"$($Credential.GetNetworkCredential().Password)`"}"
        [System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}
        [System.Net.ServicePointManager]::CheckCertificateRevocationList = $false
        [System.Net.ServicePointManager]::Expect100Continue = $false
        [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
        #$result = Invoke-WebRequest -Method Post  -Uri $uri -Body $payload -ContentType "application/json"
        $result = Invoke-RestMethod -Uri $uri -Method Post -ContentType 'application/json' -Body $payload
        return $result.auth.client_token
}

cls
$cred = Get-Credential -Message "Test..." -UserName $env:USERNAME
cls
Get-VaultToken -Credential $cred 

#>