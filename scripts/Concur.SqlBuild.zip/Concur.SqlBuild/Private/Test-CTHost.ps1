function Test-CTHost {
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")

        $objects = New-Object System.Collections.Generic.List[PSCustomObject]
        $Config = Get-Configuration
        $Port = $Config.port 
    }
    process{

        foreach($Computer in $ComputerName){

            # verify the server is up
            if(!(Test-Connection -ComputerName ($Computer | Format-ServerName) -Count 1 -Quiet)){
                [void]$objects.Add([PSCustomObject]@{
                    ComputerName = $Computer
                    Exists = $false
                });
                Add-EventLogEntry -Computer $Computer -EntryType Warning -Message "Could not connect to computer $($Computer | Format-ServerName)"
                return
            }

            # verify the server's sql server is up
            if(!(Test-SqlConnection -ServerName ($Computer | Format-ServerName))){
                [void]$objects.Add([PSCustomObject]@{
                    ComputerName = $Computer
                    Exists = $false
                });
                Add-EventLogEntry -Computer $Computer -EntryType Warning -Message "Could not connect to SQL Server on computer $($Computer | Format-ServerName)"
                return;
            }

            try{

                # get the listener
                $Listener = Get-Listener ($Computer | Format-ServerName)

                if ([System.string]::IsNullOrEmpty($Listener)) {
                    [void]$objects.Add([PSCustomObject]@{
                        ComputerName = $Computer
                        Exists = $false
                    });
                    Add-EventLogEntry -Computer $Computer -EntryType Warning -Message "Could not find Listener for computer $($Computer | Format-ServerName)"
                    return;
                }

                # see if the listener is already in ct_host
                try{

                    # connect to the ct_host server
                    $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Config.cthostserver | Format-ServerName -AddPort)
                    $srv.ConnectionContext.DatabaseName = $Config.cthostdbname

                    $cmd = "SELECT COUNT(*) AS Rows
                              FROM dbo.cth_server_instance
                             WHERE UPPER(server_name) = '$($Listener.ToUpper())' 
                               AND port_num = $Port 
                               AND instance_name IS NULL"

                    $Rows = [int] $srv.ConnectionContext.ExecuteScalar($cmd)

                    if ($Rows -eq 0) {
                        [void]$objects.Add([PSCustomObject]@{
                            ComputerName = $Computer
                            Exists = $false
                        });
                        Add-EventLogEntry -Computer $Computer -EntryType Warning -Message "Listener $($Listener | Format-ServerName) was not found in the CTH_SERVER_INSTANCE table in CT_HOST"
                        return
                    }
                }
                catch{
                    if ($Rows -eq 0) {
                        [void]$objects.Add([PSCustomObject]@{
                            ComputerName = $Computer
                            Exists = $false
                        });
                        Add-EventLogEntry -Computer $Computer -EntryType Warning -Message "There was an error when checking for existence in CT_HOST for listener $($Listener | Format-ServerName)"
                        return
                    }    
                }
                finally {
                    if ($srv) {
                        $srv.ConnectionContext.Disconnect() 
                    }
                }
            }
            catch{
                if ($Rows -eq 0) {
                    [void]$objects.Add([PSCustomObject]@{
                        ComputerName = $Computer
                        Exists = $false
                    });
                    Add-EventLogEntry -Computer $Computer -EntryType Warning -Message "There was an error when checking for existence in CT_HOST for listener $($Listener | Format-ServerName)"
                    return
                }    
            }
        }
    }
    end{
        return ![bool]($objects | Where-Object{$_.Exists -eq $false})
    }
}
