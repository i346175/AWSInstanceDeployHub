function Test-Fips{
    param(
        [Parameter(Mandatory)]
        [string]$ComputerName
    )
    
    if(!(Test-Connection -ComputerName $ComputerName -Count 2 -Quiet)){
        throw "Could not connect to computer $ComputerName"
    }

    $value = Invoke-Command -ComputerName $ComputerName -ScriptBlock{
        return Get-ItemPropertyValue -Path 'HKLM:\System\CurrentControlSet\Control\Lsa\FipsAlgorithmPolicy' -Name Enabled 
    }

    return [bool]$value

}