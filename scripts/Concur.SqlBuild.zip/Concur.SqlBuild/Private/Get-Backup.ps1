function Get-Backup{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$URI,
        [Parameter(Mandatory)]
        [string]$Destination
    )
    begin{
        $config = Get-Configuration 
    }
    process{
        $proxy = $config.proxy
        $URI = [uri]::EscapeUriString("$($config.artifactory)/$URI");

        foreach($Computer in $ComputerName){
            try{
                Invoke-Command -ComputerName $Computer -ScriptBlock{
                    #if dest dir doesn't exist, force create it...
                    New-Item -ItemType Directory -Path ([System.IO.Path]::GetDirectoryName($using:Destination)) -Force | Out-Null

                    [System.Net.ServicePointManager]::CheckCertificateRevocationList = $false
                    [System.Net.ServicePointManager]::Expect100Continue = $false
                    [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
                    
                    Invoke-RestMethod -Uri $using:URI -Method Get -OutFile $using:Destination -ContentType 'application/zip' #-Proxy $using:proxy
                }
            }
            catch{
                $Computer | Add-EventLogEntry -EntryType Error -Message "There was an error while trying to get the backup from $URI on computer $Computer.`r`nDetailed Exception:`r`n$($_ | Format-List -Force | Out-String)"
            }
        }
        

    }
    end{

    }
}