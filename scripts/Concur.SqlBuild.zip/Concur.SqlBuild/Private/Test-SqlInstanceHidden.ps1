function Test-SqlInstanceHidden{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [string]$Name = 'MSSQLSERVER'
    )
    begin{
        $objects = New-Object System.Collections.Generic.List[PSCustomObject]
    }
    process{
        foreach($Computer in $ComputerName){
            $hidden = Invoke-Command -ComputerName $Computer -ScriptBlock{
                $hklmRootNode = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server"
                $props = Get-ItemProperty "$hklmRootNode\Instance Names\SQL"
                $instances = $props.psobject.properties | ?{$_.Value -like "*$using:Name"} | Select-Object Value
                foreach($inst in $instances){
                    $key = "$hklmRootNode\$($inst.Value)\MSSQLServer\SuperSocketNetLib"
                    $instHidden = [bool](Get-ItemProperty -Path $key -Name HideInstance | Select-Object -ExpandProperty HideInstance)
                    if(!$instHidden){
                        Write-Warning "The 'IsHidden' property is not set to true on computer $env:COMPUTERNAME"
                    }
                    return $instHidden
                }
            }
            if(!$hidden){
                $Computer | Add-EventLogEntry -EntryType Warning -Message "The sql server instance is not hidden on computer $Computer"
            }
            [void]$objects.Add([PSCustomObject]@{
                ComputerName = $Computer
                IsHidden = $hidden
            });

        }
    }
    end{
        return ![bool]($objects | Where-Object{$_.IsHidden -eq $false})
    }
}