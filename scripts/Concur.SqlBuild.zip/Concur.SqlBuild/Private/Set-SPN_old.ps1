function Set-SPN_old{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$AccountName,
        [Parameter(Mandatory)]
        [PSCredential]$Credential,
        [switch]$Delete
    )
    begin{
        $config = Get-Configuration 
    }
    process{

        foreach($Computer in $ComputerName){
            
            <#
            ComputerName   : vpc19-cqm4-9s70
            Specification  : 2020
            ServiceClass   : MSSQLSvc
            sAMAccountName : VPC19-CQM4-9S70$
            SPN            : MSSQLSvc/vpc19-cqm4-9s70.devtest.system.cnqr.tech:2020
            #>
            $spn = Get-SPN -ComputerName $Computer -ServiceClass MSSQLSvc -Specification $config.port
            #the restapi errors due to the '$' in the account name, so skip this for now until it gets fixed...
            # if($spn | Where-Object{$_.sAMAccountName -eq "$Computer`$"}){
            #     Remove-SPN -ComputerName $Computer -AccountName "$Computer`$" -Credential $Credential
            # }
            if($spn | Where-Object{$_.sAMAccountName -eq $AccountName -and !$Delete}){
                $Computer | Add-EventLogEntry -EntryType Warning -Message "An SPN for computer $Computer already exists on account $AccountName for the MSSQLSvc class and port $($config.port)."
                return;
            }
    
            $username = ($Credential.GetNetworkCredential().UserName | Format-LoginName -Separator '@').ToLower()
     
            $bString = [System.Runtime.InteropServices.marshal]::SecureStringToBSTR($Credential.Password)
            $password = [System.Runtime.InteropServices.marshal]::PtrToStringAuto($bString)
            $base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f $username,$password)))
     
            #[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}
            [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
     
            $url = "$($config.spnapi)/spnAgent/spnAdd"
            if($Delete){
                 $url = "$($config.spnapi)/spnAgent/spnDel"
            }

            #of note, this thing is unforgiving...note the computerName.  if the 'N' is not capitolized...it will error.
            #the port must also be an int.  Your payload should look like this:
            <#
            {
                "domain":  "devtest.system.cnqr.tech",
                "computerName":  "vpc19-vvki-5vxn",
                "user":  "sa_sqlacct",
                "service":  "MSSQLSvc",
                "port":  2020
            }
            of note, the only way I could log into this was with a username in the format of:  snewman@devtest.system.cnqr.tech
            #>
            $payload = [ordered]@{
                domain = (Get-Domain).ToLower()
                computerName = $Computer.ToLower() 
                user = $AccountName.ToLower()
                service = 'MSSQLSvc'
                port = [int]$config.port
            }
            try{
                Invoke-RestMethod -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -ContentType "application/json" -Method Post -Uri $url -Body ($payload | ConvertTo-Json -Compress) #-Proxy $config.proxy
            }
            catch{
                $Computer | Add-EventLogEntry -EntryType Error -Message "There was an error adding the spn for account $AccountName to computer $Computer.`r`nDetailed Exception:`r`n$($_ | Format-List -Force | Out-String)" -throw
                return;
            }
            # if(!(Get-WindowsFeature | Where-Object{$_.Installed -and $_.Name -eq 'RSAT-AD-PowerShell'})){
            #     Install-WindowsFeature RSAT-AD-PowerShell | Out-Null
            # }

            #iterate through fqdn and non-fqdn computer name...
            # ($Computer | Format-ServerName -FQDN), ($Computer | Format-ServerName) | ForEach-Object{
            #     $Name = $_ 
            #     $spnName = "MSSQLSvc/$($Name):$($port)"

            #     if(!($spn | Where-Object{$_.spn -eq $spnName -and $_.sAMAccountName -eq $AccountName})){
            #         try{
            #             #$args = "-A $spnName $($AccountName | Format-LoginName -DomainType NoDomain)"
            #             #Start-Process -FilePath 'C:\Windows\System32\setspn.exe' -ArgumentList $args

            #             Set-ADUser -Identity ($AccountName | Format-LoginName -DomainType NoDomain) -ServicePrincipalNames @{Add="$spnName"}

            #             #setspn -A MSSQLSvc/$($Name):$($Port) $($AccountName | Format-LoginName -DomainType NoDomain)
            #             #Set-ADComputer -ServicePrincipalNames @{Add="MSSQLSvc/$($Name):$($port)"}
            #         }
            #         catch{
            #             $Computer | Add-EventLogEntry -EntryType Warning -Message "There was an error adding SPN $spnName on account $AccountName on computer $Computer.`r`nDetailed Exception:`r`n$($_ | Format-List -Force | Out-String)"
            #             return;
            #         }
            #     }
            #     else{
            #         $Computer | Add-EventLogEntry -EntryType Warning -Message "An SPN for computer $Name already exists on account $AccountName for the MSSQLSvc class and port $port."
            #     }
            # }

            #Set-ADComputer -ServicePrincipalNames @{Add='WSMAN/Mycomputer','WSMAN/Mycomputer.MyDomain.Com'}

        }
    }
    end{

    }
}