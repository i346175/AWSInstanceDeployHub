function Test-SPConfiguration{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$Name,
        [Parameter(Mandatory)]
        [string]$Value 
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
        $objects = New-Object System.Collections.Generic.List[PSCustomObject]
    }
    process{
        foreach($Computer in $ComputerName){
            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                $cmd = "SELECT value FROM sys.configurations WHERE name = '$Name'"
                $result = $srv.ConnectionContext.ExecuteWithResults($cmd).Tables[0] | select-object -ExpandProperty value
                if($result.ToString() -ne $Value){
                    [void]$objects.Add([PSCustomObject]@{
                        ComputerName = $Computer 
                        Equal = $false
                    });
                    $Computer | Add-EventLogEntry -EntryType Warning -Message "Configuration item '$Name' on computer $Computer does not equal $Value.  The value is $result."
                    return;
                }
                [void]$objects.Add([PSCustomObject]@{
                    ComputerName = $Computer 
                    Equal = $true
                });
            }
            catch{
                throw $_ 
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect()
                }
            }

        }
    }
    end{
        return ![bool]($objects | Where-Object{$_.Equal -eq $false})
    }
}