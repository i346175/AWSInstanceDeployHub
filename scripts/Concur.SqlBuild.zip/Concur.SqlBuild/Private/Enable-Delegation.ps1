function Enable-Delegation{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$SQLServiceAccount,
        [Parameter(Mandatory)]
        [string]$TCPPort
    )
    begin{
        
    }
    process{
        try{
            if($env:microservice -in ('cthost','expense','spend-impl','outtask')){
                $ComputerName | ForEach-Object{
                    $compName = $_
                    $compName | Add-EventLogEntry -EntryType Information -Message "Enabling [$compName] for delegation."
                    Set-ADUser -Identity $SQLServiceAccount -Add @{'msDS-AllowedToDelegateTo'="MSSQLSvc/$($compName).$($env:aws_envt).system.cnqr.tech:$($TCPPort)"}
                }
            }
        }catch{
            $msg = $_
            $ComputerName | Add-EventLogEntry -EntryType Warning -Message "There was an error in trying to enable server(s) for delegation.`n $msg"
        }
    }
    end{

    }
}