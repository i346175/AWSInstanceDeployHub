function Get-Domain{
    #return $env:USERDNSDOMAIN 
    return Get-Configuration | Select-Object -ExpandProperty domain
}