function add-eventlogentry{
    <#
    .SYNOPSIS
    Adds an entry to the event log of the specified computers
    
    .DESCRIPTION
    Adds an entry to the event log of the specified computers
    
    .PARAMETER ComputerName
    The name of the computer(s) on which to add the event log entry
    
    .PARAMETER LogName
    The name of the event log to add the message to (Application, Setup, System...)
    
    .PARAMETER Source
    The source of the log entry.  If the source does not exist, a new source is added.  'SqlConfig' is the default.
    
    .PARAMETER EntryType
    The type of entry (Information, Warning, Critical, Error, Verbose)
    
    .PARAMETER EventID
    The ID of the event
    
    .PARAMETER Message
    The message you want added to the log
    
    .EXAMPLE
    Add-EventLogEntry -Message "This is a test message"
    
    .EXAMPLE
    Add-EventLogEntry -Message "This is a test message" -LogName 'Application' -Source 'MyAppName' -EntryType 'Information'

    .NOTES
    This will also write to the powershell stream based upon the type of entry.  For example, if the EntryType were Verbose, it 
    writes to the verbose steam.
    Both Critical and Error write to the Error stream.
    #>
    
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        $LogName = 'Setup',
        $Source = 'SqlConfig',
        [ValidateSet('Information', 'Warning', 'Error', 'Verbose')]
        $EntryType = 'Information',
        [int]$EventID = 1111,
        [Parameter(Mandatory)]
        [string]$Message,
        [switch]$throw#,
        #[PSCredential]$Credential
    )
    begin{

    }
    process{
        $neededDirectory = get-item "C:\mssql-scripts\ConcurSqlBuild" -ErrorAction SilentlyContinue
        if(!$neededDirectory){
            New-Item -Path "C:\mssql-scripts" -Name "ConcurSqlBuild" -ItemType Directory
        }
        $logstring = ($(Get-Date).toString())+" : "+$Message
        if($EntryType -ne "Information")
            {
                Write-Host $logstring
            }
        Write-Output $logstring | Out-File -Append "C:\mssql-scripts\ConcurSqlBuild\concursqlbuild.log"
<#
# This code isn't functional, for now. 
# Due to changes in the build process, and complexities with hardening, we can no longer log to the event log.
# This should be investigated and remediated in the future, if deemed important.
# 
        switch($EntryType){
            'Information'{
                Write-Information $Message
                break;
            }
            'Warning'{
                Write-Warning $Message
                break;
            }
            'Error'{
                $Message = "$Message`r`nCall-Stack:`r`n$(Get-PSCallStack | Out-String)"
                if(!$throw){Write-Error $Message}
                break;
            }
            'Verbose'{
                Write-Verbose $Message
                $EntryType = 'Information'
                break;
            }
        }

        foreach($Computer in $ComputerName){
            $param = @{
                EventID = $EventID
                EntryType = $EntryType
                Message = $Message
                LogName = $LogName
                Source = $Source
                ComputerName = $Computer
            }
            #
            # The configuration below checks to see if "SqlConfig" is registered as a valid source for logging ot the event log.
            # If it isn't, then it will be registered.
            # If this isn't setup, the logging will fail. 
            #  
            $registrationCheck = Invoke-Command -ComputerName $Computer -Credential $Credential -ScriptBlock{
            Get-ChildItem HKLM:\SYSTEM\CurrentControlSet\Services\EventLog\Setup -ErrorAction SilentlyContinue
            }
            if(!$registrationCheck){
                Invoke-Command -ComputerName $Computer -Credential $Credential -ScriptBlock{
                    New-EventLog -LogName $using:LogName -Source $using:Source -ErrorAction SilentlyContinue
                }
            }
            
            Write-EventLog @param

            if($throw -and $EntryType -eq 'Error'){
                throw $Message
            }

        }#>
    }
    end{

    }
}