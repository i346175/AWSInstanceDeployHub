function Test-SID{
    param(
        [Parameter(Mandatory)]
        [string]$ComputerName,
        [Parameter(Mandatory)]
        [string]$SID
    )

    try{
        $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($ComputerName | Format-ServerName -AddPort)
        return [bool]($srv.Logins | Where-Object{(Compare-Object -ReferenceObject $_.sid -DifferenceObject ($SID | Convert-HexStringToByte)).length -gt 0})
    }
    catch{
        throw $_ 
    }
    finally{
        if($srv){
            $srv.ConnectionContext.Disconnect();
        }
    }

}