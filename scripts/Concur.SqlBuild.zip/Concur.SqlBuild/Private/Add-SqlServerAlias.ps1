function Add-SqlServerAlias{
    [cmdletbinding()]
    param(
        [parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$Name
    )
    begin{
        $config = Get-Configuration  
    }
    process{
        $Port = $config.port
        $x86Alias = "HKLM:\Software\Microsoft\MSSQLServer\Client\ConnectTo"
        $x64Alias = "HKLM:\Software\Wow6432Node\Microsoft\MSSQLServer\Client\ConnectTo"
        $keyVal = "DBMSSOCN,$($Name.ToUpper()),$Port"

        foreach($Computer in $ComputerName){
            if(!(Test-SqlServerAlias -ComputerName $Computer -Name $Computer)){
                invoke-command -ComputerName $Computer -ScriptBlock{
                    
                    $using:x86Alias, $using:x64Alias | ForEach-Object{
                        if(!(Test-Path $_)){
                            New-Item -Path $_ | Out-Null
                        }
                    }
                    New-ItemProperty -Path $using:x86Alias -Name $using:Computer -PropertyType String -Value $using:keyVal | Out-Null
                    New-ItemProperty -Path $using:x64Alias -Name $using:Computer -PropertyType String -Value $using:keyVal | Out-Null
                }
            }
        }
    }
    end{

    }
}