function Set-FIPS{
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [Alias('PhysicalName')]
        [string[]]$ComputerName,
        [bool]$Enabled = $true
    )
    begin{

    }
    process{

        foreach($Computer in $ComputerName){
            if(!(Test-Connection -ComputerName $Computer -Count 2 -Quiet)){
                throw "Could not connect to computer $Computer"
            }

            Invoke-Command -ComputerName $ComputerName -ScriptBlock{
                Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa\FipsAlgorithmPolicy' -Name Enabled -Value ([int]$using:Enabled)
            }

        }

    }
    end{

    }
}