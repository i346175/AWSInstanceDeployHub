function Enable-Protocol{
    <#
      .SYNOPSIS
      Enables a SQL Server protocol and restarts SQL Server
      
      .DESCRIPTION
      This will enable either Named Pipes, Shared Memory or the TCP protocol for the default SQL Server instance
      and restart the SQL Server service to make the changes take effect
      
      .PARAMETER ComputerName
      The name(s) of Computer(s) to run against
      
      .PARAMETER Protocol
      The name of the protocol to disable - 'NM' (Named Pipes), 'SM' (Shared Memory), 'TCP'
      
      .EXAMPLE
      PS> Enable-Protocol -ComputerName SEAPR1DBBAT083 -Protocol NP
      
      .EXAMPLE
      PS> Enable-Protocol -ComputerName SEAPR1DBBAT083 -Protocol SM 
  
      .EXAMPLE
      PS> Enable-Protocol -ComputerName SEAPR1DBBAT083 -Protocol TCP
  
      .EXAMPLE
      PS> Enable-Protocol -ComputerName SEAPR1DBBAT083,SEAPR1DBBAT082 -Protocol NP
  
      .NOTES
      
      #>
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName, 
        [ValidateSet('SM','TCP','NP')]
        [string]$Protocol
    )
    begin{

    }
    process{

        foreach($Computer in $ComputerName){

            $Computer | Add-EventLogEntry -EntryType Verbose -Message "Disabling protocol $Protocol on server $Computer and restarting SQL Server service..."

            Invoke-Command  -ComputerName $Computer -ScriptBlock{
                [system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
                [system.reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SqlWmiManagement") | Out-Null

                $wmi = New-Object Microsoft.SqlServer.Management.smo.WMI.ManagedComputer $env:COMPUTERNAME
                
                $uri = "ManagedComputer[@Name='$env:COMPUTERNAME']/ServerInstance[@Name='MSSQLSERVER']/ServerProtocol[@Name='$using:Protocol']" 
                $prot = $wmi.GetSmoObject($uri)
                if($prot.IsEnabled){
                    return;
                }
                $prot.IsEnabled = $true;  
                $prot.Alter() 

                #this function can't be used in the invoke-command, the Add-EventLogEntry only exists on the computer that is calling the invoke-command
                #remember, invoke-command is executing all the commands inside of it ON the remote computer
                #Add-EventLogEntry -EntryType Verbose -Message "SQL Server protocol $using:Protocol disabled on server $using:Computer"
                #Add-EventLogEntry -EntryType Verbose -Message "Restarting SQL Server Service on $using:Computer."
                
                Get-Service -Name MSSQLSERVER | Restart-Service -Force | Out-Null
                Start-Service -Name SQLSERVERAGENT 
            }

        }
    }
    end{
  
    }
}