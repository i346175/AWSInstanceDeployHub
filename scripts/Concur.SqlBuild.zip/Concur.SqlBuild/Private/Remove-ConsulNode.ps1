function Remove-ConsulNode{
    param(
        [Parameter(Mandatory)]
        [string]$ComputerName,
        [Parameter(Mandatory)]
        [PSCredential]$Credential,
        [string]$Role = 'dbsql'
    )

    $token = Get-VaultToken #-Credential $Credential
    if([System.String]::IsNullOrWhiteSpace($token)){
        throw "Untable to retrieve vault token.  Cannot continue."
    }

    $headers = @{}
    $headers.Add("X-Vault-Token", $token)
    $headers.Add("ContentType", "application/json")
    try{
        $result = Invoke-RestMethod -Uri "https://vault.service.cnqr.tech/v1/consul/creds/dbsql" -Headers $headers 
        $token = $result.data.token
    }
    catch{
        $_ | fl -Force
        throw $_ 
    }

    $payload = [ordered]@{
        Datacenter = 'uspscc'
        Node = "$Role-$ComputerName"
    }
    $json = $payload | ConvertTo-Json 

    $headers = @{}
    $headers.Add("X-Consul-Token", $token)
    $headers.Add("ContentType", "application/json")

    [System.Net.ServicePointManager]::CheckCertificateRevocationList = $false
    [System.Net.ServicePointManager]::Expect100Continue = $false
    [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

    $uri = [uri]::EscapeUriString("https://consul.service.cnqr.tech/v1/catalog/deregister");


    try{
        Invoke-RestMethod -Uri $uri -Method Put -ContentType 'application/json' -Body $json -Headers $headers | fl -Force
    }
    catch{
        $_ | fl -Force
    }
}
