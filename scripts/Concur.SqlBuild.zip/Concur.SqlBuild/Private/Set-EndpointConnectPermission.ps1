function Set-EndpointConnectPermission{
    <#
    .SYNOPSIS
    Grants connect permission to the Account passed in on the $Name parameter
    
    .DESCRIPTION
    Grants connect permission to the Account passed in on the $Name parameter
    
    .PARAMETER ComputerName
    The name of the computer to apply the permission on
    
    .PARAMETER Name
    The name of the account to apply the permission on
    
    .PARAMETER EndPointName
    The endpoint name.  Defaults to the default 'hadr_endpoint'
    
    .EXAMPLE
    $ComputerName | Set-EndpointConnectPermission -Name 'devtest\sa_sqlacct'
    
    .NOTES
    General notes
    #>
    
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string]$ComputerName,
        [Parameter(Mandatory)]
        [string]$Name,
        [string]$EndPointName = 'hadr_endpoint'
    )
    begin{

    }
    process{

        foreach($Computer in $ComputerName){

            if(!(Test-ADAccount -Name $Name)){
                $Computer | Add-EventLogEntry -EntryType Warning -Message "Account $Name is not a valid account and was not granted connect permissions to the endpoint $EndPointName on computer $Computer"
                return;
            }

            $Name = $Name | Format-LoginName -DomainType DN 

            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                if(!($Computer | Test-EndPoint -Name $EndPointName)){
                    $Computer | Add-EventLogEntry -EntryType Warning -Message "Endpoint $EndPointName does not exist on computer $ComputerName"
                    return;
                }
                $connect = New-Object Microsoft.SqlServer.Management.Smo.ObjectPermissionSet([Microsoft.SqlServer.Management.Smo.ObjectPermission]::Connect, $Name);
                $srv.Endpoints[$EndPointName].Grant($connect);
            }
            catch{
                throw $_ 
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }
    }
    end{

    }
}