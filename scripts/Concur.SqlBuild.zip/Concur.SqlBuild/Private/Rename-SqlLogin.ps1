function Rename-SqlLogin{
    <#
    .SYNOPSIS
    Renames a sql login
    
    .DESCRIPTION
    Renames a sql login
    
    .PARAMETER ComputerName
    One or more computers where the login is to be renamed
    
    .PARAMETER Name
    The name of the login
    
    .PARAMETER NewName
    The new name of the login
    
    .EXAMPLE
    'Server1', 'Server2', 'Server3' | Rename-SqlLogin -Name 'sa' -NewName 'BlaqueJaqueShellaque'
    
    .EXAMPLE 
    Rename-SqlLogin -ComputerName Server1 -Name 'sa' -NewName 'BlaqueJaquesShellaque

    .NOTES
    If the login doesn't exist, this will try to create the new login.  If that doesn't work, warning is then printed.
    #>
    
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$Name,
        [Parameter(Mandatory)]
        [string]$NewName
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
    }
    process{

        foreach($Computer in $ComputerName){
            try{
                $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($Computer | Format-ServerName -AddPort)
                $srv.ConnectionContext.TrustServerCertificate = $true
                if($srv.Logins[$NewName]){
                    $Computer | Add-EventLogEntry -EntryType Warning -Message "Login $NewName already exists on computer $Computer.  (Rename-SqlLogin)"
                    return;
                }
                if(!($srv.Logins[$Name])){
                    Add-Login -ComputerName $Computer -Name $Name
                }
                if($srv.Logins[$Name].LoginType -ne [Microsoft.SqlServer.Management.smo.LoginType]::SqlLogin){
                    $Computer | Add-EventLogEntry -EntryType Warning -Message "Login $Name is not a sql login on computer $Computer."
                    return;
                }
                [void]$srv.Logins[$Name].Rename($NewName);
            }
            catch{
                throw $_ 
            }
            finally{
                if($srv){
                    $srv.ConnectionContext.Disconnect();
                }
            }
        }
    }
    end{

    }
}