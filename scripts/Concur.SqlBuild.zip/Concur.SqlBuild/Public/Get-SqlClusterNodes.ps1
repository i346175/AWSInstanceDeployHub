function Get-SqlClusterNodes{
    [cmdletbinding(DefaultParameterSetName="ComputerName")]
    param(
        [Parameter(Mandatory, ParameterSetName="ComputerName", ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string]$ComputerName,
        [Parameter(Mandatory, ParameterSetName="ClusterName", ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string]$ClusterName,
        [Parameter(Mandatory, ParameterSetName="ListenerName", ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string]$ListenerName
    )
    begin{
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoEnum")
        [void][reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
        
        $config = Get-Configuration 

        $objects = new-object System.Collections.Generic.List[PSCustomObject]
    }
    process{
        try{
            switch($PSCmdlet.ParameterSetName){
                "ComputerName"{
                    $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($ComputerName | Format-ServerName -AddPort)
                }
                "ClusterName"{
                    $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($ClusterName | Format-ServerName -AddPort)
                }
                'ListenerName'{
                    $srv = New-Object Microsoft.SqlServer.Management.smo.Server ($ListenerName | Format-ServerName -AddPort)
                }
            }
            foreach($Group in $srv.AvailabilityGroups){
                foreach($Replica in $Group.AvailabilityReplicas){
                    [void]$objects.Add([PSCustomObject]@{
                        ComputerName = $Replica.Name 
                        PSComputerName = $srv.ComputerNamePhysicalNetBIOS
                        AvailabilityGroupName = $Group.Name 
                    });
                }
            }
        }
        catch{
            throw $_ 
        }
        finally{
            if($srv){
                $srv.ConnectionContext.Disconnect();
            }
        }
    }
    end{
        return $objects;
    }
}