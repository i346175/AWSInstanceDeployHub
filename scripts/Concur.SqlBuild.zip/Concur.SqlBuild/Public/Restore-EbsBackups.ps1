function Restore-EbsBackups{
<#
.SYNOPSIS
Restores a database from the local EBS drive.  

.DESCRIPTION
Restores a database from the local EBS drive, currently the M: drive.

.PARAMETER ServerName
The name of the server where the database you want restored currently resides.

.PARAMETER DatabaseName
The name of the database you want restored.

.PARAMETER StopAt
The date\time you want the restore to stop at

.PARAMETER RestoreServer
The name of the server that you want the database restored to

.PARAMETER RestoreDB
The name of the database you want this restored as

.PARAMETER FullOnly
Restore only the last full backup

.PARAMETER NoRecovery
Leave the database in recovery mode

.PARAMETER Execute
Execute the restore.

.PARAMETER Force
Force the restore if the database already exists

.EXAMPLE
Restore-EbsBackups -ServerName vpc11-gdmv-0vgc.uspscc.system.cnqr.tech -DatabaseName Test4 -RestoreServer vpc11-gdmv-0vgc.uspscc.system.cnqr.tech -RestoreDB Test4Restore0

.NOTES
If the -Execute switch is not provided, this cmdlet will only print out the restore statements.
#>    
    [cmdletbinding()]
    param(
        [Alias('ComputerName', 'CN', 'PhysicalName')]
        [Parameter(Mandatory=$true)]
        [string]$ServerName,
        [Parameter(Mandatory=$true)]
        [string]$DatabaseName,
        [datetime]$StopAt = ((get-date).AddDays(1)),
        [string]$RestoreServer,
        [string]$RestoreDB = $null,
        [switch]$FullOnly,
        [switch]$DiffOnly,
        [switch]$LogOnly,
        [switch]$NoRecovery,
        [switch]$Execute,
        [switch]$Force
    )
    begin{
        $config = Get-Configuration
        $Port = $config.Port
    }
    process{

        $ServerName = $ServerName | Format-ServerName

        $cmd = "DECLARE 
	        @DatabaseName	VARCHAR(100) = '$DatabaseName',
	        @StopAt DATETIME = '$StopAt',
	        @FullBackupStartSetID INT,
	        @DiffBackupStartSetID INT


        SELECT 
	        @FullBackupStartSetID = MAX(b.backup_set_id)
        FROM msdb.dbo.backupset b
        WHERE b.backup_start_date < @StopAt
        AND b.type = 'D'
        AND b.database_name = @DatabaseName

        SELECT @DiffBackupStartSetID = MAX(b.backup_set_id)
        FROM msdb.dbo.backupset b
        WHERE b.backup_start_date < @StopAt
        AND b.type = 'I'
        AND b.database_name = @DatabaseName
        AND b.backup_set_id > @FullBackupStartSetID

        --FULL
        SELECT 
	        b.database_name,
	        'FULL' AS BackupType,
	        b.backup_start_date,
	        m.physical_device_name
        FROM msdb.dbo.backupset b 
        INNER JOIN msdb.dbo.backupmediafamily m ON b.media_set_id = m.media_set_id
        WHERE 1=1
        AND b.backup_set_id = @FullBackupStartSetID
        UNION ALL --DIFF
        SELECT 
	        b.database_name,
	        'DIFF' AS BackupType,
	        b.backup_start_date,
	        m.physical_device_name
        FROM msdb.dbo.backupset b 
        INNER JOIN msdb.dbo.backupmediafamily m ON b.media_set_id = m.media_set_id
        WHERE 1=$([int][bool]!$FullOnly)
        AND b.backup_set_id = @DiffBackupStartSetID
        UNION ALL --LOGS
        SELECT
	        b.database_name,
	        'LOG' AS BackupType,
	        b.backup_start_date,
	        m.physical_device_name
        FROM msdb.dbo.backupset b 
        INNER JOIN msdb.dbo.backupmediafamily m ON b.media_set_id = m.media_set_id
        WHERE 1=$([int][bool]!$FullOnly)
        AND b.[type] = 'L'
        AND b.database_name = @DatabaseName
        AND b.backup_set_id > ISNULL(@DiffBackupStartSetID, @FullBackupStartSetID)
        AND b.backup_finish_date < @StopAt
        ORDER BY b.backup_start_date"

        if(!(test-connection -ComputerName $ServerName -Count 2 -Quiet)){
            throw "Could not connect to server $ServerName"
        }

        if(!$RestoreDB){
            $RestoreDB = $DatabaseName
        }

        $srv = New-Object Microsoft.SqlServer.Management.Smo.Server "$ServerName,$Port"
        if([int]$srv.VersionMajor -ge [int]11 -and $srv.IsHadrEnabled){
            if($srv.AvailabilityGroups.Count -gt 0){
                $srv.AvailabilityGroups | %{
                    if($_.AvailabilityDatabases.Contains($DatabaseName)){
                        $serverName = $_.PrimaryReplicaServerName
                        return;
                    }

                }
            }
        }
        $srv.ConnectionContext.Disconnect();

        #$backups = Invoke-Sqlcmd -ServerInstance "$ServerName,$Port" -Database msdb -Query $cmd
        $srv = New-Object Microsoft.SqlServer.Management.Smo.Server "$ServerName,$Port"
        $backups = $srv.Databases['msdb'].ExecuteWithResults($cmd).Tables[0];
        $srv.ConnectionContext.Disconnect();
        if(!$backups){
            throw "Could not find any backups for database $DatabaseName on server $ServerName"
        }

        #check to make sure the backup file exists...before you go wasting a bunch of time restoring only to find out
        #that someone deleted one of the backup files...unfortunately, this shouldn't be needed...but is...
        $backups | ForEach-Object{
            $FqdnPath = '\\' + $ServerName + '\' + $_.physical_device_name.Replace(':', '$')

            if(!([System.IO.File]::Exists($FqdnPath))){
                Write-Warning "Could not access file $FqdnPath.  Check to ensure this file exists.  Restore will attempt anyway."
            }
        }

        $restoreScript = New-Object System.Collections.Generic.List[PSCustomObject]
        $backups | ForEach-Object{
            $FqdnPath = '\\' + $ServerName + '\' + $_.physical_device_name.Replace(':', '$')

            if($_.BackupType -ne 'LOG'){
                [void]$restoreScript.Add([PSCustomObject]@{
                    Type = $_.BackupType 
                    FullName = $FqdnPath
                    Command = "RESTORE DATABASE [$RestoreDB]`r`nFROM DISK = N'$FqdnPath'`r`nWITH NORECOVERY,`r`nSTATS = 5;`r`n"
                });
            }
            else{
                [void]$restoreScript.Add([PSCustomObject]@{
                    Type = $_.BackupType
                    FullName = $FqdnPath
                    Command = "RESTORE LOG [$RestoreDB]`r`nFROM DISK = N'$FqdnPath'`r`nWITH NORECOVERY,`r`nSTATS = 5,`r`nSTOPAT = '$StopAt';`r`n"
                });
            }

        }

        #the fullonly is taken care of in the sql statement itself...
        if($DiffOnly){
            $restorescript = $restoreScript | Where-Object{$_.Type -eq 'DIFF'}
        }
        if($LogOnly){
            $restoreScript = $restoreScript | Where-Object{$_.Type -eq 'LOG'}
        }

        [void]$restoreScript.Add([PSCustomObject]@{
            Type = "RECOVERY"
            FullName = ""
            Command = "RESTORE DATABASE [$RestoreDB] WITH RECOVERY;`r`n"
        });

        <# For now, leave whoever restores it as the owner.
        [void]$restoreScript.Add([PSCustomObject]@{
            Type = "DBOWNER"
            FullName = ""
            Command = ";USE [$RestoreDB]; ALTER AUTHORIZATION ON DATABASE::[$RestoreDB] TO ussea7xadmin"
        });
        #>

        if(!$Execute){
            return $restoreScript | Select-Object -ExpandProperty Command
        }

        $srv = New-Object Microsoft.SqlServer.Management.Smo.Server "$RestoreServer,$Port"
        $srv.ConnectionContext.Connect();
        $srv.ConnectionContext.StatementTimeout = 0;

        if($srv.Databases[$RestoreDB] -and !$Force){
            throw "Database $RestoreDB already exists on server $RestoreServer.  To replace this database, you must drop the existing $RestoreDB on server $RestoreServer first."
        }

        $restoreScript | Where-Object{$_.Type -eq 'FULL'} | ForEach-Object{
            Restore-SqlDatabase -InputObject $srv -Database $RestoreDB -RestoreAction Database -BackupFile ($_.FullName) -NoRecovery -ErrorAction Stop -ReplaceDatabase:$Force
        }
        $restoreScript | Where-Object{$_.Type -eq 'DIFF'} | ForEach-Object{
            Restore-SqlDatabase -InputObject $srv -Database $RestoreDB -RestoreAction Database -BackupFile ($_.FullName) -NoRecovery -ErrorAction Stop
        }
        $restoreScript | Where-Object{$_.Type -eq 'LOG'}  | ForEach-Object{
            Restore-SqlDatabase -InputObject $srv -Database $RestoreDB -RestoreAction Log -BackupFile ($_.FullName) -NoRecovery -ErrorAction Stop
        }

        if(-not $NoRecovery){
            [void]$srv.ConnectionContext.ExecuteNonQuery("RESTORE DATABASE [$RestoreDB] WITH RECOVERY");
            
            # For now, leave whoever restores it as the owner.
            # [void]$srv.ConnectionContext.ExecuteNonQuery("USE [$RestoreDB]; ALTER AUTHORIZATION ON DATABASE::[$RestoreDB] TO ussea7xadmin");
        }
        $srv.ConnectionContext.Disconnect();
    }
    end{

    }
}
