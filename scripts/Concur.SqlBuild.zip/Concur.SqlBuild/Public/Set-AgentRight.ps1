function Set-AgentRight{
    [cmdletbinding()]
    param(
        [string[]]$ComputerName,
        [string]$Name,
        [string[]]$Right = @('SeServiceLogonRight', 'SeAssignPrimaryTokenPrivilege', 'SeChangeNotifyPrivilege', 'SeIncreaseQuotaPrivilege', 'SeBatchLogonRight')
    )
    
    Add-windowsLogin -ComputerName $ComputerName -Name $Name -Right $Right 
    Remove-WindowsGroupMember -ComputerName $ComputerName -Name $Name -Group 'Administrators'
    

}