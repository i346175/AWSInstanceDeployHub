function New-Cluster{
<#
.SYNOPSIS
Creates a new WSFC

.DESCRIPTION
Creates a new WSFC

.PARAMETER ComputerName
The names of the computers participating in the cluster

.PARAMETER ClusterName
The name of the cluster

.PARAMETER ClusterIP
The IP of the cluster

.PARAMETER Credential
A PSCredential object that has permissions to log into the boxes and create clusters.

.EXAMPLE
Create-Cluster -ComputerName $Computers -ClusterName 'SEAPR1DBC111' -ClusterIP 1.1.1.1 -Credential $cred

.EXAMPLE
Create-Cluster -ComputerName $Computers -ClusterName "CN=AWSPR1DB1111,OU=DbClusters,OU=awsqa,OU=Infrastructure,OU=Servers,OU=nonprod,DC=nonprod,DC=cnqr,DC=tech" -ClusterIP 1.1.1.1 -Credential $cred

.NOTES
To create clusters within certain OU's, pass in the fully qualified canocial name of the ou in which clusters are permitted to be created
#>

    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$ClusterName,
        [Parameter(Mandatory)]
        [string]$ClusterIP,
        [Parameter(Mandatory)]
        [PSCredential]$Credential
    )
    begin{
        $objects = New-Object System.Collections.Generic.List[PSCustomObject]
    }
    process{

        foreach($Computer in $ComputerName){
            if(!(Test-Connection -ComputerName $Computer -Count 1 -Quiet)){
                #throw "Could not connect to computer $Computer"
                Write-Warning "Could not connect to computer $Computer.  This node will be omitted from the cluster."
                return;
            }
            [void]$objects.Add([PSCustomObject]@{
                Name = $Computer
            });

            #add failover-clustering if not already enabled...
            Invoke-Command -ComputerName $Computer -ScriptBlock{
                if(!(Get-WindowsFeature -Name 'Failover-Clustering')){
                    Add-WindowsFeature -Name 'Failover-Clustering' -IncludeManagementTools
                }
            }
        }

        if(!$objects){
            throw "No valid computers were provided to create a cluster."
        }

        $command = "
            Import-Module FailoverClusters
                      
            try{
                New-Cluster -Name '$ClusterName' -Node $(($objects | Select-Object -ExpandProperty Name) -join ',') -NoStorage -StaticAddress $ClusterIP -Verbose *>&1 | Out-File c:\Install\ClusterBuild.txt -Force    
            }
            catch{
                $_ | Format-List -Force | Out-String | out-file 'c:\Install\ClusterError.txt' -Append -Force
            }   
        }"
        $sb = [ScriptBlock]::Create($command);
        $nodeName = ($objects | Select-Object Name | Select-Object -First 1)
        write-verbose "Cluster creation is being executed from $nodeName..."
        Invoke-ScheduledTask -Computername $nodeName -Credential $Credential -ScriptBlock $sb -Wait 


    }
    end{

    }
}