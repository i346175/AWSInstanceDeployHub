function Set-SqlServerExtendedProperty{
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$Name,
        [string]$Value = "" 
    )

    Set-ExtendedProperty -ComputerName $ComputerName -Name $Name -Value $Value 
}