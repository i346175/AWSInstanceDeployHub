function Set-SqlServerProxies{
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [PSCredential]$Credential 
    )

    $config = Get-SqlDefaultConfiguration 

    <#
    [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$Name,
        [Parameter(Mandatory)]
        [string]$AccountName,
        [Parameter(Mandatory)]
        #[ValidateSet('TransactSql', 'ActiveScripting', 'CmdExec', 'Snapshot', 'LogReader', 'Distribution', 'Merge', 'QueueReader', 'AnalysisQuery', 'AnalysisCommand', 'Ssis', 'PowerShell')]
        [string[]]$SubSystem

    #>

    <#
    "name":"pnsqluser",
            "credential":"sa_pnsqluser",
            "subsystem":["CmdExec", "Powershell"]
    #>
    $script:token = Get-VaultToken #-Credential $Credential
    if([System.String]::IsNullOrEmpty($script:token)){
        throw "token not retrieved from vault."
        return;
    }

    foreach($proxy in $config.proxies){
        Add-ProxyAccount -ComputerName $ComputerName -Name $proxy.name -Account $proxy.credential -SubSystem $proxy.subsystem 
    }
    

}