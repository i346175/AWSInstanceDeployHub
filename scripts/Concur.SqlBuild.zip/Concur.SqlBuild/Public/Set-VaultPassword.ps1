function Set-VaultPassword{
    param(
        [Parameter(Mandatory)]
        [pscredential]$Account
    )

    Set-Password -Account $Account 

}