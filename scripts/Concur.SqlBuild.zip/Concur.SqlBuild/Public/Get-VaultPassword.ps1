function Get-VaultPassword{
    param(
        [Parameter(Mandatory)]
        [string]$Name
        
    )
    
    return Get-Password -Name $Name 

}