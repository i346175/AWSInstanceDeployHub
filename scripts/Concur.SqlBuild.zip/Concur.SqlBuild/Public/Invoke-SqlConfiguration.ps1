function Invoke-SqlConfiguration{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline)]
        [string[]]$ComputerName,
        [PSCredential]$Credential,
        [string]$TimeZone = 'Pacific Standard Time'
    )
    begin{

    }
    process{
        try{
            <#
            #TODO:  Re-enable this code when they get the domain stuff worked out...

            if(!(Test-ADCredential -Credential $Credential)){
                throw "Credential $($Credential.UserName) are not valid credentials."
            }
            if(Test-ProxyEnabled){
                $Computer | Add-EventLogEntry -EntryType Error -Message "The proxy is enabled on computer $env:computername.`r`nPlease disable the proxy before installing." -throw
            }
            #>
            foreach($Computer in $ComputerName){
                if(!(Test-Connection -ComputerName $Computer -Count 3 -Quiet)){
                    $Computer | Add-EventLogEntry -EntryType Error -Message "Computer $Computer could not be reached via ping." -throw
                    return;
                }
                $Computer | Invoke-SqlDefaultConfiguration -Credential $Credential -TimeZone $TimeZone
            } 
        }
        catch{
            $ComputerName | Add-EventLogEntry -EntryType Error -Message "$($_ | Format-List -Force | Out-String)"
            return;
        }
    }
    end{

    }
    
    

}