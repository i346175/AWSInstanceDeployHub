function Invoke-RoleConfiguration{
    <#
    .SYNOPSIS
    Configures a sql server instance according to the role type configuration properties in the Config/RoleTypes/<roletype>.json file
    
    .DESCRIPTION
    Configures a sql server instance according to the role type configuration properties in the Config/RoleTypes/<roletype>.json file
    
    .PARAMETER ComputerName
    The name(s) of the computers you want to configure
    
    .PARAMETER Name
    The name of the role.  This MUST be one of the names of the files in the Config/RoleTypes module directory (sans the .json).  If not, this will throw an exception.
    
    .PARAMETER Credential
    Parameter description
    
    .EXAMPLE
    An example
    
    .NOTES
    General notes
    #>
    
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$Name,
        [Parameter(Mandatory)]
        [PSCredential]$Credential,
        [string]$ListenerName
    )

    try{
        if(!(Test-ADCredential -Credential $Credential)){
            $ComputerName | Add-EventLogEntry -EntryType Error -Message "Credential $($Credential.UserName) are not valid credentials." -throw
            return;
        }

        #we're using one role now...so 
        if(!(Get-RoleTypes | Where-Object{$_.Name -eq $Name})){
            $ComputerName | Add-EventLogEntry -EntryType Error -Message "Role type $Name is not a valid role type." -throw 
            return;
        }

        #$ComputerName | Invoke-RoleTypeConfiguration -Name $Name -Credential $Credential
        Invoke-RoleTypeConfiguration -ComputerName $ComputerName -Name $Name -Credential $Credential -ListenerName $ListenerName
    }
    catch{
        $ComputerName | Add-EventLogEntry -EntryType Error -Message "$($_ | Format-List -Force | Out-String)"
        return;
    }
}