function Remove-WindowsGroupMember{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string[]]$ComputerName,
        [Parameter(Mandatory)]
        [string]$Name,
        [string]$Group = 'Administrators'
    )
    begin{

    }
    process{

        $Name = $Name | Format-LoginName

        foreach($Computer in $ComputerName){
            Invoke-Command -ComputerName $Computer -ScriptBlock{

                $sb = {
                    if($_.Name.Contains('\')){
                        return $_.Name.Split('\')[1]
                    }
                    else{
                        return $_.Name 
                    }
                }
                if(!(Get-LocalGroupMember -Group 'Administrators' | select objectClass, Name, @{n='Login';e=$sb} | Where-Object{$_.Login -eq "$using:Name"})){
                    Write-Warning "Login $($using:Name) does not exist on computer $Computer."
                    return;
                }
                Remove-LocalGroupMember -Group $using:Group -Member $using:Name
            }
        }

    }
    end{

    }

}