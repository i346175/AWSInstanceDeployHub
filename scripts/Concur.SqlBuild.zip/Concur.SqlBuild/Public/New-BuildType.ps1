function New-BuildType{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [string]$Name,
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [string]$SqlServiceAccount,
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [string]$SqlAgentAccount,
        [Parameter(Mandatory)]
        [string]$Jurisdiction,
        [book]$InCTHost = $false,
        [Parameter(Mandatory)]
        [string]$DatabaseScriptLocation,
        [Parameter(Mandatory)]
        [hashtable[]]$LinkedServers,
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [hashtable[]]$Storage,
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [hashtable[]]$Logins,
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)]
        [hashtable[]]$SqlConfigurationOptions,
        [hashtable[]]$Databases,
        [switch]$Force
    )
    begin{

    }
    process{
        $roles = Get-RoleTypes
        if($roles | Where-Object{$_.Name -eq $Name -and !$Force}){
            throw "A build with the role type name $Name already exists."
        }

        $parent = Split-Path -Path $PSScriptRoot -Parent
        $configFiles = [System.io.Path]::Combine($parent, "Config", "RoleTypes")

        $fileName = Join-Path -Path $configFiles -ChildPath "$Name.json"
        New-Item -ItemType File -Path $fileName -Force

        $object = [PSCustomObject]@{
            sqlserviceaccount = $SqlServiceAccount
            sqlagentaccount = $SqlAgentAccount
            jurisdiction = $Jurisdiction
            dbscriptlocation = $DatabaseScriptLocation
            linkedservers = $LinkedServers
            storage = $Storage
            logins = $Logins
            sp_config = $SqlConfigurationOptions
            dbs = $Databases
        }

        Set-Content -Path $fileName -Value ($object | ConvertTo-Json)

    }
    end{

    }
}