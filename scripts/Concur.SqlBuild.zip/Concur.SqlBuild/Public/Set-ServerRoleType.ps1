function Set-ServerRoleType{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string]$ComputerName,
        [Parameter(Mandatory, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [string]$RoleType
    )
    begin{

    }
    process{
        if(!(Get-RoleTypes | Where-Object{$_.Name -eq $RoleType})){
            throw "Role type $RoleType was not found in the role type configuration.`r`nEnsure that this role type exists."
        }

        $config = Get-RoleTypeConfiguration -Name $RoleType
        

    }
    end{

    }
}