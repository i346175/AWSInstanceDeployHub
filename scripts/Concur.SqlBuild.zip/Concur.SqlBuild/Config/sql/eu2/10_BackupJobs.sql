/*
                                                                             
                                                                               
EEEEEEEEEEEEEEEEEEEEEEUUUUUUUU     UUUUUUUU                  222222222222222    
E::::::::::::::::::::EU::::::U     U::::::U                 2:::::::::::::::22  
E::::::::::::::::::::EU::::::U     U::::::U                 2::::::222222:::::2 
EE::::::EEEEEEEEE::::EUU:::::U     U:::::UU                 2222222     2:::::2 
  E:::::E       EEEEEE U:::::U     U:::::U                              2:::::2 
  E:::::E              U:::::D     D:::::U                              2:::::2 
  E::::::EEEEEEEEEE    U:::::D     D:::::U                           2222::::2  
  E:::::::::::::::E    U:::::D     D:::::U  ---------------     22222::::::22   
  E:::::::::::::::E    U:::::D     D:::::U  -:::::::::::::-   22::::::::222     
  E::::::EEEEEEEEEE    U:::::D     D:::::U  ---------------  2:::::22222        
  E:::::E              U:::::D     D:::::U                  2:::::2             
  E:::::E       EEEEEE U::::::U   U::::::U                  2:::::2             
EE::::::EEEEEEEE:::::E U:::::::UUU:::::::U                  2:::::2       222222
E::::::::::::::::::::E  UU:::::::::::::UU                   2::::::2222222:::::2
E::::::::::::::::::::E    UU:::::::::UU                     2::::::::::::::::::2
EEEEEEEEEEEEEEEEEEEEEE      UUUUUUUUU                       22222222222222222222
   
*/

-- 10_BackupJobs.sql 
-- 
-- 2019-08-29 - Created. 
-- 2019-09-16 - Replaced "ConsulName" with "BackupRootName". 
-- 2019-09-18 - Add S3 Sync backup Job. 
-- 2019-09-18 - Changed Log backup frequency from 4 hours to 15 minutes. 
-- 2019-09-24 - Added 'dbsql-mssql-testsg.travel' to stupid case statement. 
-- 2019-10-08 - Replaced stupid switch statement with code to transform ListenerName to BucketName. 
-- 2019-10-18 - Added placeholder code for encryption keys for EBS-to-S3 sync commands. 
-- 2019-10-31 - Added CMK keys and --sse arguments, pushed to all instances. 
-- 2019-11-07 - Added CMK key for Tools VPC. 
-- 2019-12-31 - Added comments.  Added support for DevTest buckets. Added placeholders for DevTest CMK keyids.
--              Added support for different regions per environment.
-- 2020-03-23 - Re-wrote @BackupRootName to not require Extended Property for Route53 CNAME, because that won't be possible 
--              under zero-touch: using cluster name from "sys.dm_hadr_cluster" instead. 
-- 2020-03-23 - Re-wrote S3 sync code to hardcode values based on knowing which environment we're in. 
-- 2020-05-14 - Corrected Tools cluster Route53 name. 
-- 2020-05-15 - Temporarily removed CMK usage pending investigation. 
-- 2020-12-29 - Updated "GET BACKUPROOTNAME" section to use new cluster names.
-- 2021-01-08 - Updated "GET BACKUPROOTNAME" section to use new ReportingSQL08 cluster name.
-- 2021-01-13 - Updated "GET BACKUPROOTNAME" section to add new SpendImplSQL04 cluster name.
-- 2021-01-15 - Updated "GET BACKUPROOTNAME" section to add new ToolsSQL06 cluster name.
-- 2021-04-01 - Updated "GET BACKUPROOTNAME" section to add new OuttaskSQL03 cluster name.
-- 2021-07-03 - 1. Updated "GET BACKUPROOTNAME" section to use ExtendedProperty value for clusters or Nodename for standalones.
--				2. Updated "GET EncryptionKey" CASE statement to use AWS account name instead of cluster CNames.
--				3. Updated "S3 Sync Job Step Command" to set https_proxy = '' and use EncryptionKey.
-- 2022-04-15 - Added logic to use extended_properties 'BackupRootName' to automate the script creation.
-- 2023-03-14 - Added logic to improve S3 sync.
-- 2023-08-29 - CSCI-6367 Added logic to cleanup out of date backup files on M: and change DIFF retention to 2 days on M: drive.
--
-- NOTE: You can't just drop SQL Agent code into the sections below, as we have customized the 
--       code to use unique names for GOTO labels, commands, re-initializing variables, etc. 


---------------------------------------------------------------------------------------------------
-- We need to delete all the Jobs whose names start with 'DatabaseBackup%' to both get rid of the 
-- old "Ola" and "S3 Sync" Jobs, and to make this script idempotent. 
---------------------------------------------------------------------------------------------------

declare @JobName sysname

declare cur cursor for
    select name
      from msdb.dbo.sysjobs_view 
     where name like 'DatabaseBackup%'

open cur
fetch next from cur into @JobName

while @@fetch_status = 0
begin
    exec msdb.dbo.sp_delete_job @job_name=@JobName, @delete_unused_schedule=1
    print 'Deleted job ' + @JobName
    fetch next from cur into @JobName
end

close cur
deallocate cur


---------------------------------------------------------------------------------------------------
-- Set up environment variables
---------------------------------------------------------------------------------------------------

-- Get AWS environment
declare @AwsEnvironment nvarchar(128)
set @AwsEnvironment = 'eu2' 

-- Get the AWS region, as it will be different per environment: PSCC is 'us-gov-west-1', Integration is 'us-west-2'. 
declare @AwsRegion nvarchar(128)
set @AwsRegion = 'eu-central-1'

-- Get MSSQL server backup root directory info, For example: m:\mssql\backup
declare @BackupRootPath nvarchar(4000)

exec master.dbo.xp_instance_regread
     N'HKEY_LOCAL_MACHINE',
     N'Software\Microsoft\MSSQLServer\MSSQLServer',
     N'BackupDirectory',
     @BackupRootPath output,
     'no_output'

print 'BackupRootPath: ' + @BackupRootPath

-- Get extended_properties  'BackupRootName'. It has ClusterName/SererName and VPC name. For example ToolsSQL10.tools or EC2AMAZ-NI6ECB0.tools
declare @BackupRootName nvarchar(128)
declare @VPCName nvarchar(128)

IF EXISTS (SELECT 1 FROM master.sys.extended_properties WHERE name = 'BackupRootName')
	SELECT  @BackupRootName  = CAST([value] AS NVARCHAR(128)) from master.sys.extended_properties WHERE name = 'BackupRootName'
ELSE 
    BEGIN
  	 RAISERROR (N'ERROR: No extended_properties BackupRootName in database master', 10, 1); 
	 return
	END

declare @DotIndex int = charindex('.', @BackupRootName)
set @VPCName =  stuff(@BackupRootName, 1, @DotIndex, '') 

print 'VPCName: ' +  @VPCName

-- Get S3 backup bucket name prefix: For example: integration-tools-mssql-backup, full name shall be integration-tools-mssql-backup01
declare @S3BucketNameRoot nvarchar(128)
set @S3BucketNameRoot = @AwsEnvironment + '-' + @VPCName + '-mssql-backup'

print 'S3BucketNameRoot: ' + @S3BucketNameRoot
print 'BackupRootName: ' + @BackupRootName

---------------------------------------------------------------------------------------------------
-- BUILD OLA BACKUP COMMANDS 
---------------------------------------------------------------------------------------------------

-- Full backup command. 
declare @CmdFull nvarchar(max)

set @CmdFull = N'sqlcmd -E -S $(ESCAPE_SQUOTE(SRVR)) -d master '
             + N'-Q "EXECUTE [dbo].[DatabaseBackup] '
             + N'@Databases = ''ALL_DATABASES'', '
             + N'@Directory = ''' + @BackupRootPath + ''', '
             + N'@Description = ''' + @BackupRootName + ''', '
             + N'@DirectoryStructure = ''{BackupType}{DirectorySeparator}{Description}{DirectorySeparator}{DatabaseName}'', '
             + N'@AvailabilityGroupDirectoryStructure = ''{BackupType}{DirectorySeparator}{Description}{DirectorySeparator}{DatabaseName}'', '
             + N'@BackupType = ''FULL'', '
             + N'@Verify = ''Y'', '
             + N'@CleanupTime = 168, '
             + N'@CleanupMode = ''AFTER_BACKUP'', '
             + N'@CheckSum = ''Y'', '
             + N'@Compress = ''Y'', '
             + N'@ChangeBackupType = ''Y'', '
             + N'@LogToTable = ''Y'', '
             + N'@FileName                  = ''{Description}_{DatabaseName}_{BackupType}_{Partial}_{CopyOnly}_{Year}{Month}{Day}_{Hour}{Minute}{Second}_{FileNumber}.{FileExtension}'', '
             + N'@AvailabilityGroupFileName = ''{Description}_{DatabaseName}_{BackupType}_{Partial}_{CopyOnly}_{Year}{Month}{Day}_{Hour}{Minute}{Second}_{FileNumber}.{FileExtension}'' '
             + N'" -b'

print @CmdFull

-- Diff backup command. 
declare @CmdDiff nvarchar(max)

set @CmdDiff = N'sqlcmd -E -S $(ESCAPE_SQUOTE(SRVR)) -d master '
             + N'-Q "EXECUTE [dbo].[DatabaseBackup] '
             + N'@Databases = ''ALL_DATABASES'', '
             + N'@Directory = ''' + @BackupRootPath + ''', '
             + N'@Description = ''' + @BackupRootName + ''', '
             + N'@DirectoryStructure = ''{BackupType}{DirectorySeparator}{Description}{DirectorySeparator}{DatabaseName}'', '
             + N'@AvailabilityGroupDirectoryStructure = ''{BackupType}{DirectorySeparator}{Description}{DirectorySeparator}{DatabaseName}'', '
             + N'@BackupType = ''DIFF'', '
             + N'@Verify = ''Y'', '
             + N'@CleanupTime = 48, '
             + N'@CleanupMode = ''AFTER_BACKUP'', '
             + N'@CheckSum = ''Y'', '
             + N'@Compress = ''Y'', '
             + N'@ChangeBackupType = ''Y'', '
             + N'@LogToTable = ''Y'', '
             + N'@FileName                  = ''{Description}_{DatabaseName}_{BackupType}_{Partial}_{CopyOnly}_{Year}{Month}{Day}_{Hour}{Minute}{Second}_{FileNumber}.{FileExtension}'', '
             + N'@AvailabilityGroupFileName = ''{Description}_{DatabaseName}_{BackupType}_{Partial}_{CopyOnly}_{Year}{Month}{Day}_{Hour}{Minute}{Second}_{FileNumber}.{FileExtension}'' '
             + N'" -b'

print @CmdDiff

-- Log backup command. 
declare @CmdLog nvarchar(max)

set @CmdLog  = N'sqlcmd -E -S $(ESCAPE_SQUOTE(SRVR)) -d master '
             + N'-Q "EXECUTE [dbo].[DatabaseBackup] '
             + N'@Databases = ''ALL_DATABASES'', '
             + N'@Directory = ''' + @BackupRootPath + ''', '
             + N'@Description = ''' + @BackupRootName + ''', '
             + N'@DirectoryStructure = ''{BackupType}{DirectorySeparator}{Description}{DirectorySeparator}{DatabaseName}'', '
             + N'@AvailabilityGroupDirectoryStructure = ''{BackupType}{DirectorySeparator}{Description}{DirectorySeparator}{DatabaseName}'', '
             + N'@BackupType = ''LOG'', '
             + N'@Verify = ''Y'', '
             + N'@CleanupTime = 36, '
             + N'@CleanupMode = ''AFTER_BACKUP'', '
             + N'@CheckSum = ''Y'', '
             + N'@Compress = ''Y'', '
             + N'@ChangeBackupType = ''Y'', '
             + N'@LogToTable = ''Y'', '
             + N'@FileName                  = ''{Description}_{DatabaseName}_{BackupType}_{Partial}_{CopyOnly}_{Year}{Month}{Day}_{Hour}{Minute}{Second}_{FileNumber}.{FileExtension}'', '
             + N'@AvailabilityGroupFileName = ''{Description}_{DatabaseName}_{BackupType}_{Partial}_{CopyOnly}_{Year}{Month}{Day}_{Hour}{Minute}{Second}_{FileNumber}.{FileExtension}'' '
             + N'" -b'

print @CmdLog

-- Cleanup out of date backup files command. 
declare @CmdCleanup nvarchar(max)

set @CmdCleanup = N'gci -Path ' + @BackupRootPath + '\full -File -Recurse | ?{$_.Extension -in @(''.bak'') -and $_.LastWriteTime -lt (Get-Date).AddDays(-7)} | Remove-Item -force'  + CHAR(13) + CHAR(10)
             	+ N'gci -Path ' + @BackupRootPath + '\diff -File -Recurse | ?{$_.Extension -in @(''.bak'') -and $_.LastWriteTime -lt (Get-Date).AddDays(-2)} | Remove-Item -force'  + CHAR(13) + CHAR(10)
                + N'gci -Path ' + @BackupRootPath + '\log -File -Recurse | ?{$_.Extension -in @(''.trn'') -and $_.LastWriteTime -lt (Get-Date).AddDays(-2)} | Remove-Item -force'  + CHAR(13) + CHAR(10)
                + N'gci -Path ' + @BackupRootPath + '\traces -File -Recurse | ?{$_.Extension -in @(''.zip'') -and $_.LastWriteTime -lt (Get-Date).AddDays(-7)} | Remove-Item -force'  + CHAR(13) + CHAR(10)

print @CmdCleanup

---------------------------------------------------------------------------------------------------
-- CREATE FULL BACKUP JOB 
---------------------------------------------------------------------------------------------------

USE [msdb]

/****** Object:  Job [DatabaseBackup - FULL]    Script Date: 8/29/2019 6:17:49 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 8/29/2019 6:17:49 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackFull

END

DECLARE @jobId BINARY(16)
SET @jobId = NULL

EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DatabaseBackup - FULL', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'See 10_BackupJobs.sql', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'flat', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackFull
/****** Object:  Step [DatabaseBackup - FULL]    Script Date: 8/29/2019 6:17:49 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DatabaseBackup - FULL', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=@CmdFull, 
		--@output_file_name=N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\LOG\DatabaseBackup_FULL_$(ESCAPE_SQUOTE(JOBID))_$(ESCAPE_SQUOTE(STEPID))_$(ESCAPE_SQUOTE(DATE))_$(ESCAPE_SQUOTE(TIME)).txt', 
		@flags=40, 
		@proxy_name=N'sqlbackup'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackFull
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackFull
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DatabaseBackup - FULL', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20190829, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'13f03ce0-69f3-4691-8af6-a5fe38b1760e'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackFull
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackFull
COMMIT TRANSACTION
GOTO EndSaveFull
QuitWithRollbackFull:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSaveFull:


---------------------------------------------------------------------------------------------------
-- CREATE DIFF BACKUP JOB 
---------------------------------------------------------------------------------------------------

USE [msdb]

/****** Object:  Job [DatabaseBackup - DIFF]    Script Date: 8/29/2019 9:34:13 AM ******/
BEGIN TRANSACTION
--DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 8/29/2019 9:34:13 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackDiff

END

--DECLARE @jobId BINARY(16)
SET @jobId = NULL

EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DatabaseBackup - DIFF', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'See 10_BackupsJobs.sql', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'flat', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackDiff
/****** Object:  Step [DatabaseBackup - DIFF]    Script Date: 8/29/2019 9:34:13 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DatabaseBackup - DIFF', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=@CmdDiff, 
		--@output_file_name=N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\LOG\DatabaseBackup_DIFF_$(ESCAPE_SQUOTE(JOBID))_$(ESCAPE_SQUOTE(STEPID))_$(ESCAPE_SQUOTE(DATE))_$(ESCAPE_SQUOTE(TIME)).txt', 
		@flags=40, 
		@proxy_name=N'sqlbackup'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackDiff
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackDiff
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DatabaseBackup - DIFF', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=126, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20190829, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'e5492fd4-bcc6-4eb8-a6f7-c7648cde4e34'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackDiff
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackDiff
COMMIT TRANSACTION
GOTO EndSaveDiff
QuitWithRollbackDiff:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSaveDiff:


---------------------------------------------------------------------------------------------------
-- CREATE LOG BACKUP JOB 
---------------------------------------------------------------------------------------------------

USE [msdb]

/****** Object:  Job [DatabaseBackup - LOG]    Script Date: 8/29/2019 10:02:51 AM ******/
BEGIN TRANSACTION
--DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 8/29/2019 10:02:51 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackLog

END

--DECLARE @jobId BINARY(16)
SET @jobId = NULL

EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DatabaseBackup - LOG', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'See 10_BackupJobs.sql', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'flat', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackLog
/****** Object:  Step [DatabaseBackup - LOG]    Script Date: 8/29/2019 10:02:51 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DatabaseBackup - LOG', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=@CmdLog, 
		--@output_file_name=N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\LOG\DatabaseBackup_LOG_$(ESCAPE_SQUOTE(JOBID))_$(ESCAPE_SQUOTE(STEPID))_$(ESCAPE_SQUOTE(DATE))_$(ESCAPE_SQUOTE(TIME)).txt', 
		@flags=40, 
		@proxy_name=N'sqlbackup'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackLog
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackLog
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DatabaseBackup - LOG', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=15, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20190829, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'24f0402c-83d9-4e45-b0cd-a8bde0831a01'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackLog
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackLog
COMMIT TRANSACTION
GOTO EndSaveLog
QuitWithRollbackLog:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSaveLog:


---------------------------------------------------------------------------------------------------
-- CREATE S3 SYNC JOB 
---------------------------------------------------------------------------------------------------
-- Get the encryption key for this cluster.  
declare @EncryptionKey nvarchar(128)
set @EncryptionKey = 'alias/MSSQL-Backup-CMK'

print 'EncryptionKey: ' + @EncryptionKey

-- Build the OS commands.  
declare @CmdS3Sync1 nvarchar(max)
declare @CmdS3SyncPart1 nvarchar(max)
declare @CmdS3SyncPart2 nvarchar(max)

set @CmdS3SyncPart1 = N'$env:https_proxy =  '''' ' + CHAR(13) + CHAR(10)  
               + N'$erroractionpreference = ''Stop'' ' + CHAR(13) + CHAR(10)  
               + N'$error.Clear();' + CHAR(13) + CHAR(10)  
               + N'$path = ''' + @BackupRootPath + '''' + CHAR(13) + CHAR(10)   
               + N'$folders = @(''FULL'',''DIFF'',''LOG'',''Traces'') ' + CHAR(13) + CHAR(10)  
               + N'$folders | ForEach-Object{ ' + CHAR(13) + CHAR(10)  
               + N'	$folder1 = $_ ' + CHAR(13) + CHAR(10)  
               + N'	Get-ChildItem $path\$folder1 -Directory | ForEach-Object{ ' + CHAR(13) + CHAR(10)  
               + N'		$folder2 = $_.Name ' + CHAR(13) + CHAR(10)  
               + N'		try{ ' + CHAR(13) + CHAR(10)  
               + N'			aws s3 sync $path\$folder1\$folder2   s3://'  

set @CmdS3SyncPart2 = '/$folder1/$folder2 --no-progress --sse aws:kms  --sse-kms-key-id ' + @EncryptionKey + CHAR(13) + CHAR(10) 
               + N'		} ' + CHAR(13) + CHAR(10)  
               + N'		catch{}' + CHAR(13) + CHAR(10)  
               + N' 	}' + CHAR(13) + CHAR(10)  
               + N'} ' + CHAR(13) + CHAR(10)  
               + N'if($error.Count -gt 3){ ' + CHAR(13) + CHAR(10)   
               + N'	Write-Warning ''There were errors:$error '' ' + CHAR(13) + CHAR(10)  
               + N'	throw ''failure''; ' + CHAR(13) + CHAR(10)  
               + N'} '

set @CmdS3Sync1 = @CmdS3SyncPart1 + @S3BucketNameRoot + '01' + @CmdS3SyncPart2

print @CmdS3Sync1


-- Create the Job. 
USE [msdb]

/****** Object:  Job [DatabaseBackup - S3 Sync]    Script Date: 9/18/2019 5:50:35 AM ******/
BEGIN TRANSACTION
--DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 9/18/2019 5:50:35 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackS3Sync

END

--DECLARE @jobId BINARY(16)
SET @jobId = NULL

EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DatabaseBackup - S3 Sync', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'See 10_BackupJobs.sql', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'flat', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackS3Sync
/****** Object:  Step [DatabaseBackup - S3 Sync]    Script Date: 9/18/2019 5:50:35 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DatabaseBackup - S3 Sync - 1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=10, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=@CmdS3Sync1, 
		@flags=40, 
		@proxy_name=N'sqlbackup'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackS3Sync

-- EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DatabaseBackup - S3 Sync - 2', 
-- 		@step_id=2, 
-- 		@cmdexec_success_code=0, 
-- 		@on_success_action=3, 
-- 		@on_success_step_id=0, 
-- 		@on_fail_action=3, 
-- 		@on_fail_step_id=0, 
-- 		@retry_attempts=0, 
-- 		@retry_interval=0, 
-- 		@os_run_priority=0, @subsystem=N'CmdExec', 
-- 		@command=@CmdS3Sync2, 
-- 		@flags=40
-- IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackS3Sync

-- EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DatabaseBackup - S3 Sync - 3', 
-- 		@step_id=3, 
-- 		@cmdexec_success_code=0, 
-- 		@on_success_action=1, 
-- 		@on_success_step_id=0, 
-- 		@on_fail_action=2, 
-- 		@on_fail_step_id=0, 
-- 		@retry_attempts=0, 
-- 		@retry_interval=0, 
-- 		@os_run_priority=0, @subsystem=N'CmdExec', 
-- 		@command=@CmdS3Sync3, 
-- 		@flags=40
-- IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackS3Sync

EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackS3Sync

EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DatabaseBackup - S3 Sync', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=15, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20190917, 
		@active_end_date=99991231, 
		@active_start_time=100, 
		@active_end_time=235959,  
		@schedule_uid=N'10c068cc-1290-4105-a78b-aa73deab2614'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackS3Sync
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackS3Sync
COMMIT TRANSACTION
GOTO EndSaveS3Sync
QuitWithRollbackS3Sync:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSaveS3Sync:



---------------------------------------------------------------------------------------------------
-- CREATE CLEANUP JOB 
---------------------------------------------------------------------------------------------------
USE [msdb]

/****** Object:  Job [DatabaseBackup - CLEANUP]    Script Date: 8/29/2019 9:34:13 AM ******/
BEGIN TRANSACTION
--DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 8/29/2019 9:34:13 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackCleanup

END

--DECLARE @jobId BINARY(16)
SET @jobId = NULL


EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DatabaseBackup - CLEANUP', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'See 10_BackupsJobs.sql', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'flat', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackCleanup
/****** Object:  Step [DatabaseBackup - CLEANUP]    Script Date: 8/29/2019 9:34:13 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DatabaseBackup - CLEANUP', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, 
		@subsystem=N'PowerShell', 
		@command=@CmdCleanup, 
		@flags=40, 
		@proxy_name=N'sqlbackup'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackCleanup
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackCleanup
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DatabaseBackup - CLEANUP', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20230829, 
		@active_end_date=99991231, 
		@active_start_time=220000, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackCleanup
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollbackCleanup
COMMIT TRANSACTION
GOTO EndSaveCleanup
QuitWithRollbackCleanup:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSaveCleanup:


GO


---------------------------------------------------------------------------------------------------
-- END 
---------------------------------------------------------------------------------------------------
