-- 20_AddMsdbBackupTableIndexes.sql
-- 2024-02-28
-- 
-- Creates four indexes on msdb.dbo.backupset and one on msdb.dbo.backupmediafamily .  This is 
-- required to make operations on these tables even remotely performant. 

USE [msdb]
GO

-- Add index 1 to backupset. 
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name = 'IX_BACKUPSET_TYPE' AND object_id = object_id('backupset'))
BEGIN
	CREATE NONCLUSTERED INDEX [IX_BACKUPSET_TYPE] ON [dbo].[backupset] (
		[type]
	)
	INCLUDE (
		[backup_finish_date],
		[database_name]
	)
	WITH(ONLINE = OFF)
END
GO

-- Add index 2 to backupset. 
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name = 'IX_BACKUPSET_DATABASENAME' AND object_id = object_id('backupset'))
BEGIN
	CREATE NONCLUSTERED INDEX [IX_BACKUPSET_DATABASENAME] ON [dbo].[backupset] (
		[database_name],
		[type]
	)
	INCLUDE(
		[backup_finish_date]
	)
	WITH(ONLINE = OFF)
END
GO

-- Add index 3 to backupset. 
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name = 'IX_BACKUPSET_BACKUPFINISHDATE' AND object_id = object_id('backupset'))
BEGIN
	CREATE NONCLUSTERED INDEX [IX_BACKUPSET_BACKUPFINISHDATE] ON [dbo].[backupset] (
		[backup_finish_date]
	)
	INCLUDE (
		[media_set_id],
		[type],
		[database_name]
	)
	WITH(ONLINE = OFF)
END
GO

/* CSCI-7044 -> not used & causing deadlocks on backups
-- Add index 4 to backupset. 
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_BACKUPSET_MEDIA_SET_ID' AND object_id = object_id('backupset'))
BEGIN
    CREATE NONCLUSTERED INDEX [IX_BACKUPSET_MEDIA_SET_ID] ON [dbo].[backupset] ([media_set_id])
    WITH (ONLINE = OFF)
END
GO
*/

-- Add index 1 to backupmediafamily. 
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name = 'IX_BACKUPMEDIAFAMILY_MEDIASETID' AND object_id = object_id('backupmediafamily'))
BEGIN
	CREATE NONCLUSTERED INDEX [IX_BACKUPMEDIAFAMILY_MEDIASETID] ON backupmediafamily(
		media_set_id
	)
	INCLUDE(
		physical_device_name
	)
	WITH(ONLINE = OFF)
END
GO

/*
-- Display indexes. 
select name
  from sys.indexes
 where object_id = object_id('backupset')
 order by name
*/
