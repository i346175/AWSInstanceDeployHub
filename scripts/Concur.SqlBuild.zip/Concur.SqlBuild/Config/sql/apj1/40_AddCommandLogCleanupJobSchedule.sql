-- 40_AddCommandLogCleanupJobSchedule.sql 
-- 2024-02-28 - LAL 
-- 
-- The 'CommandLog Cleanup' Job that Ola's MaintenanceSolution.sql creates is great except that 
-- it uses 30 days as the age-out period.  To be able to interrogate the 'master.dbo.CommandLog' 
-- for as long as we need, we change the code to use 366 (leap year) + 7 (extra week to catch 
-- last Full backup) + 1 (paranoia) = 374 days. 
-- 
-- Also it doesn't have a job schedule, so out of the box, it never runs. 
-- Changed the retention from 374 to 7

use msdb

-- Update the Job Step command. 
exec dbo.sp_update_jobstep
    @job_name = N'CommandLog Cleanup',
    @step_id = 1,
    @command = 
N'DELETE FROM [dbo].[CommandLog]
WHERE StartTime < DATEADD(dd,-7,GETDATE())'

/* Original version. 
DELETE FROM [dbo].[CommandLog]
WHERE StartTime < DATEADD(dd,-30,GETDATE())
*/

-- Add if schedule doesn't already exist on this Job. 
if not exists (select * from msdb.dbo.sysschedules where name = 'CommandLog Cleanup')
begin
	exec msdb.dbo.sp_add_jobschedule @job_name=N'CommandLog Cleanup', 
	        @name=N'CommandLog Cleanup', 
			@enabled=1, 
			@freq_type=8, 
			@freq_interval=1, 
			@freq_subday_type=1, 
			@freq_subday_interval=0, 
			@freq_relative_interval=0, 
			@freq_recurrence_factor=1, 
			@active_start_date=20190829, 
			@active_end_date=99991231, 
			@active_start_time=0, 
			@active_end_time=235959
end
