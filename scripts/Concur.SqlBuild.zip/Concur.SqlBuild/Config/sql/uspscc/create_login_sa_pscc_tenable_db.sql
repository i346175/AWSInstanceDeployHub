USE [master]
GO

/****** Object:  Login [USPSCC\sa_pscc_tenable_db]    Script Date: 1/9/2023 2:11:21 PM ******/
IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'USPSCC\sa_pscc_tenable_db')
BEGIN
    CREATE LOGIN [USPSCC\sa_pscc_tenable_db] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]

        exec master.dbo.sp_addsrvrolemember @loginame='USPSCC\sa_pscc_tenable_db', @rolename='sysadmin'
END
GO
