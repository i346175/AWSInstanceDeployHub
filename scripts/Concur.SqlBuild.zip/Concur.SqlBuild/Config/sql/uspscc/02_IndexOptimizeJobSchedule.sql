USE [msdb]
GO
IF EXISTS (select 1 from msdb..sysjobs j where j.name = 'IndexOptimize - USER_DATABASES')
    IF NOT EXISTS (select 1 from msdb..sysschedules s join msdb..sysjobschedules js on js.schedule_id = s.schedule_id join msdb..sysjobs j on j.job_id = js.job_id where j.name = 'IndexOptimize - USER_DATABASES' and s.name  = 'Everyday 1AM')
    BEGIN
        DECLARE @schedule_id int
        EXEC msdb.dbo.sp_add_jobschedule @job_name = 'IndexOptimize - USER_DATABASES',
                @name=N'Everyday 1AM', 
                @enabled=1, 
                @freq_type=8, 
                @freq_interval=63, 
                @freq_subday_type=1, 
                @freq_subday_interval=0, 
                @freq_relative_interval=0, 
                @freq_recurrence_factor=1, 
                @active_start_date=20220602, 
                @active_end_date=99991231, 
                @active_start_time=10000, 
                @active_end_time=235959, @schedule_id = @schedule_id OUTPUT
    END
GO 