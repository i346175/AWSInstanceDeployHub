USE msdb;
GO
IF EXISTS (SELECT 1 FROM sys.objects WHERE name = 'Check_Backup_Age' AND type = 'FN')
	DROP FUNCTION Check_Backup_Age
GO
CREATE FUNCTION dbo.Check_Backup_Age( 
    @BackupType CHAR(20)
)
RETURNS int
AS   
BEGIN   
    DECLARE @ret as int; 
    DECLARE @ret1 as int;
    DECLARE @ret2 as int; 

    DECLARE @FullAge as int;
    DECLARE @DiffAge as int;
    DECLARE @LogAge as int;

    -- Must pass in right parameter for BackupType
    IF ( @BackupType not in ( 'full','diff','log' ) )
    BEGIN 
        SET @ret = 1;  
        RETURN @ret;
    END 
	
	-- Check whether it is a secondary node. Skip the alert check for the secondary node, since the backup is only on the cluster's primary
    SELECT @ret = count(*)
    FROM  sys.availability_groups_cluster AS AGC
    INNER JOIN sys.dm_hadr_availability_replica_cluster_states AS RCS
    ON   RCS.group_id = AGC.group_id
    INNER JOIN sys.dm_hadr_availability_replica_states AS ARS
    ON     ARS.replica_id = RCS.replica_id
    INNER JOIN sys.availability_group_listeners AS AGL
    ON     AGL.group_id = ARS.group_id
    WHERE  ARS.role_desc = 'SECONDARY'
    AND RCS.replica_server_name = @@SERVERNAME
    ;

    IF ( @ret > 0 )  
    BEGIN 
        SET @ret = 0;  
        RETURN @ret;
    END 

    -- For full backup, alert if the most recent one is over one week, 180 = 7*24 + 12 hours - full backups can take over a day to complete
    SET @FullAge = 180;

    -- For diff backup, alert if the most recent one is over one day 26 = 24 + 12 hours - full backups can take over a day to complete
    SET @DiffAge = 26;

    -- For log backup, alert if the most recent one is over 270=(4 * 60) + 30  minutes - allow for slop over into next quarter-hour (15 mins wasn't enough)
	SET @LogAge = 270;


    --full backups older than @FullAge hours
    IF ( @BackupType = 'full' )
    BEGIN

    -- Get list of backup types and databases; allow 4 hours for new databases to get backed up.
    ; With BackupGroup AS(
    SELECT 
    MAX(ISNULL(b.backup_set_id,0))       AS SetID,
    CASE WHEN b.[Type] = 'D' THEN 'FULL'
    WHEN b.[type] = 'L' THEN 'LOG'
    WHEN b.[type] = 'I' THEN 'DIFF'
    END                                  AS BackupType,
    d.name                               AS DatabaseName,
    d.create_date                        AS CreateDate
    FROM master.sys.databases d
    LEFT JOIN msdb.dbo.backupset b ON b.database_name = d.name
    AND b.server_name = @@SERVERNAME
    AND DATEDIFF(Hour, d.create_date, GETDATE()) > 4 
    WHERE 1=1
    AND d.state_desc = 'ONLINE'
    AND d.user_access_desc = 'MULTI_USER'
    AND d.source_database_id IS NULL
    AND d.name NOT IN('ssrstempdb', 'tempdb')
    GROUP BY b.[type], d.name, d.create_date
    UNION
    -- Add empty row if db has never had a Diff backup; else we can't detect that. 
    SELECT NULL            AS SetID,
    'DIFF'          AS BackupType,
    d.Name          AS DatabaseName,
    d.create_date   AS CreateDate
    FROM master.sys.databases   d
    WHERE NOT EXISTS (SELECT * FROM msdb.dbo.backupset b 
            WHERE b.database_name = d.name
                AND b.server_name = @@SERVERNAME
                AND DATEDIFF(Hour, d.create_date, GETDATE()) > 4
                AND b.type = 'I')
    AND d.state_desc = 'ONLINE'
    AND d.user_access_desc = 'MULTI_USER'
    AND d.source_database_id IS NULL
    AND d.name NOT IN('ssrstempdb', 'tempdb')
    )
    , BackupFull AS (
    SELECT g.DatabaseName,
    ISNULL(MAX(backup_finish_date), '1999-12-31 00:00:00')   AS LatestFullBackupDate
    FROM BackupGroup   g
    LEFT JOIN msdb.dbo.backupset   b 
    ON g.SetID = b.backup_set_id AND g.BackupType = 'FULL' 
    GROUP BY g.DatabaseName
    )
    SELECT @ret1 = count(*)
    FROM msdb.dbo.backupset b 
    INNER JOIN BackupGroup g ON b.backup_set_id = g.SetID
    WHERE 1=1
    AND b.server_name = @@SERVERNAME
    AND g.BackupType = 'FULL'
    AND DATEDIFF(HOUR, b.backup_finish_date, GETDATE()) > @FullAge
    ;

    SELECT @ret2 = count(*)
    FROM master.sys.databases d
    WHERE 1=1
    AND d.name != 'tempdb'
    AND d.state_desc = 'ONLINE'
    AND d.user_access_desc = 'MULTI_USER'
    AND d.source_database_id IS NULL
    AND d.create_date < DATEADD(DAY, -1, GETDATE())
    AND d.name NOT IN(
        SELECT DISTINCT database_name 
        FROM msdb.dbo.backupset
        WHERE server_name = @@SERVERNAME
    );

    SET @ret = @ret1 + @ret2;

   END
    
    --diff backups older than  @diffAge hours (that were created more than @diffAge hours ago too)
    IF ( @BackupType = 'diff' )
    BEGIN
        -- Get list of backup types and databases; allow 4 hours for new databases to get backed up.
    ; With BackupGroup AS(
    SELECT 
    MAX(ISNULL(b.backup_set_id,0))       AS SetID,
    CASE WHEN b.[Type] = 'D' THEN 'FULL'
    WHEN b.[type] = 'L' THEN 'LOG'
    WHEN b.[type] = 'I' THEN 'DIFF'
    END                                  AS BackupType,
    d.name                               AS DatabaseName,
    d.create_date                        AS CreateDate
    FROM master.sys.databases d
    LEFT JOIN msdb.dbo.backupset b ON b.database_name = d.name
    AND b.server_name = @@SERVERNAME
    AND DATEDIFF(Hour, d.create_date, GETDATE()) > 4 
    WHERE 1=1
    AND d.state_desc = 'ONLINE'
    AND d.user_access_desc = 'MULTI_USER'
    AND d.source_database_id IS NULL
    AND d.name NOT IN('ssrstempdb', 'tempdb')
    GROUP BY b.[type], d.name, d.create_date
    UNION
    -- Add empty row if db has never had a Diff backup; else we can't detect that. 
    SELECT NULL            AS SetID,
    'DIFF'          AS BackupType,
    d.Name          AS DatabaseName,
    d.create_date   AS CreateDate
    FROM master.sys.databases   d
    WHERE NOT EXISTS (SELECT * FROM msdb.dbo.backupset b 
            WHERE b.database_name = d.name
                AND b.server_name = @@SERVERNAME
                AND DATEDIFF(Hour, d.create_date, GETDATE()) > 4
                AND b.type = 'I')
    AND d.state_desc = 'ONLINE'
    AND d.user_access_desc = 'MULTI_USER'
    AND d.source_database_id IS NULL
    AND d.name NOT IN('ssrstempdb', 'tempdb')
    )
    , BackupFull AS (
    SELECT g.DatabaseName,
    ISNULL(MAX(backup_finish_date), '1999-12-31 00:00:00')   AS LatestFullBackupDate
    FROM BackupGroup   g
    LEFT JOIN msdb.dbo.backupset   b 
    ON g.SetID = b.backup_set_id AND g.BackupType = 'FULL' 
    GROUP BY g.DatabaseName
    )    

    SELECT @ret = count(*)
    FROM msdb.dbo.backupset b 
    INNER JOIN BackupFull bf ON b.database_name = bf.DatabaseName
    RIGHT JOIN BackupGroup g ON b.backup_set_id = g.SetID
    WHERE 1=1
    AND g.BackupType = 'DIFF'
    AND g.DatabaseName != 'master'
    AND DATEDIFF(HOUR, ISNULL(b.backup_finish_date, '1999-12-31 00:00:00'), GETDATE()) > @diffAge
    AND DATEDIFF(Hour, g.CreateDate, GETDATE()) > @diffAge
    --AND DATEDIFF(Hour, '@LatestFailoverString', GETDATE()) > @diffAge
    AND DATEDIFF(Hour, bf.LatestFullBackupDate, GETDATE()) > @diffAge
    ;

    END

    IF ( @BackupType = 'log' )
    BEGIN
        -- Get list of backup types and databases; allow 4 hours for new databases to get backed up.
    ; With BackupGroup AS(
    SELECT 
    MAX(ISNULL(b.backup_set_id,0))       AS SetID,
    CASE WHEN b.[Type] = 'D' THEN 'FULL'
    WHEN b.[type] = 'L' THEN 'LOG'
    WHEN b.[type] = 'I' THEN 'DIFF'
    END                                  AS BackupType,
    d.name                               AS DatabaseName,
    d.create_date                        AS CreateDate
    FROM master.sys.databases d
    LEFT JOIN msdb.dbo.backupset b ON b.database_name = d.name
    AND b.server_name = @@SERVERNAME
    AND DATEDIFF(Hour, d.create_date, GETDATE()) > 4 
    WHERE 1=1
    AND d.state_desc = 'ONLINE'
    AND d.user_access_desc = 'MULTI_USER'
    AND d.source_database_id IS NULL
    AND d.name NOT IN('ssrstempdb', 'tempdb')
    GROUP BY b.[type], d.name, d.create_date
    UNION
    -- Add empty row if db has never had a Diff backup; else we can't detect that. 
    SELECT NULL            AS SetID,
    'DIFF'          AS BackupType,
    d.Name          AS DatabaseName,
    d.create_date   AS CreateDate
    FROM master.sys.databases   d
    WHERE NOT EXISTS (SELECT * FROM msdb.dbo.backupset b 
            WHERE b.database_name = d.name
                AND b.server_name = @@SERVERNAME
                AND DATEDIFF(Hour, d.create_date, GETDATE()) > 4
                AND b.type = 'I')
    AND d.state_desc = 'ONLINE'
    AND d.user_access_desc = 'MULTI_USER'
    AND d.source_database_id IS NULL
    AND d.name NOT IN('ssrstempdb', 'tempdb')
    )
    , BackupFull AS (
    SELECT g.DatabaseName,
    ISNULL(MAX(backup_finish_date), '1999-12-31 00:00:00')   AS LatestFullBackupDate
    FROM BackupGroup   g
    LEFT JOIN msdb.dbo.backupset   b 
    ON g.SetID = b.backup_set_id AND g.BackupType = 'FULL' 
    GROUP BY g.DatabaseName
    )
    --Check for log files that have not had a log backup in 4 hours
    SELECT @ret1 = count(*)
    FROM msdb.dbo.backupset b 
    INNER JOIN master.sys.databases d ON b.database_name = d.name
    INNER JOIN BackupGroup g ON b.backup_set_id = g.SetID
    WHERE 1=1
    AND b.server_name = @@SERVERNAME
    AND d.recovery_model_desc IN('FULL', 'BULK_LOGGED')
    AND g.BackupType = 'LOG'
    AND DATEDIFF(MINUTE, b.backup_finish_date, GETDATE()) > @LogAge
    ;

    
    --check for databases in full recovery with no log backup, regardless of size
    SELECT @ret2 = count(*)
    FROM master.sys.databases d
    WHERE d.name NOT IN(
        SELECT DISTINCT database_name 
        FROM msdb.dbo.backupset
        WHERE [type] = 'L'
        AND server_name = @@SERVERNAME
    )
    AND d.name NOT IN('ssrstempdb', 'tempdb')
    AND d.recovery_model_desc IN('FULL','BULK_LOGGED')
    AND d.state_desc = 'ONLINE'
    AND d.user_access_desc = 'MULTI_USER'
    AND DATEDIFF(Hour, d.create_date, GETDATE()) > 4
    ;

    SET @ret = @ret1 + @ret2;

END

IF (@ret IS NULL)   
    SET @ret = 0;  
    
RETURN @ret; 

END; 

