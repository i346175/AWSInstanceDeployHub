-- 30_UpdateBackupHistoryTableRetention.sql 
-- 2019-08-29 - LAL
-- 2020-04-06 - LAL - Added schedule, changed to 91 days to keep its size from causing blocking with
--                    the daily status report and causing a page.  Don't know how long we need to 
--                    keep 'backupset' data for PSCC anyway.
-- 
-- The 'sp_delete_backuphistory' Job that Ola's MaintenanceSolution.sql creates is great except that 
-- it uses 30 days as the age-out period.  To be able to interrogate the 'msdb.dbo.backupset' 
-- for as long as we need, we change the code to use 366 (leap year) + 7 (extra week to catch 
-- last Full backup) + 1 (paranoia) = 374 days.  Note that the custom indexes we added to this 
-- table in '20_AddMsdbBackupTableIndexes.sql' makes keeping this much data possible.
-- 
-- Also it doesn't have a job schedule, so out of the box, it never runs. 

use msdb

exec dbo.sp_update_jobstep
    @job_name = N'sp_delete_backuphistory',
    @step_id = 1,
    @command = 
N'DECLARE @CleanupDate DATETIME
SET @CleanupDate = DATEADD(dd, -8, GETDATE())
EXECUTE dbo.sp_delete_backuphistory @oldest_date = @CleanupDate'

/* Original version. 
DECLARE @CleanupDate datetime
SET @CleanupDate = DATEADD(dd,-30,GETDATE())
EXECUTE dbo.sp_delete_backuphistory @oldest_date = @CleanupDate
*/

-- Add if schedule doesn't already exist on this Job. 
if not exists (select * from msdb.dbo.sysschedules where name = 'sp_delete_backuphistory')
begin
	exec msdb.dbo.sp_add_jobschedule @job_name=N'sp_delete_backuphistory', 
	        @name=N'sp_delete_backuphistory', 
			@enabled=1, 
			@freq_type=8, 
			@freq_interval=1, 
			@freq_subday_type=1, 
			@freq_subday_interval=0, 
			@freq_relative_interval=0, 
			@freq_recurrence_factor=1, 
			@active_start_date=20200405, 
			@active_end_date=99991231, 
			@active_start_time=0, 
			@active_end_time=235959
end
