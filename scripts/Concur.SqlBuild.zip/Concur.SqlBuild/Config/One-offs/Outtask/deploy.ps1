. C:\vault\Get-VaultPassword.ps1
. C:\vault\Get-VaultToken.ps1
. C:\cfn\temp\CFN_Variables.ps1

$cthostserver = $($config.cthostserver).split('.')[0]
$sqlport = $config.port
$envt = $config.jurisdiction

$logfile = "C:\mssql-scripts\ConcurSqlBuild\concursqlbuild.log"

#transform $env:microservice to variable start with capital letter and store to variable $microservice
$microservice = $env:microservice.substring(0,1).ToUpper() + $env:microservice.substring(1)
$scriptPath = "C:\Program Files\WindowsPowerShell\Modules\Concur.SqlBuild\Config\One-offs\$microservice"

try{
    Start-Transcript -Path $logfile -Append
    Write-Output ">>>> $($env:microservice.Tostring().ToUpper()) | $($env:COMPUTERNAME.Tostring().ToUpper()) - One-Off Configurations - STARTED <<<<<"
    
    ## CREATING LINKED SERVER TO CTHOST
    Write-Output "`t`tCreating Linked Server to CTHOST..."
    $sqlText = $(Get-Content "$scriptPath\create_LinkedServer.sql")
    $sqlText = $sqlText.Replace("<LinkedServerName>","$cthostserver").Replace("<SQLPort>","$sqlport")
    Invoke-Sqlcmd -Database master -Query "$sqlText" -ErrorAction Stop -TrustServerCertificate
    If($envt -in ('us2','eu2','apj1')){
        Invoke-Sqlcmd -Database master -InputFile "$scriptPath\create_Logins-$envt.sql" -ErrorAction Stop -TrustServerCertificate
    }

    Write-Output ">>>> $($env:microservice.Tostring().ToUpper()) | $($env:COMPUTERNAME.Tostring().ToUpper()) - One-Off Configurations - COMPLETED <<<<<"
}
catch{
    throw $_
}
finally {
    Stop-Transcript
}