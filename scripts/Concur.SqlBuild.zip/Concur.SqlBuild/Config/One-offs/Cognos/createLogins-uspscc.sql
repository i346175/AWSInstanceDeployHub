USE master;
GO
/* sp_help_revlogin script 
** Generated Feb  1 2023 11:15AM on EC2AMAZ-ALG7GN9 */
 
 
-- Login: archive_user
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'archive_user')
                BEGIN
CREATE LOGIN [archive_user] WITH PASSWORD = 0x02000063CAFD42534E2428E6FC3C96B9A1819DFC5407DE46030DA44E21AD94AE93CC5A37A6F172396DCD544ACFDFD1ADCBBB23FE713B6C9E7377C505519A43173D6082150520 HASHED, SID = 0x4EC9E71AF3A13C45A0AB0A825BDAFEC2, DEFAULT_DATABASE = [master], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF

        exec master.dbo.sp_addsrvrolemember @loginame='archive_user', @rolename='dbcreator'
END
 
-- Login: cognosdb
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'cognosdb')
                BEGIN
CREATE LOGIN [cognosdb] WITH PASSWORD = 0x02009C3074B6D37B227BD7C82D234205DADED3A166368ED439AA647E27D1686069D1D71E7603D68D84EA7D9BB53619E13AFA999C55776AFE5E8C7F0B89A5DD3530F1FBAD96F1 HASHED, SID = 0x4D6A82EBA5BF63499573104B1B31ED4C, DEFAULT_DATABASE = [master], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF
 
END
 
-- Login: cognosdbadmin
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'cognosdbadmin')
                BEGIN
CREATE LOGIN [cognosdbadmin] WITH PASSWORD = 0x02000C98683E149260BE76BFB9BA16035750C57238C90CC2F398F4E3B99445853D28F5B816147472407C1275F3F11B75A474640E632B533291505DCACB82A02FDEBD79553C41 HASHED, SID = 0xB05F48AFBA97D7479D379C04C6ACC2C7, DEFAULT_DATABASE = [master], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF

        exec master.dbo.sp_addsrvrolemember @loginame='cognosdbadmin', @rolename='sysadmin'
END
 
-- Login: concur_rptdbsvc_acc1
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'concur_rptdbsvc_acc1')
                BEGIN
CREATE LOGIN [concur_rptdbsvc_acc1] WITH PASSWORD = 0x0200390E9BCB61738C817C8A825A457D0D08454D8E64EEDE478FA55C6775C5F7C12719C97A49C380292DFCC629EA2280A4CBEE2C0A033784AD9424E4CC1D7A1C307BE3960BE2 HASHED, SID = 0xDEECD1C3307917438EAAF812E3AAE364, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF

        exec master.dbo.sp_addsrvrolemember @loginame='concur_rptdbsvc_acc1', @rolename='sysadmin'
END
 
-- Login: reportingshared_admin
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'reportingshared_admin')
                BEGIN
CREATE LOGIN [reportingshared_admin] WITH PASSWORD = 0x0200AF1F76545ADE23015D926059F95B0B5422725AAE90846234A8F323BCFE6B26772955C6E18AD8FC2FC2954B58755312A36BE942754683D5F0CDDF14C53D49B5611A4A8B79 HASHED, SID = 0xEAF1A75E4481224694A6A08E5821CBBF, DEFAULT_DATABASE = [master], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF

        exec master.dbo.sp_addsrvrolemember @loginame='reportingshared_admin', @rolename='sysadmin'
END
 
-- Login: reportingshared_user
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'reportingshared_user')
                BEGIN
CREATE LOGIN [reportingshared_user] WITH PASSWORD = 0x0200A205CA8BE0275CDC3C547C53E017983061B8A948433EF69F0ED685E95CCA8503635AE19EA38F64EDEA06DEC96D2AE5E974284BD429FB3A6DFC7FBB4B13DB487CA6AAAE27 HASHED, SID = 0xFDB5813625EA4943914FA5FB64953AFB, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF
 
END
 
-- Login: uspscc\Database Admins
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'uspscc\Database Admins')
                BEGIN
CREATE LOGIN [uspscc\Database Admins] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='uspscc\Database Admins', @rolename='sysadmin'
END
 
-- Login: USPSCC\dbsql_admins
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'USPSCC\dbsql_admins')
                BEGIN
CREATE LOGIN [USPSCC\dbsql_admins] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='USPSCC\dbsql_admins', @rolename='sysadmin'
END
 
-- Login: USPSCC\I847250-a
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'USPSCC\I847250-a')
                BEGIN
CREATE LOGIN [USPSCC\I847250-a] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='USPSCC\I847250-a', @rolename='sysadmin'
END
 
-- Login: USPSCC\I847262-a
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'USPSCC\I847262-a')
                BEGIN
CREATE LOGIN [USPSCC\I847262-a] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='USPSCC\I847262-a', @rolename='sysadmin'
END
 
-- Login: USPSCC\sa_dba_prov
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'USPSCC\sa_dba_prov')
                BEGIN
CREATE LOGIN [USPSCC\sa_dba_prov] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='USPSCC\sa_dba_prov', @rolename='sysadmin'
END
 
-- Login: USPSCC\sa_gypsy
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'USPSCC\sa_gypsy')
                BEGIN
CREATE LOGIN [USPSCC\sa_gypsy] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='USPSCC\sa_gypsy', @rolename='sysadmin'
END
 
-- Login: uspscc\sa_pnsqluser
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'uspscc\sa_pnsqluser')
                BEGIN
CREATE LOGIN [uspscc\sa_pnsqluser] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='uspscc\sa_pnsqluser', @rolename='sysadmin'
END
 
-- Login: USPSCC\sa_pscc_tenable_db
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'USPSCC\sa_pscc_tenable_db')
                BEGIN
CREATE LOGIN [USPSCC\sa_pscc_tenable_db] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='USPSCC\sa_pscc_tenable_db', @rolename='sysadmin'
 
END
 
-- Login: USPSCC\sa_solarwinds
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'USPSCC\sa_solarwinds')
                BEGIN
CREATE LOGIN [USPSCC\sa_solarwinds] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='USPSCC\sa_solarwinds', @rolename='sysadmin'
END
 
-- Login: ussea7xadmin
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'ussea7xadmin')
                BEGIN
CREATE LOGIN [ussea7xadmin] WITH PASSWORD = 0x0200E0B7479490540D6CB53C97B57F7E27F17AEC1F6D19EEF34130A3B8EBC3C603D05E2885FC1E6D7C7DE1889207F05A62304327D8EFC366C210422A8F8D1EC48F2B63B30EDB HASHED, SID = 0xD62CBE57F3E0604584F11D63EDF8B53E, DEFAULT_DATABASE = [master], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF

        exec master.dbo.sp_addsrvrolemember @loginame='ussea7xadmin', @rolename='sysadmin'
END
 
-- Login: ussea7xRpt
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'ussea7xRpt')
                BEGIN
CREATE LOGIN [ussea7xRpt] WITH PASSWORD = 0x020000E10B3DE113E0241FDA4F75375C365C4BF06FAB1BF7E59CBFD44C6B24C1440551DE8DA70599BF3BDD8AFF4282C4CFB795DDF2738FEBEBB27D4C7226771C232751465CEE HASHED, SID = 0x58F31801696FF747B9AE5EDB39AA02EC, DEFAULT_DATABASE = [master], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF
 
END
 
-- Login: ussea7xRptAdmin
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'ussea7xRptAdmin')
                BEGIN
CREATE LOGIN [ussea7xRptAdmin] WITH PASSWORD = 0x02003D3EF113643BDE2009D3D3B88B6C782655067948892EAC291DA7790ED10D1EEE463BBDAEDCB4C9B18413691BF03B5FF65E7E5B1633E9CD0C61787CE55A16718F1716BAC2 HASHED, SID = 0xF5AFC2F1D2CB194D8608BDD45DCE4F7E, DEFAULT_DATABASE = [master], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF

        exec master.dbo.sp_addsrvrolemember @loginame='ussea7xRptAdmin', @rolename='sysadmin'
END

