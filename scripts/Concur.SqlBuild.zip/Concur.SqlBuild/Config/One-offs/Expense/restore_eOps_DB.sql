IF NOT EXISTS (SELECT TOP 1 1 FROM sys.databases WHERE [name] = 'eOperationsDBA')
    RESTORE DATABASE [eOperationsDBA] FROM DISK = 'C:\mssql-scripts\eOperationsDBA.bak'
    WITH MOVE 'eOperationsDBA_Data' TO 'E:\MSSQL\DATA\eOperationsDBA.mdf',
         MOVE 'eOperationsDBA_Log' TO 'G:\MSSQL\TRANLOG\eOperationsDBA_1.ldf';
ALTER DATABASE [eOperationsDBA] SET RECOVERY SIMPLE;
ALTER DATABASE [eOperationsDBA] SET COMPATIBILITY_LEVEL = 150;