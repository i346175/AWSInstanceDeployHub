USE master;
GO
EXEC sp_configure 'show advanced options', 1;
GO
RECONFIGURE
GO
EXEC sp_configure 'clr_enabled', 1;
GO
RECONFIGURE WITH OVERRIDE; 
GO
EXEC sp_configure 'remote access', 1 ;  
GO  
RECONFIGURE WITH OVERRIDE;
GO
EXEC sp_configure 'cost threshold for parallelism', 200 ;
GO
RECONFIGURE WITH OVERRIDE; 
GO
EXEC sp_configure 'show advanced options', 0;
GO
RECONFIGURE
GO