USE master;
GO
/* sp_help_revlogin script 
** Generated Feb  1 2023 10:48AM on EC2AMAZ-48JLVHR */
 
 
-- Login: candata_user
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'candata_user')
                BEGIN
CREATE LOGIN [candata_user] WITH PASSWORD = 0x02008310232EEECCD6427BBC301285DDC86DE8EA663381A12EF6CDD6E1A3AEF9A88C0A66EA905E3B08D732EC05CC6302885106332F751B9CC1CAE5F52DDEBF9B5B5EE061F95D HASHED, SID = 0x10C42290BC31E44CA4BE9626A6EB6BC7, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF

        exec master.dbo.sp_addsrvrolemember @loginame='candata_user', @rolename='sysadmin'
        exec master.dbo.sp_addsrvrolemember @loginame='candata_user', @rolename='dbcreator'
END
 
-- Login: concuradmin
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'concuradmin')
                BEGIN
CREATE LOGIN [concuradmin] WITH PASSWORD = 0x020028DEEC2BDD6C191D12A5F98DA2BC760B2065ED25FB907E0BCF6E1DE64FF2228C8C09A68B5A088507EE314EB178F36C74DDD6AF71F69662D24F5FD2FEEBB55C411B933CAD HASHED, SID = 0xA1FE42290E853C4C9B437E17EDE26201, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF

        exec master.dbo.sp_addsrvrolemember @loginame='concuradmin', @rolename='sysadmin'
END
 
-- Login: concurrptadmin
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'concurrptadmin')
                BEGIN
CREATE LOGIN [concurrptadmin] WITH PASSWORD = 0x02007B974FE75481A0FCA1A10F460E3D35C7ED312E3D5DDB344CA960269F7AE8DBAFAE7FC67BF0BE36BD2119A2B23D01A02B5F9D1ED81B44526FB9B1A14836F13662A4FD85EC HASHED, SID = 0xF39FBAE9076EF8488FA2E82A8E655B7C, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF

        exec master.dbo.sp_addsrvrolemember @loginame='concurrptadmin', @rolename='sysadmin'
END
 
-- Login: concurrptuser
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'concurrptuser')
                BEGIN
CREATE LOGIN [concurrptuser] WITH PASSWORD = 0x0200E1363D5DD6BD0EB9B787A482D2277D73D0A0F542FFA9BC7954DF82E2C9FA1AD4C6E03E2329178D6A67EDA23FA29FC536D292F778098E3D80EA9AA9BE6C467DF6CC916F76 HASHED, SID = 0xFC5F8BC202FEE84CB65D480BF46829CC, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF
 
END
 
-- Login: concuruser
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'concuruser')
                BEGIN
CREATE LOGIN [concuruser] WITH PASSWORD = 0x0200A0E2714C342C5D05C952104B38BFE45E3FC746634D1C7DA02568CCE989B7E400918EEB64975AE1876B042213FEF1A256BEFA08904F5A736BC5B0838C8B28A001CD160399 HASHED, SID = 0xCE18430BA52D9A4E81F9A9F13F2E08DC, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF
 
END
 
-- Login: dp-integration
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'dp-integration')
                BEGIN
CREATE LOGIN [dp-integration] WITH PASSWORD = 0x02008D0E13B7BC73922139CC0A70198385A66752D22F8F299F2A887E54C4E37D16F3CBE89A9BEAE5C311A881B5EAD83ECC0DE0DB2356240250DDEAE19DA88A9BDF5C3BE0C19B HASHED, SID = 0x41F8DAC032F92A499582B993FFD25A80, DEFAULT_DATABASE = [master], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF
 
END
 
-- Login: INTEGRATION\CES_Readonly_PROD
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'INTEGRATION\CES_Readonly_PROD')
                BEGIN
CREATE LOGIN [INTEGRATION\CES_Readonly_PROD] FROM WINDOWS WITH DEFAULT_DATABASE = [master]
 
END
 
-- Login: integration\Database Admins
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'integration\Database Admins')
                BEGIN
CREATE LOGIN [integration\Database Admins] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='integration\Database Admins', @rolename='sysadmin'
END
 
-- Login: integration\dbsql_admins
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'integration\dbsql_admins')
                BEGIN
CREATE LOGIN [integration\dbsql_admins] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='integration\dbsql_admins', @rolename='sysadmin'
END
 
-- Login: INTEGRATION\I847250-a
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'INTEGRATION\I847250-a')
                BEGIN
CREATE LOGIN [INTEGRATION\I847250-a] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='INTEGRATION\I847250-a', @rolename='sysadmin'
END
 
-- Login: integration\neilv
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'integration\neilv')
                BEGIN
CREATE LOGIN [integration\neilv] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='integration\neilv', @rolename='sysadmin'
END
 
-- Login: INTEGRATION\sa_aska
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'INTEGRATION\sa_aska')
                BEGIN
CREATE LOGIN [INTEGRATION\sa_aska] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='INTEGRATION\sa_aska', @rolename='sysadmin'
        exec master.dbo.sp_addsrvrolemember @loginame='INTEGRATION\sa_aska', @rolename='securityadmin'
        exec master.dbo.sp_addsrvrolemember @loginame='INTEGRATION\sa_aska', @rolename='dbcreator'
END
 
-- Login: integration\sa_dba_prov
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'integration\sa_dba_prov')
                BEGIN
CREATE LOGIN [integration\sa_dba_prov] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='integration\sa_dba_prov', @rolename='sysadmin'
END
 
-- Login: INTEGRATION\sa_gypsy
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'INTEGRATION\sa_gypsy')
                BEGIN
CREATE LOGIN [INTEGRATION\sa_gypsy] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='INTEGRATION\sa_gypsy', @rolename='sysadmin'
        exec master.dbo.sp_addsrvrolemember @loginame='INTEGRATION\sa_gypsy', @rolename='dbcreator'
END
 
-- Login: integration\sa_pnsqluser
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'integration\sa_pnsqluser')
                BEGIN
CREATE LOGIN [integration\sa_pnsqluser] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='integration\sa_pnsqluser', @rolename='sysadmin'
END
 
-- Login: INTEGRATION\sa_sdbms
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'INTEGRATION\sa_sdbms')
                BEGIN
CREATE LOGIN [INTEGRATION\sa_sdbms] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='INTEGRATION\sa_sdbms', @rolename='dbcreator'
END
 
-- Login: sa_cq
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'sa_cq')
                BEGIN
CREATE LOGIN [sa_cq] WITH PASSWORD = 0x02009741570DBD959353EE326D29BFBEEC8E98F5E33062FFBA5CEDA0DDD2A7F3DBD5688A41B1BE4BD12FF87E3B7D757C38B20A5B1D2A1F0A63096A534DB61A9D2165351C4CCD HASHED, SID = 0xB468F3A7AB5ABF4FAE555B71B534E532, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF
 
END
 
-- Login: sa_expense_spend_mile
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'sa_expense_spend_mile')
                BEGIN
CREATE LOGIN [sa_expense_spend_mile] WITH PASSWORD = 0x0200F281039D688878109BD7CDD67D8AD6CF06211E903391348699DEFDED973431A4573F80D65E143BD07D3E81EA59A937765835F06FA66BB2080077279E2EAF75B72FD582F9 HASHED, SID = 0x7BED19BE4C1CCB4A91822783AF44343B, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF
 
END
 
-- Login: sa_redgreen
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'sa_redgreen')
                BEGIN
CREATE LOGIN [sa_redgreen] WITH PASSWORD = 0x0200E990FF5AF2E5A9C02B7519515875E9901D5A2FEF5DC031802B6AA13CCE5B5B6DAAE81BCE59041E994FA243855C7A5A08D3522AFA7D6098E128B88F91912ED135A09393C7 HASHED, SID = 0x972B5BFC7653C24A9207081AC90FC29F, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF

        exec master.dbo.sp_addsrvrolemember @loginame='sa_redgreen', @rolename='sysadmin'
END
 
-- Login: sa_sdbms
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'sa_sdbms')
                BEGIN
CREATE LOGIN [sa_sdbms] WITH PASSWORD = 0x0200EA5AB1DD6367104294BA7012AC9A1F6B3BD82C3442E71A43912FA926CF862812FF8EA6FC1DEEE92DA83B0A83F54FCB003F53CED2013F379352DE90CEE59BD3D4AF29356D HASHED, SID = 0x162E94CC5CA44276A8A0F219EE8E475B, DEFAULT_DATABASE = [master], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF

        exec master.dbo.sp_addsrvrolemember @loginame='sa_sdbms', @rolename='sysadmin'
        exec master.dbo.sp_addsrvrolemember @loginame='sa_sdbms', @rolename='dbcreator'
END
 
-- Login: sa_sdbms_test
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'sa_sdbms_test')
                BEGIN
CREATE LOGIN [sa_sdbms_test] WITH PASSWORD = 0x02007587E577AC2C197F61F073761271A9AEF66E85D63A519A266915706B84FB277AEDB2A46EB2FC4FEB99943642FDAF72AAE5A61D6C544912D44F4C1703E4216F0B7C195051 HASHED, SID = 0xD3F75F04DB5A454F819F835E887F78CD, DEFAULT_DATABASE = [master], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF

        exec master.dbo.sp_addsrvrolemember @loginame='sa_sdbms_test', @rolename='dbcreator'
END
 
-- Login: sdbms_dcp
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'sdbms_dcp')
                BEGIN
CREATE LOGIN [sdbms_dcp] WITH PASSWORD = 0x0200D439F99B01242840CFA7F107FFD12FB4EA1CC0ED249E74414743EEDD6CF81FD5DA877B7CFBECE552ECA21A8DF767840E61D1044A39CB5EE4D1B775DB53479364C1441BAD HASHED, SID = 0xE6E3A972FD2B344DB244671F9CE536D5, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF

        exec master.dbo.sp_addsrvrolemember @loginame='sdbms_dcp', @rolename='sysadmin'
END
 
-- Login: ussea7xRpt
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'ussea7xRpt')
                BEGIN
CREATE LOGIN [ussea7xRpt] WITH PASSWORD = 0x0200409F31CBA5DFEFDFEDCADDCEF1C7513277FDCA5A09E26523127460A768E501C61D6D7E4873F91B1FC42610C5C074E5224D58883676E46499B23250AABC227735FC93A5AB HASHED, SID = 0x44114983038C8846A1223D9D60B4034A, DEFAULT_DATABASE = [master], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF
 
END
 
-- Login: ussea7xRptAdmin
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'ussea7xRptAdmin')
                BEGIN
CREATE LOGIN [ussea7xRptAdmin] WITH PASSWORD = 0x02008E44C84B5CE130D3593833AA4CED65B038473E5D1E990ABE9B3C132FE22631B56FBDBD6A9BA830E03A69777FE95FC7583A37D2DFF2485DB3C105CD73D501FED20B048A22 HASHED, SID = 0x8D534F033FBCB14384AE67F451B83741, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF

        exec master.dbo.sp_addsrvrolemember @loginame='ussea7xRptAdmin', @rolename='sysadmin'
END

------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- intext_spend_acc1 -> OPI-5853266 for reporting (should have only cesrole in spend dbs...)
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'intext_spend_acc1')
BEGIN
   CREATE LOGIN [intext_spend_acc1] WITH PASSWORD = 0x0200B547C5196003AE622A6CE7D92A5D902B41AC4156F72AAFE617D129ADFCE7E30FB546CC4185604829A1FD914C0B355BA928DEBC3A235E55C3121232BE6B1FBF5736DA9830 HASHED, SID = 0x506CE48132875B46A5D489FB3D7E4878, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF
END
GO


------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- intext_spend_acc2 -> OPI-5853266 for reporting (should have only cesrole in spend dbs...)
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'intext_spend_acc2')
BEGIN
   CREATE LOGIN [intext_spend_acc2] WITH PASSWORD = 0x0200AA39E26FAAABAF0571912E627424CA5F5AF27B82BC9416F7447B89D1559A8DB8C3FE17AF7BD4B1A0381E05452691D6D0A1DB5DD5729D675FE731B9AA6D49B04B857CFCC5 HASHED, SID = 0x6218B03D5DB1A4488F98177E922AEEF7, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF
END