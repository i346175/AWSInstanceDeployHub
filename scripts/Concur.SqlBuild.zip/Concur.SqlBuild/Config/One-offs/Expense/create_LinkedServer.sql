USE [master];
IF NOT EXISTS(SELECT TOP 1 1 FROM sys.servers WHERE name = '<LinkedServerName>')
BEGIN
    EXEC master.dbo.sp_addlinkedserver @server = N'<LinkedServerName>', @srvproduct=N'SQL Server'
    EXEC master.dbo.sp_addlinkedsrvlogin @rmtsrvname=N'<LinkedServerName>',@useself=N'True',@locallogin=NULL,@rmtuser=NULL,@rmtpassword=NULL
    EXEC master.sys.sp_setnetname '<LinkedServerName>','<LinkedServerName>.spend.cnqr.tech,<SQLPort>'
    EXEC master.dbo.sp_serveroption @server=N'<LinkedServerName>', @optname=N'collation compatible', @optvalue=N'false'
    EXEC master.dbo.sp_serveroption @server=N'<LinkedServerName>', @optname=N'data access', @optvalue=N'true'
    EXEC master.dbo.sp_serveroption @server=N'<LinkedServerName>', @optname=N'dist', @optvalue=N'false'
    EXEC master.dbo.sp_serveroption @server=N'<LinkedServerName>', @optname=N'pub', @optvalue=N'false'
    EXEC master.dbo.sp_serveroption @server=N'<LinkedServerName>', @optname=N'rpc', @optvalue=N'true'
    EXEC master.dbo.sp_serveroption @server=N'<LinkedServerName>', @optname=N'rpc out', @optvalue=N'true'
    EXEC master.dbo.sp_serveroption @server=N'<LinkedServerName>', @optname=N'sub', @optvalue=N'false'
    EXEC master.dbo.sp_serveroption @server=N'<LinkedServerName>', @optname=N'connect timeout', @optvalue=N'0'
    EXEC master.dbo.sp_serveroption @server=N'<LinkedServerName>', @optname=N'collation name', @optvalue=null
    EXEC master.dbo.sp_serveroption @server=N'<LinkedServerName>', @optname=N'lazy schema validation', @optvalue=N'false'
    EXEC master.dbo.sp_serveroption @server=N'<LinkedServerName>', @optname=N'query timeout', @optvalue=N'0'
    EXEC master.dbo.sp_serveroption @server=N'<LinkedServerName>', @optname=N'use remote collation', @optvalue=N'true'
    EXEC master.dbo.sp_serveroption @server=N'<LinkedServerName>', @optname=N'remote proc transaction promotion', @optvalue=N'true'
END

