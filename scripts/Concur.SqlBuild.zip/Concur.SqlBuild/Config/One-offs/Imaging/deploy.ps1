try{
    Write-Host "No ONE-OFF scripts to run..."
}
catch{
    throw $_
}
finally {

}