USE [CT_HOST];
IF NOT EXISTS(SELECT TOP 1 1 FROM [ct_host].[dbo].[CTH_SERVER_INSTANCE] WHERE SERVER_NAME = '<SQLServerToAdd>')
    INSERT [ct_host].[dbo].[CTH_SERVER_INSTANCE] 
        VALUES ('<SQLServerToAdd>',<SQLPort>, null, '<SQLServerToAdd>');