. C:\vault\Get-VaultPassword.ps1
. C:\vault\Get-VaultToken.ps1
. C:\cfn\temp\CFN_Variables.ps1

$env:https_proxy = ''
$envt = $config.jurisdiction
$cthostserver = $config.cthostserver
$cthostdbname = $config.cthostdbname
$sqlport = $config.port
$s3bucket = $config.s3bucket
$awsregion = $config.awsregion
$cthstUser = 'dbformation'

$vpc = $($config.vaultnamespace).split('/')[0]
$domain = $config.domain

$logfile = "C:\mssql-scripts\ConcurSqlBuild\concursqlbuild.log"

#transform $env:microservice to variable start with capital letter and store to variable $microservice
$microservice = $env:microservice.substring(0,1).ToUpper() + $env:microservice.substring(1)
$scriptPath = "C:\Program Files\WindowsPowerShell\Modules\Concur.SqlBuild\Config\One-offs\$microservice"

try{
    Start-Transcript -Path $logfile -Append
    Write-Output ">>>> $($env:microservice.Tostring().ToUpper()) | $($env:COMPUTERNAME.Tostring().ToUpper()) - One-Off Configurations - STARTED <<<<<"
    
    ##### Running scripts on EXPENSE server #####
    Invoke-Sqlcmd -Database master -InputFile "$scriptPath\sp_configure.sql" -ErrorAction Stop -TrustServerCertificate
    Invoke-Sqlcmd -Database master -InputFile "$scriptPath\create-awsopsdb.sql" -ErrorAction Stop -TrustServerCertificate
    Invoke-Sqlcmd -Database master -InputFile "$scriptPath\aws-sql-clr-install.sql" -ErrorAction Stop -TrustServerCertificate
    Invoke-Sqlcmd -Database master -InputFile "$scriptPath\createLogins-$envt.sql" -ErrorAction Stop -TrustServerCertificate
    Invoke-Sqlcmd -Database master -InputFile "$scriptPath\change-awsopsdb-owner.sql" -ErrorAction Stop -TrustServerCertificate

    If($NameOfCRecord.ToLower() -notlike "*dummy*"){ #Condition added under CSCI-6183    
        $runScript = 0
        If(!(Test-Path -Path 'C:\cfn\temp\get_cluster_nodes_addresses.ps1')){
            $runScript = 1
        }Else{
            & C:\cfn\temp\get_cluster_nodes_addresses.ps1
            If(((Get-NetIPConfiguration).IPv4Address.IPAddress) -eq $MasterPrivateIP){
                $runScript = 1
            }
        }    

        If($runScript){
            $env:https_proxy = ''
            ##### Running scripts on CT_HOST server #####
            $token = Get-VaultToken -vault_namespace "$vpc/dbsql" -aws_region $awsregion 
            $Account = Get-VaultPassword -Name "$cthstUser" -token $token -vault_namespace "$vpc/dbsql" -aws_region $awsregion
            $PWord = ConvertTo-SecureString -String $($Account.GetNetworkCredential().Password) -AsPlainText -Force
            $cthstCred = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $cthstUser, $PWord
            $NameOfCRecord = $($NameOfCRecord).split('.')[0]
            #Condition added under CSCI-6763
            If($AWSAccountName -eq 'report'){
                $replaceStr = "$NameOfCRecord"
            }Else{
                $replaceStr = "$NameOfCRecord.$AWSAccountName.cnqr.tech"
            }
            
            $sqlText = $(Get-Content "$scriptPath\add_ServerEntryToCTHostTables.sql").Replace("<SQLServerToAdd>",$replaceStr).Replace("<SQLPort>","$sqlport")
            Invoke-Sqlcmd -ServerInstance "$cthostserver,$sqlport" -Database $cthostdbname -Query "$sqlText" -Credential $cthstCred -ErrorAction Stop -TrustServerCertificate
            # ===========================================
        }
    }
    
    Write-Output ">>>> $($env:microservice.Tostring().ToUpper()) | $($env:COMPUTERNAME.Tostring().ToUpper()) - One-Off Configurations - COMPLETED <<<<<"
}
catch{
    throw $_
}
finally {
    Stop-Transcript
}