use master;
GO
DECLARE @SQL nvarchar(1000);
IF EXISTS (SELECT 1 FROM sys.databases WHERE [name] = N'awsopsdb')
BEGIN
    SET @SQL = N'USE [awsopsdb];

                 ALTER DATABASE awsopsdb SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
                 USE [master];

                 DROP DATABASE awsopsdb;';
    EXEC (@SQL);
END;

CREATE DATABASE awsopsdb;

ALTER DATABASE awsopsdb SET TRUSTWORTHY ON;