-- name of the variable 
declare @awsopsdbOwner nvarchar(50)

-- name of the variable 
declare @variableName nvarchar(50) = N'aws_envt'

-- declare variables to store the result 
declare @environment nvarchar(50)
declare @table table (value nvarchar(50))

-- get the environment variables by executing a command on the command shell
declare @command nvarchar(60) = N'echo %' + @variableName + N'%';
insert into @table exec master..xp_cmdshell @command;
set @environment = (select top 1 value from @table);
print @environment

-- do something with the result 
if @environment = N'integration'  
    set @awsopsdbOwner = N'sa_sdbms'
else 
    set @awsopsdbOwner = N'concur_dcp'

print @awsopsdbOwner


use awsopsdb
EXEC sp_changedbowner @awsopsdbOwner;  