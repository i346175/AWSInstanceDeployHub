USE master;
GO
/* sp_help_revlogin script 
** Generated Feb  1 2023 11:24AM on EC2AMAZ-BNU991P */
 
 
-- Login: concur_dcp
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'concur_dcp')
                BEGIN
CREATE LOGIN [concur_dcp] WITH PASSWORD = 0x02009DA58CA091B9E321F565DB94D2150387F7307168FFCD114191F3C62E5C69144450E1942620FA1BA3B57EC69E0E16C5F62FBFF75D58CA327B466E41696F90DA1995611227 HASHED, SID = 0x16927AE14923BF48B855516378DF68F5, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF

        exec master.dbo.sp_addsrvrolemember @loginame='concur_dcp', @rolename='sysadmin'
END
 
-- Login: sa_alphaflight_green
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'sa_alphaflight_green')
                BEGIN
CREATE LOGIN [sa_alphaflight_green] WITH PASSWORD = 0x0200ED45A7D4F29A42F642E39B6207BEF39B5F2613EAE099367138C6E7768C403B2E4DEDE0EEC60BF9AD2394DEA8D47E386E7B0C3A4C90644C03E0F1EF366AB1DE91B02589E2 HASHED, SID = 0xFAFA254393D54745A497F1C12ED1A1E8, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF

        exec master.dbo.sp_addsrvrolemember @loginame='sa_alphaflight_green', @rolename='sysadmin'
END
 
-- Login: sa_aska
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'sa_aska')
                BEGIN
CREATE LOGIN [sa_aska] WITH PASSWORD = 0x020004382AC9B2B31A0526A527A677CF59AF977ECDF2AF0CD01FFD18B96C84E094288C52E00709D2CFB3F45F69EF61CF3950FCB415954C96F711837920F0322372426E51A96E HASHED, SID = 0x3A6BB1763C18A14D80890B1629FD2572, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF

        exec master.dbo.sp_addsrvrolemember @loginame='sa_aska', @rolename='sysadmin'
END
 
-- Login: uspscc\Database Admins
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'uspscc\Database Admins')
                BEGIN
CREATE LOGIN [uspscc\Database Admins] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='uspscc\Database Admins', @rolename='sysadmin'
END
 
-- Login: USPSCC\dbsql_admins
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'USPSCC\dbsql_admins')
                BEGIN
CREATE LOGIN [USPSCC\dbsql_admins] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='USPSCC\dbsql_admins', @rolename='sysadmin'
END
 
-- Login: USPSCC\I847250
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'USPSCC\I847250')
                BEGIN
CREATE LOGIN [USPSCC\I847250] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='USPSCC\I847250', @rolename='sysadmin'
END
 
-- Login: USPSCC\I847250-a
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'USPSCC\I847250-a')
                BEGIN
CREATE LOGIN [USPSCC\I847250-a] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='USPSCC\I847250-a', @rolename='sysadmin'
END
 
-- Login: USPSCC\I847262
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'USPSCC\I847262')
                BEGIN
CREATE LOGIN [USPSCC\I847262] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='USPSCC\I847262', @rolename='sysadmin'
END
 
-- Login: USPSCC\I847262-a
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'USPSCC\I847262-a')
                BEGIN
CREATE LOGIN [USPSCC\I847262-a] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='USPSCC\I847262-a', @rolename='sysadmin'
END

-- Login: USPSCC\sa_dba_prov
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'USPSCC\sa_dba_prov')
                BEGIN
CREATE LOGIN [USPSCC\sa_dba_prov] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='USPSCC\sa_dba_prov', @rolename='sysadmin'
END
 
-- Login: USPSCC\sa_gypsy
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'USPSCC\sa_gypsy')
                BEGIN
CREATE LOGIN [USPSCC\sa_gypsy] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='USPSCC\sa_gypsy', @rolename='sysadmin'
END
 
-- Login: uspscc\sa_pnsqluser
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'uspscc\sa_pnsqluser')
                BEGIN
CREATE LOGIN [uspscc\sa_pnsqluser] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='uspscc\sa_pnsqluser', @rolename='sysadmin'
END
 
-- Login: USPSCC\sa_pscc_sql_monitor
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'USPSCC\sa_pscc_sql_monitor')
                BEGIN
CREATE LOGIN [USPSCC\sa_pscc_sql_monitor] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='USPSCC\sa_pscc_sql_monitor', @rolename='sysadmin'
END
 
-- Login: USPSCC\sa_pscc_tenable_db
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'USPSCC\sa_pscc_tenable_db')
                BEGIN
CREATE LOGIN [USPSCC\sa_pscc_tenable_db] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='USPSCC\sa_pscc_tenable_db', @rolename='sysadmin' 
END
 
-- Login: USPSCC\sa_solarwinds
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'USPSCC\sa_solarwinds')
                BEGIN
CREATE LOGIN [USPSCC\sa_solarwinds] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='USPSCC\sa_solarwinds', @rolename='sysadmin'
END
 
-- Login: ussea7x
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'ussea7x')
                BEGIN
CREATE LOGIN [ussea7x] WITH PASSWORD = 0x0200473277F39DEC26C3C56D0E4DB8EDE11F365347F6ACF3394D4ED0AE460CC47C7C0F5CF993E5AB9C40D8AB139DD1E69CB54AB2F2C1C0899374B2477457C05B1C49DAC7A0FC HASHED, SID = 0xD5DA51CC54486E4F91FC3F93C88717CB, DEFAULT_DATABASE = [master], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF
 
END
 
-- Login: ussea7xadmin
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'ussea7xadmin')
                BEGIN
CREATE LOGIN [ussea7xadmin] WITH PASSWORD = 0x020036470EDE17D52F16B1EDDEBF9BFE1459407B3458397876682862711C457E64888683DB1B31787A2F2A4559AA18BDD2E9CF0A1FDD1E16236D372865E6C3E37C313A199E44 HASHED, SID = 0xD62CBE57F3E0604584F11D63EDF8B53E, DEFAULT_DATABASE = [master], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF

        exec master.dbo.sp_addsrvrolemember @loginame='ussea7xadmin', @rolename='sysadmin'
END

