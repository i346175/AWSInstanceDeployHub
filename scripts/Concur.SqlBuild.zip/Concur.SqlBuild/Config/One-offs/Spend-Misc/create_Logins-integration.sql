USE [master];
GO

-- Login: integration\OT_DBO_PROD
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'integration\OT_DBO_PROD')
BEGIN
    CREATE LOGIN [integration\OT_DBO_PROD] FROM WINDOWS;
END

-- Login: integration\OT_READONLY_PROD
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'integration\OT_READONLY_PROD')
BEGIN
    CREATE LOGIN [integration\OT_READONLY_PROD] FROM WINDOWS;
END