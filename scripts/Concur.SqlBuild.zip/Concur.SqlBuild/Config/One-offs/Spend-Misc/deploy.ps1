. C:\cfn\temp\CFN_Variables.ps1
$envt = $config.jurisdiction
$logfile = "C:\mssql-scripts\ConcurSqlBuild\concursqlbuild.log"

$cthostserver = $($config.cthostserver).split('.')[0]
$cthostdbname = $config.cthostdbname
$sqlport = $config.port
$s3bucket = $config.s3bucket
$envt = $config.jurisdiction
$awsregion = $config.awsregion
$cthstUser = 'dbformation'
$vpc = $($config.vaultnamespace).split('/')[0]
$domain = $config.domain

#transform $env:microservice to variable start with capital letter and store to variable $microservice
$microservice = $env:microservice.substring(0,1).ToUpper() + $env:microservice.substring(1)
$scriptPath = "C:\Program Files\WindowsPowerShell\Modules\Concur.SqlBuild\Config\One-offs\$microservice"

try {
    Start-Transcript -Path $logfile -Append
    Write-Output ">>>> $($env:microservice.Tostring().ToUpper()) | $($env:COMPUTERNAME.Tostring().ToUpper()) - One-Off Configurations - STARTED <<<<<"
    If($NameOfCRecord.ToLower() -like "*cupdb*" -and $envt -in ('us2','eu2','apj1')){
        Invoke-Sqlcmd -Database master -InputFile "$scriptPath\create_Logins-$envt.sql" -ErrorAction Stop -TrustServerCertificate
    }
    Else{
        Write-Host "No ONE-OFF scripts to run..."
    }
    Write-Output ">>>> $($env:microservice.Tostring().ToUpper()) | $($env:COMPUTERNAME.Tostring().ToUpper()) - One-Off Configurations - COMPLETED <<<<<"
}
catch{
    throw $_
}
finally{
}
