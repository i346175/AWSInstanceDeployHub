USE master;
GO
/* sp_help_revlogin script 
** Generated Feb  1 2023 11:27AM on EC2AMAZ-DBNIBFN */
 
 
-- Login: CliqAnalytics
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'CliqAnalytics')
                BEGIN
CREATE LOGIN [CliqAnalytics] WITH PASSWORD = 0x020045476C81E323BE36638B2EDEE5DED46C8B542A82E963CCA0E0C010D815835E84F4EA145594CCAFF98D52B4E8185B86C97E002547B1F23A9582783B159D5761BDFB87D852 HASHED, SID = 0xB47BED6CF9122249B94DD3A2C3DA9D08, DEFAULT_DATABASE = [master], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF
 
END
 
-- Login: db_migration_cliqitinerary
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'db_migration_cliqitinerary')
                BEGIN
CREATE LOGIN [db_migration_cliqitinerary] WITH PASSWORD = 0x020079756D217F2310E5053A33059699C4EB6D9613951EE2ADFBFC4E267DA595313B8D9959D4E7DE539413A9E7E25619249F92584115EB66A20EC076CCB5BB48E2B30E0DD99E HASHED, SID = 0x2C2234C49A48A74BA5AFA7F7048793C4, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF
 
END
 
-- Login: dbo_dbupdate
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'dbo_dbupdate')
                BEGIN
CREATE LOGIN [dbo_dbupdate] WITH PASSWORD = 0x0200A7EA6D6FDA897EE896ABE7040DC399B7475D1703B498C07B804CB49FE221F0EC4645C27E332D0EF9B89DAC1BE5850191904F34CBA66C458EFF9A19CB30556C370C878816 HASHED, SID = 0x4030616C4AE71C459CC9CAEFF904783D, DEFAULT_DATABASE = [master], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF

        exec master.dbo.sp_addsrvrolemember @loginame='dbo_dbupdate', @rolename='sysadmin'
END
 
-- Login: itindpuspscc
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'itindpuspscc')
                BEGIN
CREATE LOGIN [itindpuspscc] WITH PASSWORD = 0x02005719BD60C09317A5B9245835B55586850F8503947E3692CC07F859A8A8A5A34DE2A882E84F2915FB817CBCAF6B43E2F6F5B18CD139052631D7DB8CEFE54D9834DDDEECE4 HASHED, SID = 0xB16C5EB6EE83EE418715E585BB441278, DEFAULT_DATABASE = [master], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF
 
END
 
-- Login: sa_ccps_itin
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'sa_ccps_itin')
                BEGIN
CREATE LOGIN [sa_ccps_itin] WITH PASSWORD = 0x0200F225C8BEDABCAC98F24E5F4BC4D287CBCFFA26D85FBFC0E7DBC07F610BE1DD12EB91E5E62CB372BA4499563E54FC2F538047C002EDCA908E22539614C97964397AAA3578 HASHED, SID = 0x2F6F72F628AD6F41B15BF5EDEA91304C, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF
 
END
 
-- Login: sa_itin
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'sa_itin')
                BEGIN
CREATE LOGIN [sa_itin] WITH PASSWORD = 0x02001F1EF297C13D131CC8F7248857E9EEF272FAD3AEC1F6EF2FBF413F09B0F1615E64EADEEA89BEB0185B5894E7114D4A6E19E859B32BAE0C6F23113A9690E89640B408C787 HASHED, SID = 0x91F3B43F02EFC94B9217648BEDB5779A, DEFAULT_DATABASE = [master], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF
 
END
 
-- Login: sql_cte_itin
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'sql_cte_itin')
                BEGIN
CREATE LOGIN [sql_cte_itin] WITH PASSWORD = 0x02002429B7C5F45F608728A30AE189104743BEE9CCF3C866BC887D392509214FC22D195A97A3D237BB7D1FE51B667CA67DB050256DC0565CC45D9DC79718C742CA387B97D973 HASHED, SID = 0x9C0961FC7031CB429E7598BF10FC0A96, DEFAULT_DATABASE = [master], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF
 
END
 
-- Login: uspscc\Database Admins
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'uspscc\Database Admins')
                BEGIN
CREATE LOGIN [uspscc\Database Admins] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='uspscc\Database Admins', @rolename='sysadmin'
END
 
-- Login: USPSCC\dbsql_admins
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'USPSCC\dbsql_admins')
                BEGIN
CREATE LOGIN [USPSCC\dbsql_admins] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='USPSCC\dbsql_admins', @rolename='sysadmin'
END
 
-- Login: USPSCC\sa_dba_prov
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'USPSCC\sa_dba_prov')
                BEGIN
CREATE LOGIN [USPSCC\sa_dba_prov] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='USPSCC\sa_dba_prov', @rolename='sysadmin'
END
 
-- Login: uspscc\sa_pnsqluser
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'uspscc\sa_pnsqluser')
                BEGIN
CREATE LOGIN [uspscc\sa_pnsqluser] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='uspscc\sa_pnsqluser', @rolename='sysadmin'
END
 
-- Login: USPSCC\sa_pscc_tenable_db
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'USPSCC\sa_pscc_tenable_db')
                BEGIN
CREATE LOGIN [USPSCC\sa_pscc_tenable_db] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='USPSCC\sa_pscc_tenable_db', @rolename='sysadmin' 
END
 
-- Login: USPSCC\sa_solarwinds
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'USPSCC\sa_solarwinds')
                BEGIN
CREATE LOGIN [USPSCC\sa_solarwinds] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

        exec master.dbo.sp_addsrvrolemember @loginame='USPSCC\sa_solarwinds', @rolename='sysadmin'
END

