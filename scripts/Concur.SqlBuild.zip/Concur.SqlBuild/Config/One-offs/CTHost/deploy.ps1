$envt = $config.jurisdiction
$logfile = "C:\mssql-scripts\ConcurSqlBuild\concursqlbuild.log"
#transform $env:microservice to variable start with capital letter and store to variable $microservice
$microservice = $env:microservice.substring(0,1).ToUpper() + $env:microservice.substring(1)
$scriptPath = "C:\Program Files\WindowsPowerShell\Modules\Concur.SqlBuild\Config\One-offs\$microservice"

try{
    Start-Transcript -Path $logfile -Append
    Write-Output ">>>> $($env:microservice.Tostring().ToUpper()) | $($env:COMPUTERNAME.Tostring().ToUpper()) - One-Off Configurations - STARTED <<<<<"
    Get-ChildItem -Path "$scriptPath\*" -Include *.sql -Exclude *Logins*.sql | ForEach-Object{
        $file = $_.FullName.Trim()    
        Invoke-Sqlcmd -Database master -InputFile $file -ErrorAction Stop -TrustServerCertificate
    }
    If($envt -in ('us2','eu2','apj1')){
        Invoke-Sqlcmd -Database master -InputFile "$scriptPath\create_Logins-$envt.sql" -ErrorAction Stop -TrustServerCertificate
    }
    Copy-Item "$scriptPath\Set-DefaultDBLocation.ps1" D:\PowerShellScripts\Set-DefaultDBLocation.ps1
    Write-Output ">>>> $($env:microservice.Tostring().ToUpper()) | $($env:COMPUTERNAME.Tostring().ToUpper()) - One-Off Configurations - COMPLETED <<<<<"
    Get-Service -Name MSSQLSERVER | Restart-Service -Force
}
catch{
    throw $_
}
finally {
    Stop-Transcript
}
