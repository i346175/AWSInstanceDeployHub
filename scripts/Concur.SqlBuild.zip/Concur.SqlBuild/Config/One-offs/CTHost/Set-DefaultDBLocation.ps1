   #Requires -Modules SQLServer
   Import-Module SqlServer -DisableNameChecking

   Remove-Variable * -ErrorAction SilentlyContinue
   
   function Get-AdminPassword {
       param (
           [Parameter(Mandatory)]
           [string]$clusterName,
           [Parameter(Mandatory)][ValidateSet("front", "report", "reportmigration", "spend", "tools", "travel")]
           [string]$VPC,
           [Parameter(Mandatory)][ValidateSet("clusadmin", "sa", "sa_sqlacct", "sa_sqlagentacct", "sa_sqlbackup")]
           [string]$userAccount,
           [ValidateSet("new", "current", "old")]
           [string]$type = 'current'
       )
       begin{
           . C:\vault\Get-VaultPassword.ps1
           . C:\vault\Get-VaultToken.ps1
       }
       process{
           if($env:aws_envt -eq 'eu2') { $sqlport = '2050'}
           elseif($env:aws_envt -eq 'us2'){ $sqlport = '2040' }
               elseif($env:aws_envt -eq 'uspscc'){ $sqlport = '2020'}
               elseif($env:aws_envt -eq 'apj1'){ $sqlport = '2060'}
                   else{ $sqlport = '2020'}
           $vaultnamespace = "$VPC/dbsql"
           $envt = $env:aws_envt
           switch ($type)
           {
               "new" { $userAcct = "$($userAccount)_new" ; Break}
               "current" { $userAcct = $userAccount ; Break }
               "old" { $userAcct = "$($userAccount)_old"}
           }
           
           try{
               $env:https_proxy = ''
               $token = Get-VaultToken -vault_namespace $vaultnamespace -aws_region $awsregion 
               $Account = Get-VaultPassword -Name "$clusterName.$envt.$VPC.$userAcct".ToLower() -token $token -vault_namespace $vaultnamespace -aws_region $awsregion
               # $Account.GetNetworkCredential().UserName
               return $Account.GetNetworkCredential().Password
           }
           catch{
               Write-Error ">>>>> Unable to find secret: $clusterName.$envt.$VPC.$userAcct <<<<<"
           }
       }
       end{
       }
   } 
   
   function Set-DefaultDBLocation {
       try{
           #SET VARIABLES
           $port = $config.port
           $s3BucketName = $config.s3bucket
           $env = $config.jurisdiction
           $typeFilter=$config.dbtypes

           $log = "D:\Logs\Set-DefaultDBLocation.txt"

           try{
               [System.DirectoryServices.ActiveDirectory.Domain]::GetComputerDomain()
               $dir = 'domain'
           } catch{
               $dir = 'domainless'
           }
           
           $sqlConn = New-Object Microsoft.SqlServer.Management.Common.ServerConnection
           $sqlConn.ServerInstance = ".,$port"
           $srv = New-Object Microsoft.SqlServer.Management.SMO.Server($sqlConn)
           $srv.ConnectionContext.TrustServerCertificate = $true
   
           if ($env:COMPUTERNAME -ne $srv.AvailabilityGroups.PrimaryReplicaServerName) {
               return
           }
   
           #GET CONFIG
           $cmd = "SELECT s.ENV_TYPE, s.INSTANCE_KEY, i.SERVER_NAME, a.NAME
           FROM ct_host.dbo.cth_new_single_tenant_db_settings s
           INNER JOIN ct_host.dbo.CTH_SERVER_INSTANCE i ON s.INSTANCE_KEY = i.INSTANCE_KEY
           INNER JOIN ct_host.dbo.CTH_APPLICATION a ON a.APP_KEY = s.APP_KEY
           WHERE 1=1"
           $dt = New-Object System.Data.DataTable
           
           $dt.Load($srv.ConnectionContext.ExecuteReader($cmd));
   
           if($dt.Rows.Count -eq 0){
               $msg = "No rows were returned for the application single tenant db server locations. This returned no rows:`r`n$($cmd)"
               throw $msg
           }
   
           ## GET INSTANCES
           $inventoryFile = "C:\Temp\inventory.json"
           $s3Key  =  "EC2Inventory/$($env.ToLower())_EC2Inventory.json"
   
           Read-S3Object -BucketName $s3BucketName -Key $s3Key -File  $inventoryFile | Out-Null
   
           $inventory = Get-Content -Raw $inventoryFile | ConvertFrom-Json
               
           $instances = @()
           
           $msFilter = @('spend-impl', 'expense', 'reporting')
           $instFilter = @('mt|-D\d*$|d$')
   
           $instances =  $inventory | ? { 
           $_.Microservice -in $msFilter -and $_.ConfigType -eq 'PRODUCTION' -and $_.SQLServerCName.Replace("-", "") -match "$typeFilter" -and $_.SQLServerCName -notmatch $instFilter -and $_.PSObject.Properties.Name -notcontains 'SQLListener'} | Select MicroService, HostName, SQLServerCName, Account_Name
   
           $instances | Add-Member -MemberType NoteProperty -Name Type -Value ''
           $instances | Add-Member -MemberType NoteProperty -Name Port -Value $port
   
           $instances | ?{if ($_.SQLServerCName -match 'prod'){
               $type = 'PROD'
               } elseif ($_.SQLServerCName -match 'test'){
               $type = 'TEST'
               } elseif ($_.SQLServerCName -match 'demo'){
               $type = 'DEMO'
               }
               # messy integration anomalies
               elseif ($env:aws_envt -eq 'integration' -and $_.Microservice -eq 'reporting'){
                   $type = 'PROD TEST DEMO'
               } elseif ($env:aws_envt -eq 'integration' -and $_.MicroService -eq 'spend-impl'){
                   $_.MicroService = 'Expense'
                   $type = 'TEST DEMO'
               } elseif ($env:aws_envt -eq 'integration' -and $_.MicroService -eq 'expense'){
                   $type = 'PROD'
               } else {
                   $msg = 'Unable to determine server type'
                   throw $msg
               }
               $_.Type = $type
           }
       
           #GET SERVER FREE SPACE
           $dt | % {
               $serverFreeSpace = New-Object System.Collections.Generic.List[PSCustomObject]
               $env_type = $_.ENV_TYPE
               $oldInstanceKey = $_.INSTANCE_KEY
               $oldServerName = $_.SERVER_NAME
               $application = $_.NAME
   
               $instances | ?{$_.Microservice -eq $application -and $_.Type -match $env_type} | %{
                   $driveSpace = $null
                   $serverName = $_.Hostname
                   $cName = $_.SQLServerCName
                   $serverVPC = $_.Account_Name
                   $type = $_.Type
   
                   #linked server check (only required for expense)
                   if ($application -eq 'Expense'){ 
                      $linkedServer = $null
                      $linkedServer = $srv.LinkedServers | ?{$_.Name -eq $cName}
                      if (!$linkedServer){
                          $msg = "Linked server for $cName does not exist on ct_host" 
                          throw $msg
                      }
                      #only works on domain 
                      if ($dir -eq 'domain'){
                          try{
                              $linkedServer.TestConnection()
                          } catch {
                                  $msg = "Linked server for $cName does not work on ct_host" 
                                  throw $msg
                          }
                      }   
                   }
   
                   if ($dir -eq 'domainless'){
                       $userAccount = 'sa_sqlbackup'
                       $serverPWord = $null
                       $maxRetries = 5
                       $retryCount = 0
                       for ($retryCount = 0; $retryCount -lt $maxRetries; $retryCount++) {
                           try {
                               $serverPWord = ConvertTo-SecureString $(Get-AdminPassword -clusterName $serverName -VPC $serverVPC -userAccount $userAccount) -AsPlainText -Force
                               break 
                           } catch {
                               Start-Sleep -Seconds 5
                           }
                       }
                       if ($retryCount -eq $maxRetries) {
                           $msg = "Error authenticating to vault for $($serverName) $($serverVPC) $($userAccount)"
                           throw $msg
                       }

                       $serverCredential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $userAccount, $serverPWord
                       $driveSpace = $null
                       $driveSpace = Get-WMIObject Win32_LogicalDisk -filter "DriveType=3" -ComputerName $serverName -Credential $serverCredential -ErrorAction SilentlyContinue | ?{$_.DeviceID -eq 'E:'} 
                       
                   } else {
                       $driveSpace = Invoke-Command -ComputerName $serverName -ScriptBlock {Get-WMIObject Win32_LogicalDisk -filter "DriveType=3" -ErrorAction SilentlyContinue | ?{$_.DeviceID -eq 'E:'}} 
                   }
                   
                   if (!$driveSpace){
                       $msg = "Unable to retrieve drive space for Server $($cName)"
                       Write-Warning $msg
                       "[{0:MM/dd/yy} {0:HH:mm:ss}] $($msg)" -f (Get-Date) | Out-File $log -Append 
                   } else {
                       [void]$serverFreeSpace.Add([PSCustomObject]@{
                           ServerName = $serverName
                           CName = $cName
                           Type = $type
                           FreeSpaceGB = [Math]::Round(($driveSpace.FreeSpace/1GB),2)
                           FreeSpacePercent = [Math]::Round((($driveSpace.FreeSpace/1GB) / ($driveSpace.Size/1GB) * 100),0)
                           });    
                   }
               }                    
   
               $targetServer = $null
               $targetServer = $serverFreeSpace |  Sort FreeSpaceGB -Descending | Select -First 1
               if (!$targetServer){
                   $msg = "Unable to locate a server of type $application - $env_type to rebalance"
                   "[{0:MM/dd/yy} {0:HH:mm:ss}] $($msg)" -f (Get-Date) | Out-File $log -Append 
                   Write-Warning $msg
                   return
                   #throw $msg
               } elseif ($targetServer.FreeSpacePercent -lt 10){
                   $msg = "There is less than 10 percent disks space on $($targetServer.CName). Unable to locate a server of type $application - $env_type to rebalance "
                   throw $msg
               } 
   
               $newInstanceKey = $null
               $cmd = $null
               $cmd = "SELECT INSTANCE_KEY FROM ct_host.dbo.CTH_SERVER_INSTANCE WHERE UPPER(LEFT(SERVER_NAME, ISNULL(NULLIF(CHARINDEX('.', SERVER_NAME)-1, -1), LEN(SERVER_NAME)))) = '$($targetServer.CName.ToUpper())';"
               $newInstanceKey = $srv.ConnectionContext.ExecuteScalar($cmd);
               if(!$newInstanceKey){
                   $msg = "Could not find the instance key for computer $($targetServer.CName) from CTH_SERVER_INSTANCE in ct_host." 
                   throw $msg
               }
   
               if ($oldInstanceKey -eq $newInstanceKey) {          
                   return
               } else {
                   #UPDATE CONFIG
                   try{
                        $cmd = $null                    
                        $cmd = "UPDATE s 
                        SET INSTANCE_KEY = $newInstanceKey
                        FROM ct_host.dbo.cth_new_single_tenant_db_settings s
                        INNER JOIN ct_host.dbo.CTH_SERVER_INSTANCE i ON s.INSTANCE_KEY = i.INSTANCE_KEY
                        INNER JOIN ct_host.dbo.CTH_APPLICATION a ON a.APP_KEY = s.APP_KEY
                        WHERE 1=1 
                        AND UPPER(a.NAME) = UPPER('$application' )
                        AND UPPER(s.ENV_TYPE) = UPPER('$env_type')
                        AND s.INSTANCE_KEY =  $oldInstanceKey";
                        $sqlConn.BeginTransaction();
                        $srv.ConnectionContext.ExecuteNonQuery($cmd);
                        $sqlConn.CommitTransaction();
                       "[{0:MM/dd/yy} {0:HH:mm:ss}] $($application) $($env_type) $($oldServerName) to $($targetServer.CName)" -f (Get-Date) | Out-File $log -Append 
                   }
                   catch {
                        $sqlConn.RollBackTransaction();
                        $msg = "There was an error in updating ct_host for cth_new_single_tenant_db_settings from $oldServerName to $($targetServer.CName) `r`nThe detailed error message is: :`r`n$(($_ | Format-List -Force | Out-String))"
                        throw $msg
                   }
               }
           }
           
       }
       catch{
           $snsTopic = "IOPS-DB-Email"
           $accountDetails = Get-EC2InstanceMetadata -Category IdentityDocument | ConvertFrom-Json | Select accountId, region
           $awsPartition = (Get-EC2InstanceMetadata -Category Region).PartitionName
           $snsArn = "arn:$($awsPartition):sns:$($accountDetails.region):$($accountDetails.accountID):$($snsTopic)"
           Publish-SNSMessage -TopicArn $snsArn -Subject "dbsql_WARNING_$(($env:aws_envt).ToUpper())_spend_CT_HOST_Set-DefaultDBLocation" -Message "Unable to set default DB location `r`n
           $_" | Out-Null
           return
       }
       finally{
           if ($srv){
               $srv.ConnectionContext.Disconnect();
           }
       }
   }
   
   Set-DefaultDBLocation  
 