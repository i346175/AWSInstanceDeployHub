USE [master]
GO

IF NOT EXISTS (SELECT TOP 1 1 FROM sys.server_principals WHERE type_desc = 'SERVER_ROLE' AND name = 'dbFormationSrvRole')
    CREATE SERVER ROLE [dbFormationSrvRole] AUTHORIZATION [flat]
GO

ALTER SERVER ROLE [setupadmin] ADD MEMBER [dbFormationSrvRole]
GRANT ALTER ANY LINKED SERVER TO [dbFormationSrvRole]
GRANT ALTER ANY LOGIN TO [dbFormationSrvRole]
GRANT VIEW SERVER STATE TO [dbFormationSrvRole]
GO