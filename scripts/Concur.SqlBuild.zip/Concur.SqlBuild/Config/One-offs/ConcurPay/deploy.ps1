$logfile = "C:\mssql-scripts\ConcurSqlBuild\concursqlbuild.log"

#transform $env:microservice to variable start with capital letter and store to variable $microservice
$microservice = $env:microservice.substring(0,1).ToUpper() + $env:microservice.substring(1)
$scriptPath = "C:\Program Files\WindowsPowerShell\Modules\Concur.SqlBuild\Config\One-offs\$microservice"

try{
    Start-Transcript -Path $logfile -Append
    Write-Host "No ONE-OFF scripts to run..."
}
catch{
    throw $_
}
finally {
    Stop-Transcript
}