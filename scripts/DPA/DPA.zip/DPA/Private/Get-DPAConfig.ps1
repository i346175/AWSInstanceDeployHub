<#
.SYNOPSIS
Gets a Solarwinds DPA monitor configurations
.DESCRIPTION
Gets all configuration according solarwinds DPA name
.PARAMETER solarwinds
Solarwinds DPA drop down list
.EXAMPLE
Get-DpaConfig -solarwinds solarwinds-central
Gets the configuration for solarwinds-central
.NOTES
Author: Zdenek Stary
#>
function Get-DPAConfig{
    param (
        [Parameter(Mandatory=$True,HelpMessage="Choose the Solarwinds which exist")]
        [ValidateSet("solarwinds-reporting","solarwinds-central","solarwinds-spend","solarwinds-travel","solarwinds-test")]
        [String]$solarwinds
    )


    begin
    {


#[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy        
[System.Net.ServicePointManager]::ServerCertificateValidationCallback = $null
[System.Net.ServicePointManager]::CheckCertificateRevocationList = $null
[System.Net.ServicePointManager]::Expect100Continue = $null
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::SystemDefault
        
    }
    process
    {
        $env:https_proxy = ''
    
        $vault_namespace = 'tools/dbsql'
        switch ($env:aws_envt){
            "eu2"{ 
                 $SqlPort = "2050"; 
                 $awsRegion = 'eu-central-1';
             break}
             "us2" { 
                 $SqlPort = "2040"; 
                 $awsRegion = 'us-west-2';

             break}
             "uspscc" { 
                $SqlPort = "2020"; 
                $awsRegion = 'us-gov-west-1';

            break}
             "integration" { 
                 $SqlPort = "2020"; 
                 $awsRegion = 'us-west-2';

            break}
             "apj1" { 
                $SqlPort = "2060"; 
                $awsRegion = 'ap-northeast-1';
            break}
         }
          
        try {
            set-location "C:\vault"
            . .\Get-VaultToken.ps1
            . .\Get-VaultPassword.ps1
            . .\Get-AdminPassword.ps1
            $token = Get-VaultToken -vault_namespace $vault_namespace -aws_region $awsRegion
            $secretName="$($solarwinds)-token"

            $Account = Get-VaultPassword -vault_namespace $vault_namespace -aws_region $awsRegion -Name "$($secretName)" -token $token
            $refreshToken = $Account.GetNetworkCredential().Password
            $refreshToken = $refreshToken.Replace("'","''")
        }
        catch{
            $_
            write-output "Access Token Retrival Failed"
        }


 #Adding certificate exception to prevent API errors
 #test if type name 'TrustAllCertsPolicy exist and not add it if true
 <#
 add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
#>
#fix for powershell core "message": "Unable to find type [System.Net.ICertificatePolicy]." not found type System.Net.ICertificatePolicy

if ($PSEdition -eq 'Desktop') {
    class TrustAllCertsPolicy : System.Net.ICertificatePolicy {
        [bool] CheckValidationResult (
            [System.Net.ServicePoint]$srvPoint,
            [System.Security.Cryptography.X509Certificates.X509Certificate]$certificate,
            [System.Net.WebRequest]$request,
            [int]$certificateProblem
        ) {
            return $true
        }
     }

    [System.Net.ServicePointManager]::CertificatePolicy = New-Object -TypeName TrustAllCertsPolicy
 } 
#[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}
[System.Net.ServicePointManager]::CheckCertificateRevocationList = $false
[System.Net.ServicePointManager]::Expect100Continue = $false
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

        try {
      
            $baseURL = "https://$($solarwinds).tools.cnqr.tech/iwc/api/"
            $authTokenURL = "$($baseURL)security/oauth/token"
            $body = @{"grant_type" = "refresh_token"
            "refresh_token" = $refreshToken
            };           
            
            $dpaAuthResponse = Invoke-RestMethod -Uri $authTokenURL -Method POST -Body $body

        }
        catch 
        {
            write-output $_
            write-output "Access Token Retrival Failed"
        }
             
        
        # If successful we will create our headers to be used for all API calls
        $tokenType = $dpaAuthResponse.token_type
        $accessToken = $dpaAuthResponse.access_token


        $dpa = [PSCustomObject]@{
            baseURL = $baseURL
            tokenType = $tokenType
            accessToken = $accessToken
            body = $body
            sqlPort = $SqlPort
            awsRegion = $awsRegion
            vault_namespace = $vault_namespace
            token = $token
        }
        return $dpa
    
    }
    end{

    }
}