# DPA

## Requirements

- DPA module: import-module DPA -Force

### Basic Usage

### Basic Usage

DPA module must be placed to these bucket and updated there in case of every change
EU2: https://mssql-dbinstalls.s3.eu-central-1.amazonaws.com/DPA/
integration/US2/ccps: https://mssql-2019-ent-rtm.s3.us-west-2.amazonaws.com/DPA/

## Examples

Register new SQL server to Solarwinds DPA
```powershell
$sysadminCredential = Get-Credential -UserName integration\i346175-a -Message 'Enter sysadmin password'

Register-DPAMonitor -solarwinds solarwinds-central -vpc tools -microservice tools -monitorName "EC2AMAZ-EJSPL5E" -credential $sysadminCredential -DatabaseType SQLServer -clusterName TestSQL006 -port 2020 -deployment ON_PREMISE

```
```powershell
$sysadminCredential = Get-Credential -UserName integration\i346175-a -Message 'Enter sysadmin password'

Register-DPAMonitor -solarwinds solarwinds-central -vpc tools -microservice tools -monitorName "EC2AMAZ-EJSPL5E" -credential $sysadminCredential
```

Unregister server from Solarwinds DPA
```powershell
$sysadminCredential = Get-Credential -UserName integration\i346175-a -Message 'Enter sysadmin password'
Unregister-DPAMonitor -solarwinds solarwinds-central -monitorName "EC2AMAZ-EJSPL5E" -credential $sysadminCredential
```

Unregister group of servers from Solarwinds DPA
```powershell
$result = Get-DPAMonitor -solarwinds solarwinds-central
$servers = $result | Where-Object -Property "Name" -Like "*Tools*" | Select-Object -Property 'Name' -ExpandProperty 'Name'
$sysadminCredential = Get-Credential -UserName integration\i346175-a -Message 'Enter sysadmin password'
$servers -split "`r`n" | Unregister-DPAMonitor -solarwinds solarwinds-central -monitorName {"$_"} -credential $sysadminCredential
```

Set specific custom property value to registered servers
```powershell
$result = Get-DPAMonitor -solarwinds solarwinds-central
$servers = $result | Where-Object -Property "Name" -Like "*Tools" | Select-Object -Property 'Name' -ExpandProperty 'Name'

$sysadminCredential = Get-credential -UserName integration\i346175-a -Message 'Enter sysadmin password'
$servers -split "`r`n" | Set-DPACustomPropertyValue -solarwinds solarwinds-central -property "MicroService" -propertyValue "tools" -monitorName {"$_"}
```

Get list of all registered servers and properties from specified Solarwinds DPA
```powershell
Get-DPAMonitor -solarwinds solarwinds-central
```


