<#
.SYNOPSIS
Gets a DPA monitor (server)
.DESCRIPTION
Gets a registered server (monitor) from DPA. This can be done by name or ID.
.PARAMETER DatabaseId
Database ID of the monitor (db_id in the URL).
.PARAMETER MonitorName
Name of the monitor.
.EXAMPLE
Get-DpaMonitor -DatabaseId 1 -solarwinds 'solarwinds-reporting'
Gets the information for db_id = 1
.EXAMPLE
Get-DpaMonitor -MonitorName 'MyMonitoredServer' -solarwinds 'solarwinds-reporting'
Gets the information for MyMonitoredServer
.NOTES
Author: Zdenek Stary
#>

function Get-DPAMonitor {
    [CmdletBinding(DefaultParameterSetName = 'All')]
    param (
        [Parameter(ParameterSetName = 'ByDatabaseId')]
        [ValidateNotNullOrEmpty()]
        [int[]] $DatabaseId,

        [Parameter(ParameterSetName = 'ByName')]
        [ValidateNotNullOrEmpty()]
        [string[]] $MonitorName,

        [Parameter(ParameterSetName = 'Pipeline', ValueFromPipeline)]
        [object[]] $InputObject,
        
        [Parameter(Mandatory=$True)]
        [ValidateSet('solarwinds-reporting','solarwinds-central','solarwinds-spend','solarwinds-travel','solarwinds-test')]
        [ValidateNotNullOrEmpty()]
        [String]$solarwinds

    )
    begin {
#[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy 

[System.Net.ServicePointManager]::ServerCertificateValidationCallback = $null
[System.Net.ServicePointManager]::CheckCertificateRevocationList = $null
[System.Net.ServicePointManager]::Expect100Continue = $null
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::SystemDefault

    }
    process {
        
        if ($PSCmdlet.ParameterSetName -eq 'Pipeline') {
            foreach ($iObject in $InputObject) {
                switch ($iObject.GetType().Name) {
                    'AlertGroup' {
                        $iObject.Monitors
                    }
                }
            }
        } else {
            if ($PSBoundParameters.ContainsKey('DatabaseId') -and $DatabaseId.Count -eq 1) {
                $endpoint = "databases/$DatabaseId/monitor-information"
            } else {
                $endpoint = 'databases/monitor-information'
            }
           
        
        try {
    
                $dpa = Get-DPAConfig -solarwinds $solarwinds
         
                $monitorURL = $dpa.baseURL + "$endpoint"

                $dpaHeader = @{}
                $dpaHeader.Add("Accept", "application/json")
                $dpaHeader.Add("Content-Type", "application/json;charset=UTF-8")
                $dpaHeader.Add("Authorization", "$($dpa.tokenType) $($dpa.accessToken)")


#[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}
[System.Net.ServicePointManager]::CheckCertificateRevocationList = $false
[System.Net.ServicePointManager]::Expect100Continue = $false
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

                $response = Invoke-RestMethod -Method Get -Uri $($monitorURL) -Headers $($dpaHeader) -TimeoutSec 60
                $monitors = $response.data
         
                #$monitors | Format-List
            } catch {
                if ($_.Exception.Response.StatusCode.value__ -eq 422) {
                    return $null
                }
     
                write-host "Problem with reading from $($solarwinds).tools.cnqr.tech"
                $_
            }
        
            if ($PSBoundParameters.ContainsKey('DatabaseId') -and $DatabaseId -is [array]) {
                $monitors = $monitors | Where-Object { $_.dbid -in $DatabaseId }
            } elseif ($PSCmdlet.ParameterSetName -eq 'ByName') {
                $monitors = $monitors | Where-Object { $_.name -like "*$MonitorName*" }
            }
    
            $monitorFactory = New-Object MonitorFactory
            foreach ($monitor in $monitors) {
                $monitorFactory.New($monitor)
            }
            
        }
    }
}
