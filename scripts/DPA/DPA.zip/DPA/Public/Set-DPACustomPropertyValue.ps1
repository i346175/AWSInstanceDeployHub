<#
.SYNOPSIS
Set customr property
.DESCRIPTION
Set custom property value in Solarwinds DPA
.PARAMETER solarwinds
Solarwinds drop down list
.PARAMETER propertyName
Name of the property
.PARAMETER propertyValue
Value of the property
.EXAMPLE
$sysadminCredential = Get-Credential -UserName i346175-u -Message 'Enter sysadmin password'
Set-DPACustomPropertyValue -solarwinds solarwinds-central -property "MicroService" -propertyValue "spend-impl" -monitorName "EC2AMAZ-ERMB67B"
Gets all values from Microservice property in Solarwinds DPA solarwinds-central
.NOTES
Author: Zdenek Stary
#>
function Set-DPACustomPropertyValue{
    param (
        [Parameter(Mandatory=$True,HelpMessage="Choose the Solarwinds which exist")]
        [ValidateSet("solarwinds-reporting","solarwinds-central","solarwinds-spend","solarwinds-travel","solarwinds-test")]
        [String]$solarwinds,
        [Parameter(Mandatory=$True,HelpMessage="Specify property name ")]
        [String]$property,
        [Parameter(Mandatory=$True,HelpMessage="Specify property value ")]
        [String]$propertyValue,
        [Parameter(Mandatory=$True,ValueFromPipeline = $true,HelpMessage="Specify server name (Monitor) ")]
        [String]$monitorName
    )

    begin{
#[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy 

[System.Net.ServicePointManager]::ServerCertificateValidationCallback = $null
[System.Net.ServicePointManager]::CheckCertificateRevocationList = $null
[System.Net.ServicePointManager]::Expect100Continue = $null
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::SystemDefault
    }
    process
    {

        try{
            $dpa = Get-DPAConfig -solarwinds $solarwinds               
            #----------------------------------------------------------
            # Setting custom property values
            #----------------------------------------------------------
       
            $body = $propertyValue | ConvertTo-Json
            #GET propertyId and  $propertyValueId from propertyValue and property
            $result=Get-DPAMonitor -solarwinds $solarwinds -MonitorName "*$monitorName*"
            $serverID = $result.DatabaseId
            #Get Id of the property
            $result2 = Get-DPACustomProperty -solarwinds $solarwinds -propertyName "$property"
            $propertyId = $result2.id
            #Get Id of the property Value which is part of given property
            $result3 = Get-DPACustomProperty -solarwinds $solarwinds -propertyId $propertyId
            $propertyValueId = $result3 | Select-Object -ExpandProperty values | Where-Object -Property value -EQ "$propertyValue" | Select-Object -ExpandProperty id

            
            $assignPropertyValueURL = $dpa.baseURL + "databases/" + $serverID + "/properties/" + $propertyId + "/values/" + $propertyValueId;
            
            $dpaHeader = @{}
            $dpaHeader.Add("Accept", "application/json")
            $dpaHeader.Add("Content-Type", "application/json;charset=UTF-8")
            $dpaHeader.Add("Authorization", "$($dpa.tokenType) $($dpa.accessToken)")   

            $response = Invoke-RestMethod -Uri $assignPropertyValueURL -Body $body -Method POST -Headers $($dpaHeader) -TimeoutSec 60
            $monitors = $response.data
            $monitors | Format-Table -AutoSize
            Write-Host "The value ""$propertyValue"" of custom property ""$property"" is assigned to the $monitorName" -ForegroundColor Green
        } catch {
            if ($_.Exception.Response.StatusCode.value__ -eq 422) {
                return $null
            }

            write-host "Problem with reading from $($solarwinds).tools.cnqr.tech"
            $_.Exception.ToString()
        }

    }
    end{

    }
} 