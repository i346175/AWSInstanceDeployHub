
<#
.SYNOPSIS
Unregister the monitor (server) from Solarwinds DPA
.DESCRIPTION
Unregister the monitor (server) from chosen Solarwinds DPA
.PARAMETER solarwinds
Choose the Solarwinds which exist
.PARAMETER monitorName
Name of the monitor (servername).
.EXAMPLE
$sysadminCredential = Get-Credential -UserName integration\i346175-a -Message 'Enter sysadmin password'
Unregister-DPAMonitor -solarwinds solarwinds-central -monitorName 'server' -credential $sysadminCredential
.EXAMPLE
$sysadminCredential = Get-Credential -UserName integration\i346175-a -Message 'Enter sysadmin password'
"EC2AMAZ-5CQLOMJ
EC2AMAZ-80E2LAK
EC2AMAZ-BLSHH39
EC2AMAZ-FBCSGGT" -split "`r`n" | %{
$name = $_.ToString().Trim().ToLower();
 Unregister-DPAMonitor -solarwinds solarwinds-central -credential $sysadminCredential -monitorName $name
}
.NOTES
Author: Zdenek Stary
#>
function Unregister-DPAMonitor{
    param (
        [Parameter(Mandatory=$True,HelpMessage="Choose the Solarwinds which exist")]
        [ValidateSet("solarwinds-reporting","solarwinds-central","solarwinds-spend","solarwinds-travel","solarwinds-test")]
        [String]$solarwinds,
        [Parameter(Mandatory=$True,ValueFromPipeline = $true)]
        [String]$monitorName,
        [Parameter()]
        [PSCredential] $credential
    )

    begin{
#[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy 

[System.Net.ServicePointManager]::ServerCertificateValidationCallback = $null
[System.Net.ServicePointManager]::CheckCertificateRevocationList = $null
[System.Net.ServicePointManager]::Expect100Continue = $null
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::SystemDefault


    }
    process
    {
        try{

            $dpa = Get-DPAConfig -solarwinds $solarwinds
       
            $sysAdminUser = $credential.UserName
            $PasswordSA = $credential.GetNetworkCredential().Password

                        
            $dpaHeader = @{}
            $dpaHeader.Add("Accept", "application/json")
            $dpaHeader.Add("Content-Type", "application/json;charset=UTF-8")
            $dpaHeader.Add("Authorization", "$($dpa.tokenType) $($dpa.accessToken)") 
            
         
            #----------------------------------------------------------
            # Unregister a SQL Server database instance for monitoring.
            #----------------------------------------------------------
            $monitor = Get-DpaMonitor -MonitorName $monitorName -solarwinds $solarwinds
            $unregistrationURL = $dpa.baseURL + "databases/unregister-monitor"


            $body = @{
                "databaseId" = $monitor.DatabaseId; 
                "sysAdminUser" = "$($sysAdminUser)";
                "sysAdminPassword" = "$($PasswordSA)";
                            
            }

  
            $body = $body | ConvertTo-Json
  
            try{
                Write-Host "Unregistering server $monitorName..."
                $dpaResponseJSON = Invoke-RestMethod -Uri $unregistrationURL -Body $body -Method POST -Headers $dpaHeader -TimeoutSec 60
                $dpaResponse = $dpaResponseJSON.data
                #$dpaResponse | Format-Table -AutoSize
                write-host "Unregistering server $($monitorName) from $($solarwinds).tools.cnqr.tech was SUCCESSFULL" -ForegroundColor Green
            }
            catch{
                write-host "Unregistering server $($monitorName) from $($solarwinds).tools.cnqr.tech FAILED"
                $_.Exception.ToString()
            }
            
        
        } catch {
            if ($_.Exception.Response.StatusCode.value__ -eq 422) {
                return $null
            }

            write-host "Problem with reading from $($solarwinds).tools.cnqr.tech"
            $_.Exception.ToString()
        }
    }
    end{

    }
} 