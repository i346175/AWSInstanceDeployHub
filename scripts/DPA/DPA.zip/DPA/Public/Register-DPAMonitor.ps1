<#
.SYNOPSIS
Register a Solarwinds DPA monitor (server)
.DESCRIPTION
Register server (monitor) to choose Solarwinds DPA. This is usually done during provisioning but it can be add with this script.
.PARAMETER solarwinds
Choose the Solarwinds which exist
.PARAMETER monitorName
Name of the monitor (servername).
.PARAMETER databaseType
Choose from existing database types
.PARAMETER port
port of the server (if not specified, port used according environment)
.PARAMETER clusterName
Name of the cluster (if not specified, cluster name is not used in Monitor name)) 
.PARAMETER deployment
Choose from existing deployment types
.PARAMETER createMonitoringUser
Create monitoring user (if not specified, monitoring user is not created). By default monitoring user is created during server build.
.PARAMETER vpc
Choose from existing VPC names
.PARAMETER microservice
Choose from these microservices
.PARAMETER credential
Credentials of the sysadmin user (if not specified so 'sa' is used as credential, only during build)
.EXAMPLE
$sysadminCredential = Get-Credential -UserName integration\i346175-a -Message 'Enter sysadmin password'
Register-DPAMonitor -solarwinds 'solarwinds-reporting' -monitorName 'MyMonitoredServer' -vpc 'reportmigration' -microservice 'reporting' -credential $sysadminCredential
.NOTES
Author: Zdenek Stary
#>
function Register-DPAMonitor
{
    param (
        [Parameter(Mandatory=$True,HelpMessage="Choose the Solarwinds which exist")]
        [ValidateSet("solarwinds-reporting","solarwinds-central","solarwinds-spend","solarwinds-travel","solarwinds-test")]
        [String]$solarwinds,
        
        [Parameter(Mandatory=$True)]
        [String]$monitorName,
        
        [Parameter(Mandatory=$False)]
        [ValidateSet('SQLServer')]
        $databaseType='SQLServer',
        
        [Parameter(Mandatory=$False)]
        $port,

        [Parameter(Mandatory=$False)]
        [ValidateNotNullOrEmpty()]
        [string[]] $clusterName,

        [Parameter(Mandatory=$False)]
        [ValidateSet("RDS", "ON_PREMISE-EC2")]
        $deployment = "ON_PREMISE",
        [Parameter(Mandatory=$False)]
        [switch] $createMonitoringUser,
        
        [Parameter(Mandatory=$False)]
        [switch] $domainless,     
        [Parameter(Mandatory=$True,HelpMessage="Choose from existing VPC names ")]
        [ValidateSet("spend","travel","report","front","reportmigration","tools")]
        [String]$vpc,
        
        [Parameter(Mandatory=$True,HelpMessage="Choose from these microservices")]
        [ValidateSet("tools","outtasksession","outtask","itinerary","travel-misc","cthost","expense","spend-impl","spend-misc","concurpay","reporting","imaging","cognos")]
        [String]$microservice,
        
        [Parameter(Mandatory=$False,HelpMessage="Sysadmin account")]
        [ValidateNotNull()]
        [System.Management.Automation.PSCredential]
        [System.Management.Automation.Credential()]
        $credential = [System.Management.Automation.PSCredential]::Empty
    )

    begin{
#[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy 

[System.Net.ServicePointManager]::ServerCertificateValidationCallback = $null
[System.Net.ServicePointManager]::CheckCertificateRevocationList = $null
[System.Net.ServicePointManager]::Expect100Continue = $null
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::SystemDefault

    }
    process
    {
        #Test if server is already registered
        $result=Get-DPAMonitor -solarwinds $solarwinds -MonitorName "*$monitorName*"
        
        if ($result.DatabaseId) {
             #finish script with message
             Write-Host "Database $($monitorName) is already registered to $($solarwinds).tools.cnqr.tech" -ForegroundColor DarkYellow
             break
        }

        
        try{
    
            #PLAN: Get all AWS Tag values according parameter $monitorName and AWS $vpc
            #$tagValues = Get-EC2TagValues -monitorName $monitorName -vpc $vpc
            set-location "C:\vault"
            . .\Get-VaultPassword.ps1
            . .\Get-AdminPassword.ps1
 
            #test if $credential.UserName was set
            if ($null -eq $credential.UserName) {
                #if not set use sysadmin account which is stored in vault and get password (sa is available only during provisioning)
                $sysAdminUser = "sa_sqlbackup"
                $PasswordSA = Get-AdminPassword -vault_namespace $($dpa.vault_namespace) -aws_region $($dpa.awsRegion) -Name $($sysAdminUser) -token $dpa.token -vpc $vpc
                $PasswordSA = $credential.GetNetworkCredential().Password
            }
            else {
                #use set credentials from parameter $credential
                $sysAdminUser = $credential.UserName
                $PasswordSA = $credential.GetNetworkCredential().Password
            }
            #}
            $dpa = Get-DPAConfig -solarwinds $solarwinds
            #Set account which is used like monitoring user
            $userAccount = "solarwinds"

            $Account2 = Get-VaultPassword -vault_namespace $($dpa.vault_namespace) -aws_region $($dpa.awsRegion) -Name $($userAccount) -token $dpa.token

            $PasswordDPA = $Account2.GetNetworkCredential().Password
            $PasswordDPA = $PasswordDPA.Replace("'","''")

            $registrationURL = $dpa.baseURL + "databases/register-monitor"

            $dpaHeader = @{}
            $dpaHeader.Add("Accept", "application/json")
            $dpaHeader.Add("Content-Type", "application/json;charset=UTF-8")
            $dpaHeader.Add("Authorization", "$($dpa.tokenType) $($dpa.accessToken)")   

            #----------------------------------------------------------
            # Register a SQL Server database instance for monitoring.
            #----------------------------------------------------------
            switch ($env:aws_envt){
                "eu2"{ 
                     $fqdn = "$($env:aws_envt).system.cnqr.tech";
                 break}
                 "us2" { 
                     $fqdn = "$($env:aws_envt).system.cnqr.tech";
                 break}
                 "uspscc" { 
                    $fqdn = "$($env:aws_envt).system.cnqr.tech";
                break}
                 "integration" { 
                     $fqdn = "$($env:aws_envt).system.cnqr.tech";
                break}
                 "apj1" {
                    $fqdn = "$($env:aws_envt).system.cnqr.tech";
                break}
             }
      
            $body = @{
                "serverName" = "$($monitorName).$($fqdn)";
                "databaseType" = $databaseType.ToUpper()
                "monitoringUser" = "solarwinds"
                "monitoringUserPassword" = "$($PasswordDPA)";   
                "sysAdminUser" = "$($sysAdminUser)";
                "sysAdminPassword" = "$($PasswordSA)";
                "databaseGroup" = $microservice.ToUpper()
                "deployment" = $deployment       
            }
            
            if ($PSBoundParameters.ContainsKey('domainless')) {
                #Dont display fqdn for integration server as it is all the time same
                if ($PSBoundParameters.ContainsKey('clusterName')) 
                {
                    $displayName  = "$($clusterName)_$($monitorName).$($vpc).cnqr.tech"
                }
                else {
                    $displayName = "$($monitorName).$($vpc).cnqr.tech"
                }
            }
            else
            {
                #ADD cluster name on the beginning of the monitor name
                if ($PSBoundParameters.ContainsKey('clusterName')) 
                {
                    $displayName  = "$($clusterName)_$($monitorName).$($fqdn)"
                }
                else {
                    $displayName = "$($monitorName).$($fqdn)"               
                }
            }   

            $body['displayName'] = $displayName
                      
            if ($PSBoundParameters.ContainsKey('port')) {
                $body['port'] = $port
            }
            else {
                $body['port'] = $dpa.sqlPort;
            }
            

            if ($PSBoundParameters.ContainsKey('deployment') -and $deployment -eq "RDS") {
                $body['deployment'] = "AMAZON"
            }
            elseif ($PSBoundParameters.ContainsKey('deployment') -and $deployment -eq "ON_PREMISE-EC2") {
                $body['deployment'] = "ON_PREMISE"
            }
      
           
            if ($PSBoundParameters.ContainsKey('createMonitoringUser')) {
                $body['monitoringUserIsNew'] = $true
            } else {
                $body['monitoringUserIsNew'] = $false
            }

            $body = $body | ConvertTo-Json
         
            try{
                Write-Host "Registering Database..."
                $response = Invoke-RestMethod -Uri $registrationURL -Body $body -Method POST -Headers $dpaHeader -TimeoutSec 60
                $monitor = $response.data
                write-host "Registering server ""$monitorName"" under the name ""$displayName"" to $($solarwinds).tools.cnqr.tech was SUCCESSFULL" -ForegroundColor Green
            }
            catch{
                write-output "Registering server ""$monitorName"" under the name ""$displayName"" to $($solarwinds).tools.cnqr.tech FAILED"
                $_.Exception.ToString()
            }
            
            #Return EC2 Tags assigned to server
            #MicroService=Value,#Cluster(Name)=Value,
            #$tags=get-EC2TagValues($monitorName,$tag)

            #Assign specific Tag values to registered server in Solarwinds DPA
            #It includes check if Solarwinds DPA has given Tag Name, if not then Tag Name is firstly created in Solarwinds DPA like custom property name
            #Then the value of this property Name is created and assigned to server in Solarwinds

            try{
                Set-DPACustomPropertyValue -solarwinds $solarwinds -property "MicroService" -propertyValue "$microservice" -monitorName "$monitorName"
            }
            catch{
                write-output "Assigning microservice $microservice to $displayName FAILED"
                $_.Exception.ToString()
            }
     
        } catch {
            if ($_.Exception.Response.StatusCode.value__ -eq 422) {
                return $null
            }

            write-host "Problem with reading from $($solarwinds).tools.cnqr.tech"
            $_.Exception.ToString()
        }  
    }
    end
    {

    }
} 
