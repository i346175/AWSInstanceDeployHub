<#
.SYNOPSIS
Gets a Solarwinds DPA monitor configurations
.DESCRIPTION
Gets all configuration according solarwinds DPA name
.PARAMETER solarwinds
Solarwinds drop down list
.PARAMETER propertyName
Name of the property
.PARAMETER propertyId
Value of the property
.EXAMPLE
Get-DPACustomProperty -solarwinds $solarwinds -propertyName "MicroService"
Gets all values from Microservice property in Solarwinds DPA solarwinds-central
.NOTES
Author: Zdenek Stary
#>
function Get-DPACustomProperty {
    [CmdletBinding(DefaultParameterSetName = 'All')]
    param (
        [Parameter(ParameterSetName = 'ByName')]
        [ValidateNotNullOrEmpty()]
        [string[]] $propertyName,
        [Parameter(ParameterSetName = 'ByPropertyId')]
        [ValidateNotNullOrEmpty()]
        [int[]] $propertyId,
        [Parameter(Mandatory=$True,HelpMessage="Choose the Solarwinds which exist")]
        [ValidateSet("solarwinds-reporting","solarwinds-central","solarwinds-spend","solarwinds-travel","solarwinds-test")]
        [String]$solarwinds
    )

    begin{
#[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy 

[System.Net.ServicePointManager]::ServerCertificateValidationCallback = $null
[System.Net.ServicePointManager]::CheckCertificateRevocationList = $null
[System.Net.ServicePointManager]::Expect100Continue = $null
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::SystemDefault
    }
    process
    {
        if ($PSBoundParameters.ContainsKey('propertyId') -and $propertyId.Count -eq 1) 
        {
            $endpoint = "databases/properties/ + $propertyId"
           
        } else {
            $endpoint = "databases/properties"
        }

            
        try{
            $dpa = Get-DPAConfig -solarwinds $solarwinds
            $URL = $dpa.baseURL + "$endpoint"

            $dpaHeader = @{}
            $dpaHeader.Add("Accept", "application/json")
            $dpaHeader.Add("Content-Type", "application/json;charset=UTF-8")
            $dpaHeader.Add("Authorization", "$($dpa.tokenType) $($dpa.accessToken)")

            $responseJSON = Invoke-RestMethod -Uri $URL -Method GET -Headers $dpaHeader -TimeoutSec 60
            $properties = $responseJSON.data
       
                
        } catch {
            if ($_.Exception.Response.StatusCode.value__ -eq 422) {
                return $null
            }
     
            write-host "Problem with reading from $($solarwinds).tools.cnqr.tech"
            $_.Exception.ToString()
        }
            

        if ($PSBoundParameters.ContainsKey('propertyId') -and $propertyId -is [array]) {
            $properties = $properties | Where-Object { $_.id -in $propertyId }
        } elseif ($PSCmdlet.ParameterSetName -eq 'propertyName') {
            $properties = $properties | Where-Object { $_.name -eq $propertyName }
        }

    }
    end{
        return $properties
    }
} 
